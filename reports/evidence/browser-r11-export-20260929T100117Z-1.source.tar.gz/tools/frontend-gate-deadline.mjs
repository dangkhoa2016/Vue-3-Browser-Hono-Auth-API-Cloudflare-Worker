// The expiry marker distinguishes the supervisor deadline from a producer's own exit 124.
import {spawn} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const [seconds,marker,command,...args]=process.argv.slice(2);
if(!/^\d+$/.test(seconds)||Number(seconds)<=0||!marker||!command) process.exit(2);
let expired=false, killer;
const child=spawn(command,args,{stdio:'inherit',detached:true});
const signalGroup=signal=>{try{process.kill(-child.pid,signal);}catch(error){if(error.code!=='ESRCH')throw error;}};
const timer=setTimeout(()=>{
  expired=true;writeFileSync(marker,'deadline expired\n',{flag:'wx'});
  signalGroup('SIGTERM');killer=setTimeout(()=>signalGroup('SIGKILL'),10000);
},Number(seconds)*1000);
child.on('error',error=>{clearTimeout(timer);console.error(error.message);process.exitCode=127;});
child.on('close',(code,signal)=>{
  clearTimeout(timer);clearTimeout(killer);
  if(expired) signalGroup('SIGKILL');
  process.exitCode=expired?124:(code??(signal==='SIGTERM'?143:signal==='SIGKILL'?137:1));
});
