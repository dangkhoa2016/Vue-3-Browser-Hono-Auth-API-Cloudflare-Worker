<template>
  <div class="relative max-w-7xl mx-auto space-y-8">
    <div class="absolute inset-0 -z-10">
      <div class="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(14,116,144,0.18),transparent_45%),radial-gradient(circle_at_bottom_right,rgba(234,179,8,0.18),transparent_45%)]"></div>
      <div class="absolute inset-0 bg-[linear-gradient(transparent,rgba(15,23,42,0.03))]"></div>
    </div>

    <LoginRequiredPrompt
      v-if="showLoginRequired"
      tone="amber"
      button-icon="bi bi-box-arrow-in-right text-lg"
      :title="$t('message.auth.login_required')"
      :message="$t('message.kv_admin_page.login_required_message')"
      :button-text="$t('message.auth.login')"
      @action="openLoginModal"
    />
    <template v-else-if="!isSuperAdmin">
      <section class="bg-rose-50/80 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800 rounded-3xl p-8 text-center shadow-sm">
        <i class="bi bi-shield-lock-fill text-5xl text-rose-600 dark:text-rose-400 mb-4"></i>
        <h3 class="text-xl font-bold text-rose-900 dark:text-rose-100 mb-2">{{ $t('message.kv_admin_page.access_denied_title') }}</h3>
        <p class="text-rose-700 dark:text-rose-300">{{ $t('message.kv_admin_page.access_denied_message') }}</p>
      </section>
    </template>
    <template v-else>
      <PageHeroSection
        section-class="relative overflow-hidden rounded-[32px] border border-slate-200/70 dark:border-slate-800 bg-gradient-to-br from-white via-blue-50/40 to-indigo-50/40 dark:from-slate-900 dark:via-slate-950 dark:to-slate-900 p-8 shadow-[0_24px_80px_-60px_rgba(15,23,42,0.8)]"
        top-blob-class="absolute -top-20 -right-16 w-72 h-72 bg-blue-400/10 rounded-full blur-3xl"
        bottom-blob-class="absolute -bottom-24 -left-24 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl"
        content-class="relative flex flex-col md:flex-row gap-6 md:items-center justify-between"
      >
        <template #left>
          <div>
            <div class="inline-flex items-center gap-2 rounded-full bg-blue-900/10 text-blue-800 dark:bg-blue-400/10 dark:text-blue-200 px-3 py-1 text-xs font-semibold tracking-[0.2em]">
              <span class="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
              {{ $t('message.navbar.kv_admin_audit', 'KV ADMIN AUDIT') }}
            </div>
            <h1 class="mt-4 text-3xl font-black text-slate-900 dark:text-white">Audit System Configs</h1>
            <p class="mt-2 text-slate-600 dark:text-slate-300">Manage retention, performance, alerts, and feature flags.</p>
          </div>
        </template>

        <template #right>
          <div>
            <ActionTextButton variant="soft" shape="full" icon="bi bi-arrow-clockwise" @click="loadData">
              {{ $t('message.kv_admin_page.reload', 'Reload') }}
            </ActionTextButton>
          </div>
        </template>
      </PageHeroSection>

      <div v-if="errorMessage" class="p-8 text-center rounded-[28px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <i class="bi bi-exclamation-triangle-fill text-4xl text-rose-500 mb-3"></i>
        <h3 class="text-lg font-bold text-slate-900 dark:text-white">Error</h3>
        <p class="text-slate-500 mt-2">{{ errorMessage }}</p>
      </div>

      <div v-else class="flex flex-col gap-6">
        <!-- Feature Flags -->
        <div class="rounded-[28px] border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-6">
          <h2 class="text-xl font-bold border-b border-slate-100 dark:border-slate-800 pb-3"><i class="bi bi-toggles2 text-indigo-500 mr-2"></i> Features</h2>
          
          <div v-if="loadingState.features" class="space-y-4 animate-pulse">
            <div v-for="i in 4" :key="i" class="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
              <div class="space-y-2">
                <div class="h-4 w-32 bg-slate-200 dark:bg-slate-700 rounded"></div>
                <div class="h-3 w-48 bg-slate-200 dark:bg-slate-700 rounded"></div>
              </div>
              <div class="h-6 w-11 bg-slate-200 dark:bg-slate-700 rounded-full"></div>
            </div>
          </div>
          
          <div v-else class="grid md:grid-cols-2 grid-cols-1 gap-4">
            <div v-for="(val, key) in auditData.features" :key="key" class="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
              <div>
                <p class="font-medium text-slate-800 dark:text-slate-200">{{ formatFeatureName(key) }}</p>
                <p class="text-xs text-slate-500">{{ key }}</p>
              </div>
              <button 
                class="relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none"
                :class="val ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-600'"
                @click="toggleFeature(key, !val)"
                :disabled="isToggling[key]"
              >
                <span class="inline-block h-4 w-4 transform rounded-full bg-white transition-transform" :class="val ? 'translate-x-6' : 'translate-x-1'"/>
              </button>
            </div>
          </div>
        </div>

        <!-- Retention Policies -->
        <div class="rounded-[28px] border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
          <h2 class="text-xl font-bold border-b border-slate-100 dark:border-slate-800 pb-3"><i class="bi bi-clock-history text-amber-500 mr-2"></i> Retention Policies</h2>
          
          <div v-if="loadingState.retention" class="grid md:grid-cols-2 grid-cols-1 gap-4 animate-pulse">
            <div v-for="i in 4" :key="i" class="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30">
              <div class="h-3 w-20 bg-amber-200 dark:bg-amber-800/50 rounded mb-2"></div>
              <div class="h-5 w-16 bg-amber-200 dark:bg-amber-800/50 rounded"></div>
            </div>
          </div>
          
          <div v-else class="grid md:grid-cols-2 grid-cols-1 gap-4">
            <div v-for="(val, key) in auditData.retention" :key="key" class="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30">
              <span class="text-xs uppercase tracking-wider text-amber-600 dark:text-amber-400 block mb-1 shrink-0 whitespace-nowrap overflow-hidden text-ellipsis">{{ formatFeatureName(key) }}</span>
              <span class="font-mono text-lg text-slate-800 dark:text-slate-200 font-bold whitespace-normal break-words">{{ formatValueUnit(key, val) }}</span>
            </div>
          </div>
        </div>

        <!-- Performance Settings -->
        <div class="rounded-[28px] border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
          <h2 class="text-xl font-bold border-b border-slate-100 dark:border-slate-800 pb-3"><i class="bi bi-speedometer2 text-emerald-500 mr-2"></i> Performance</h2>
          
          <div v-if="loadingState.performance" class="grid md:grid-cols-2 grid-cols-1 gap-4 animate-pulse">
            <div v-for="i in 4" :key="i" class="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/30">
              <div class="h-3 w-20 bg-emerald-200 dark:bg-emerald-800/50 rounded mb-2"></div>
              <div class="h-5 w-16 bg-emerald-200 dark:bg-emerald-800/50 rounded"></div>
            </div>
          </div>
          
          <div v-else class="grid md:grid-cols-2 grid-cols-1 gap-4">
            <div v-for="(val, key) in auditData.performance" :key="key" class="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/30">
              <span class="text-xs uppercase tracking-wider text-emerald-600 dark:text-emerald-400 block mb-1 truncate">{{ formatFeatureName(key) }}</span>
              <span class="font-mono text-lg text-slate-800 dark:text-slate-200 font-bold whitespace-normal break-words">{{ formatValueUnit(key, val) }}</span>
            </div>
          </div>
        </div>

        <!-- Alert & Thresholds -->
        <div class="rounded-[28px] border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
          <h2 class="text-xl font-bold border-b border-slate-100 dark:border-slate-800 pb-3"><i class="bi bi-bell text-rose-500 mr-2"></i> Alerts & Thresholds</h2>
          
          <div v-if="loadingState.alerts" class="grid grid-cols-2 gap-4 animate-pulse">
            <div v-for="i in 4" :key="i" class="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-900/10 border border-rose-100 dark:border-rose-900/30">
              <div class="h-3 w-20 bg-rose-200 dark:bg-rose-800/50 rounded mb-2"></div>
              <div class="h-5 w-16 bg-rose-200 dark:bg-rose-800/50 rounded"></div>
            </div>
          </div>
          
          <div v-else class="grid grid-cols-2 gap-4">
            <div v-for="(val, key) in auditData.alerts" :key="key" class="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-900/10 border border-rose-100 dark:border-rose-900/30">
              <span class="text-xs uppercase tracking-wider text-rose-600 dark:text-rose-400 block mb-1 truncate">{{ formatFeatureName(key) }}</span>
              <span class="font-mono text-lg text-slate-800 dark:text-slate-200 font-bold whitespace-normal break-words">{{ formatValueUnit(key, val) }}</span>
            </div>
          </div>
        </div>

        <!-- Compliance Settings -->
        <div class="rounded-[28px] border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
          <h2 class="text-xl font-bold border-b border-slate-100 dark:border-slate-800 pb-3"><i class="bi bi-shield-check text-purple-500 mr-2"></i> Compliance Settings</h2>
          
          <div v-if="loadingState.compliance" class="grid grid-cols-2 gap-4 animate-pulse">
            <div v-for="i in 6" :key="i" class="p-4 rounded-2xl bg-purple-50/50 dark:bg-purple-900/10 border border-purple-100 dark:border-purple-900/30">
              <div class="h-3 w-20 bg-purple-200 dark:bg-purple-800/50 rounded mb-2"></div>
              <div class="h-5 w-16 bg-purple-200 dark:bg-purple-800/50 rounded"></div>
            </div>
          </div>
          
          <div v-else class="grid grid-cols-2 gap-4">
            <div v-for="(val, key) in auditData.compliance" :key="key" class="p-4 rounded-2xl bg-purple-50/50 dark:bg-purple-900/10 border border-purple-100 dark:border-purple-900/30">
              <span class="text-xs uppercase tracking-wider text-purple-600 dark:text-purple-400 block mb-1 shrink-0 whitespace-nowrap overflow-hidden text-ellipsis">{{ formatFeatureName(key) }}</span>
              <span class="font-mono text-lg text-slate-800 dark:text-slate-200 font-bold whitespace-normal break-words">
                <span v-if="typeof val === 'boolean'" :class="val ? 'text-emerald-500' : 'text-slate-400'">
                  <i :class="val ? 'bi bi-check-circle-fill' : 'bi bi-x-circle-fill'"></i> {{ val ? 'Enabled' : 'Disabled' }}
                </span>
                <span v-else>{{ formatValueUnit(key, val) }}</span>
              </span>
            </div>
          </div>
        </div>

        <!-- Realtime Settings -->
        <div class="rounded-[28px] border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
          <h2 class="text-xl font-bold border-b border-slate-100 dark:border-slate-800 pb-3"><i class="bi bi-activity text-blue-500 mr-2"></i> Realtime Settings</h2>
          
          <div v-if="loadingState.realtime" class="grid grid-cols-2 gap-4 animate-pulse">
            <div v-for="i in 4" :key="i" class="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30">
              <div class="h-3 w-20 bg-blue-200 dark:bg-blue-800/50 rounded mb-2"></div>
              <div class="h-5 w-16 bg-blue-200 dark:bg-blue-800/50 rounded"></div>
            </div>
          </div>
          
          <div v-else class="grid grid-cols-2 gap-4">
            <div v-for="(val, key) in auditData.realtime" :key="key" class="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30">
              <span class="text-xs uppercase tracking-wider text-blue-600 dark:text-blue-400 block mb-1 shrink-0 whitespace-nowrap overflow-hidden text-ellipsis">{{ formatFeatureName(key) }}</span>
              <span class="font-mono text-lg text-slate-800 dark:text-slate-200 font-bold whitespace-normal break-words">
                <span v-if="typeof val === 'boolean'" :class="val ? 'text-emerald-500' : 'text-slate-400'">
                  <i :class="val ? 'bi bi-check-circle-fill' : 'bi bi-x-circle-fill'"></i> {{ val ? 'Enabled' : 'Disabled' }}
                </span>
                <span v-else>{{ formatValueUnit(key, val) }}</span>
              </span>
            </div>
          </div>
        </div>

        <!-- Export Settings -->
        <div class="rounded-[28px] border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
          <h2 class="text-xl font-bold border-b border-slate-100 dark:border-slate-800 pb-3"><i class="bi bi-download text-teal-500 mr-2"></i> Export Settings</h2>
          
          <div v-if="loadingState.export" class="grid grid-cols-2 gap-4 animate-pulse">
            <div v-for="i in 4" :key="i" class="p-4 rounded-2xl bg-teal-50/50 dark:bg-teal-900/10 border border-teal-100 dark:border-teal-900/30">
              <div class="h-3 w-20 bg-teal-200 dark:bg-teal-800/50 rounded mb-2"></div>
              <div class="h-5 w-16 bg-teal-200 dark:bg-teal-800/50 rounded"></div>
            </div>
          </div>
          
          <div v-else class="grid grid-cols-2 gap-4">
            <div v-for="(val, key) in auditData.export" :key="key" class="p-4 rounded-2xl bg-teal-50/50 dark:bg-teal-900/10 border border-teal-100 dark:border-teal-900/30">
              <span class="text-xs uppercase tracking-wider text-teal-600 dark:text-teal-400 block mb-1 shrink-0 whitespace-nowrap overflow-hidden text-ellipsis">{{ formatFeatureName(key) }}</span>
              <span class="font-mono text-lg text-slate-800 dark:text-slate-200 font-bold whitespace-normal break-words">
                <span v-if="typeof val === 'boolean'" :class="val ? 'text-emerald-500' : 'text-slate-400'">
                  <i :class="val ? 'bi bi-check-circle-fill' : 'bi bi-x-circle-fill'"></i> {{ val ? 'Enabled' : 'Disabled' }}
                </span>
                <span v-else>{{ formatValueUnit(key, val) }}</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import ActionTextButton from '/vue/components/ActionTextButton.vue';
import LoginRequiredPrompt from '/vue/components/LoginRequiredPrompt.vue';
import PageHeroSection from '/vue/components/PageHeroSection.vue';
import { useKvAdminAuditConfigsPage } from '/vue/composables/useKvAdminAuditConfigsPage.js';

const {
  showLoginRequired,
  openLoginModal,
  isSuperAdmin,
  loadingState,
  errorMessage,
  isToggling,
  auditData,
  loadData,
  toggleFeature,
  formatFeatureName,
  formatValueUnit
} = useKvAdminAuditConfigsPage();
</script>
