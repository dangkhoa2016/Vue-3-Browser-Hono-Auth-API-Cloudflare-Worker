<template>
  <div class="max-w-6xl mx-auto space-y-8 py-6">
    <!-- Loading State -->
    <div v-if="isLoading" class="space-y-4 animate-pulse">
      <div class="h-12 bg-gray-200 dark:bg-gray-700 rounded-xl"></div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="h-36 bg-gray-200 dark:bg-gray-700 rounded-2xl"></div>
        <div class="h-36 bg-gray-200 dark:bg-gray-700 rounded-2xl"></div>
      </div>
      <div class="h-64 bg-gray-200 dark:bg-gray-700 rounded-2xl"></div>
    </div>

    <LoginRequiredPrompt
      v-else-if="showLoginRequired"
      tone="blue"
      :title="$t('message.api_explorer.login_required_title')"
      :message="$t('message.api_explorer.login_required_message')"
      :button-text="$t('message.auth.login')"
      @action="openLoginModal"
    />

    <!-- Error State -->
    <div v-else-if="errorMessage" class="bg-red-50 dark:bg-red-900/20 border-2 border-red-200 dark:border-red-800 rounded-2xl p-8 text-center">
      <i class="bi bi-exclamation-triangle-fill text-5xl text-red-600 dark:text-red-400 mb-4"></i>
      <h3 class="text-xl font-bold text-red-900 dark:text-red-100 mb-2">{{ $t('message.api_explorer.error_loading') }}</h3>
      <p class="text-red-700 dark:text-red-300 mb-4">{{ errorMessage }}</p>
      <ActionTextButton
        icon="bi bi-arrow-clockwise"
        tone="rose"
        shape="xl"
        @click="loadApiInfo"
      >
        {{ $t('message.common.retry') }}
      </ActionTextButton>
    </div>

    <!-- Content -->
    <div v-else-if="apiInfo" class="space-y-6">
      <!-- Header -->
      <div class="relative overflow-hidden bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-700 dark:to-purple-800 rounded-2xl p-6 text-white shadow-xl">
        <div class="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
        <div class="absolute -bottom-14 -left-6 w-32 h-32 bg-purple-300/10 rounded-full blur-3xl"></div>
        <div class="relative flex items-center justify-between flex-wrap gap-4">
          <div>
            <p class="text-sm font-semibold uppercase tracking-wide text-white/80">{{ $t('message.api_explorer.header_message') }}</p>
            <h1 class="text-2xl font-bold mt-1">{{ apiInfo.message || $t('message.api_explorer.title') }}</h1>
            <p class="text-white/80 mt-1">{{ $t('message.api_explorer.subtitle') }}</p>
          </div>
          <div class="flex gap-3 flex-wrap">
            <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur text-sm font-semibold">
              <i class="bi bi-person-badge"></i>
              {{ $t('message.api_explorer.role') }}: {{ apiInfo.user?.role }}
            </span>
            <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur text-sm font-semibold">
              <i class="bi bi-hdd-network"></i>
              {{ $t('message.api_explorer.environment') }}: {{ apiInfo.environment || 'unknown' }}
            </span>
            <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur text-sm font-semibold">
              <i class="bi bi-activity"></i>
              {{ $t('message.api_explorer.status') }}: {{ apiInfo.status || 'running' }}
            </span>
          </div>
        </div>
      </div>

      <!-- Summary Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <div class="flex items-center justify-between mb-2">
            <span class="text-sm font-semibold text-gray-500 dark:text-gray-300">{{ $t('message.api_explorer.total_available') }}</span>
            <i class="bi bi-unlock text-blue-500"></i>
          </div>
          <div class="text-3xl font-black text-gray-900 dark:text-white">{{ apiInfo.route_summary?.total_available || 0 }}</div>
        </div>
        <div class="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <div class="flex items-center justify-between mb-2">
            <span class="text-sm font-semibold text-gray-500 dark:text-gray-300">{{ $t('message.api_explorer.total_system') }}</span>
            <i class="bi bi-globe2 text-purple-500"></i>
          </div>
          <div class="text-3xl font-black text-gray-900 dark:text-white">{{ apiInfo.route_summary?.total_system || 0 }}</div>
        </div>
        <div class="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <div class="flex items-center justify-between mb-2">
            <span class="text-sm font-semibold text-gray-500 dark:text-gray-300">{{ $t('message.api_explorer.categories') }}</span>
            <i class="bi bi-folder2-open text-emerald-500"></i>
          </div>
          <div class="flex flex-wrap gap-2 mt-2">
            <span v-for="cat in apiInfo.route_summary?.categories || []" :key="cat"
              class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">
              <i class="bi bi-check-circle"></i>{{ cat }}
            </span>
          </div>
        </div>
      </div>

      <!-- Endpoints -->
      <div class="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <i class="bi bi-diagram-3 text-purple-500"></i>
            {{ $t('message.api_explorer.endpoints') }}
          </h3>
          <span class="text-sm text-gray-600 dark:text-gray-300">{{ endpointCountLabel }}</span>
        </div>

        <div v-if="endpointCategories.length === 0" class="text-gray-500 dark:text-gray-300 text-sm">
          {{ $t('message.api_explorer.no_endpoints') }}
        </div>

        <div v-else class="space-y-4">
          <div v-for="cat in endpointCategories" :key="cat.name" class="border border-gray-100 dark:border-slate-800 rounded-xl">
            <div class="flex items-center justify-between px-4 py-3 bg-gray-50 dark:bg-slate-800/70 rounded-t-xl cursor-pointer select-none"
              @click="toggleCategory(cat.name)">
              <div class="flex items-center gap-2">
                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-200 font-bold">
                  {{ cat.name[0]?.toUpperCase() || '?' }}
                </span>
                <div>
                  <div class="font-semibold text-gray-900 dark:text-white">{{ cat.name }}</div>
                  <div class="text-xs text-gray-500 dark:text-gray-400">{{ cat.countLabel }}</div>
                </div>
              </div>
              <ActionIconButton
                :icon="collapsed[cat.name] ? 'bi bi-chevron-down' : 'bi bi-chevron-up'"
                :title="collapsed[cat.name] ? 'Expand' : 'Collapse'"
                :aria-label="collapsed[cat.name] ? 'Expand' : 'Collapse'"
                tone="indigo"
                @click="toggleCategory(cat.name)"
              />
            </div>
            <transition name="collapse">
              <div class="divide-y divide-gray-100 dark:divide-slate-800" v-show="!collapsed[cat.name]">
                <div v-for="route in cat.routes" :key="route.key" class="px-4 py-3 flex flex-col gap-1.5">
                  <div class="flex items-center gap-3">
                    <span class="px-2 py-1 text-[11px] font-semibold rounded bg-blue-50 text-blue-700 dark:bg-blue-900/40 dark:text-blue-200">
                      {{ route.method || '—' }}
                    </span>
                    <div class="font-semibold text-gray-900 dark:text-white break-all">{{ route.path || route.key }}</div>
                  </div>
                  <div v-if="route.description && route.description !== (route.path || route.key)" class="text-sm text-gray-600 dark:text-gray-300">
                    {{ route.description }}
                  </div>
                </div>
              </div>
            </transition>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import ActionTextButton from '/vue/components/ActionTextButton.vue';
import ActionIconButton from '/vue/components/ActionIconButton.vue';
import LoginRequiredPrompt from '/vue/components/LoginRequiredPrompt.vue';
import { useApiExplorerPage } from '/vue/composables/useApiExplorerPage.js';

const {
  apiInfo,
  isLoading,
  errorMessage,
  collapsed,
  showLoginRequired,
  openLoginModal,
  loadApiInfo,
  endpointCategories,
  endpointCountLabel,
  toggleCategory
} = useApiExplorerPage();
</script>

<style scoped>
.collapse-enter-active,
.collapse-leave-active {
  transition: max-height 0.2s ease, opacity 0.2s ease;
}

.collapse-enter-from,
.collapse-leave-to {
  max-height: 0;
  opacity: 0;
}

.collapse-enter-to,
.collapse-leave-from {
  max-height: 500px;
  opacity: 1;
}
</style>
