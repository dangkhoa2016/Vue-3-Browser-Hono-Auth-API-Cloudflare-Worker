const { createApp } = Vue;
const { loadModule } = window['vue3-sfc-loader'];
import * as I18nModule from '/assets/js/i18n.js';
import * as AppServices from '/assets/js/appServices.js';
const { loadLanguageAsync, detectBrowserLanguage } = I18nModule;
const { setSfcOptions, setAppServices } = AppServices;

const SFC_CACHE_NAME = 'vue-sfc-cache-v2';

const options = {
  cacheName: SFC_CACHE_NAME,
  moduleCache: {
    vue: Vue,
    'vue-i18n': VueI18n,
    '/assets/js/i18n.js': I18nModule,
    // appServices must be in cache from the start so AsyncLoader.vue can import it via sfc-loader
    '/assets/js/appServices.js': AppServices,
  },
  async getFile(url) {
    let cache, cachedRes;

    const isDevMode = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    const resolvedUrl = new URL(url, window.location.href);
    const bypassCache = resolvedUrl.searchParams.has('__reload');

    if (window.caches && !isDevMode && !bypassCache) {
      cache = await caches.open(SFC_CACHE_NAME);
      cachedRes = await cache.match(url);
    }

    // Fallback to fetch if not cached, dev mode, or explicit reload.
    const res = cachedRes || await fetch(url, {
      cache: isDevMode || bypassCache ? 'no-store' : 'default'
    });
    if (!res.ok)
      throw Object.assign(new Error(res.status + ' ' + res.statusText + ' ' + url), { res });

    // Store successful response to Cache (needs clone() to be read later)
    if (cache && !cachedRes && !bypassCache) {
      cache.put(url, res.clone());
    }

    if (url.match(/\.(png|jpe?g|gif|svg|ico|webp)$/i)) {
      return {
        getContentData: (asBinary) => asBinary ? res.arrayBuffer() : `export default "${url}"`,
        type: '.mjs'
      }
    }

    return {
      getContentData: asBinary => asBinary ? res.arrayBuffer() : res.text(),
      type: url.endsWith('.js') ? '.mjs' : undefined
    }
  },
  addStyle(textContent) {
    const style = document.createElement('style');
    style.textContent = textContent;
    const ref = document.head.getElementsByTagName('style')[0] || null;
    document.head.insertBefore(style, ref);
  }
};

// Register sfc-loader options via appServices so all modules can access via getSfcOptions().
// Must be called before initMainApp() because router.js uses getSfcOptions() at module load time.
setSfcOptions(options);

// Main App Logic
async function initMainApp() {
  const { createPinia } = Pinia;

  // Populate module cache BEFORE importing router.js.
  // router.js uses a top-level await to load AsyncLoader.vue via loadModule(),
  // so the cache must have vue-router/pinia/axios entries ready at that point.
  options.moduleCache['vue-router'] = VueRouter;
  options.moduleCache['pinia'] = Pinia;
  options.moduleCache['axios'] = window.axios;

  // Load modules dynamically
  const routerModule = await import('/assets/js/router.js');
  const apiModule = await import('/assets/js/api.js');
  const authStoreModule = await import('/assets/js/stores/authStore.js');
  const modalStoreModule = await import('/assets/js/stores/modalStore.js');
  const { router } = routerModule;
  const { setupMock } = apiModule;

  // Register remaining module instances so sfc-loader uses the same singletons
  options.moduleCache['/assets/js/router.js'] = routerModule;
  options.moduleCache['/assets/js/api.js'] = apiModule;
  options.moduleCache['/assets/js/stores/authStore.js'] = authStoreModule;
  options.moduleCache['/assets/js/stores/modalStore.js'] = modalStoreModule;

  // Two more, and they are not interchangeable with `api.js` above. The settings page reaches the
  // endpoint preference through `mainStore`, which imports the HTTP client *directly* rather than
  // through the barrel, and the HTTP client is the module that owns the API identity — the singleton
  // the auth store subscribes to in order to drop a session when the server changes (F03).
  //
  // Any module a `.vue` file imports by URL is a *second evaluation* of that module unless the
  // instance the app already loaded is handed to the loader here, and a second evaluation is a second
  // identity singleton: it holds its own listeners and its own `currentIdentity`. With two of them,
  // saving a new endpoint wrote the shared storage keys and notified nobody, so the old tab kept its
  // session and the guarantee that a credential issued by one server is never sent to another did not
  // hold. The symptom was invisible in the request log, because both copies write the same keys.
  const httpClientModule = await import('/assets/js/api/httpClient.js');
  const mainStoreModule = await import('/assets/js/stores/mainStore.js');
  options.moduleCache['/assets/js/api/httpClient.js'] = httpClientModule;
  options.moduleCache['/assets/js/stores/mainStore.js'] = mainStoreModule;

  // Lazy SFC stores import these stateful modules directly. Give the loader the native
  // instances before any consumer mounts, so session fences and protected resets agree.
  for (const path of [
    '/assets/js/api/apiIdentity.js',
    '/assets/js/api/protectedState.js',
    '/assets/js/api/sessionCoordinator.js',
    '/assets/js/api/sessionStorage.js',
    '/assets/js/appServices.js'
  ]) options.moduleCache[path] = await import(path);


  try {
    const App = await loadModule('/vue/App.vue', options);
    const app = createApp(App);
    const pinia = createPinia();
    app.use(pinia);
    app.use(router);
    app.use(window.i18nInstance);

    const { useAuthStore } = authStoreModule;
    const { useModalStore } = modalStoreModule;
    const toastStoreModule = await import('/assets/js/stores/toastStore.js');
    options.moduleCache['/assets/js/stores/toastStore.js'] = toastStoreModule;

    // Register store instances via appServices (replaces window.authStore/modalStore/toastStore).
    // Must be called before app.mount() so post-mount component code can safely call getAuthStore() etc.
    setAppServices({
      authStore: useAuthStore(pinia),
      modalStore: useModalStore(pinia),
      toastStore: toastStoreModule.useToastStore(pinia),
    });

    // Enable detailed DevTools locally to trace performance issues
    const isDevMode = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    if (isDevMode) {
      app.config.devtools = true;
      app.config.performance = true;
    }

    // Catch unhandled Vue component errors globally so they don't silently disappear
    app.config.errorHandler = (err, _instance, info) => {
      console.error('[Vue] Unhandled error in', info, err);
      AppServices.getToastStore()?.error?.(`An unexpected error occurred: ${err.message || 'Check console'}`);
    };

    // Warning handler for missing properties or deprecations
    app.config.warnHandler = (msg, _instance, trace) => {
      console.warn('[Vue Warn]', msg, trace);
    };

    // Default to mock API
    setupMock(true);

    app.mount('#app');
    return true;
  } catch (err) {
    console.log("Failed to load main app:", err);
    const loaderEl = document.getElementById('loader');
    if (loaderEl) {
      loaderEl.innerHTML = `
        <div class="error-modal-overlay">
          <div class="error-modal-content">
            <h2 class="error-modal-title">Application Error</h2>
            <p class="error-modal-text">Failed to load the main application.</p>
            <div class="error-modal-details">
              ${err.message}
            </div>
            <button onclick="location.reload()" class="error-modal-button">Retry</button>
          </div>
        </div>
      `;
    }

    return false;
  }
}

// Expose initMainApp globally so Loader.vue can call it
window.initMainApp = initMainApp;

// Initialize Loader
(async () => {
  try {
    // Detect and load initial language BEFORE mounting loader
    const initialLang = detectBrowserLanguage();
    await loadLanguageAsync(initialLang);

    const Loader = await loadModule('/vue/Loader.vue', options);
    const loaderApp = createApp(Loader);

    // Use i18n in loaderApp
    loaderApp.use(window.i18nInstance);

    loaderApp.mount('#loader');
  } catch (err) {
    console.error("Failed to load loader component:", err);
    document.body.innerHTML = `
      <div class="error-modal-overlay">
        <div class="error-modal-content">
          <h2 class="error-modal-title">System Error</h2>
          <p class="error-modal-text">Failed to initialize application loader.</p>
          <div class="error-modal-details">
            ${err.message}
          </div>
          <button onclick="location.reload()" class="error-modal-button">Retry</button>
        </div>
      </div>
    `;
  }
})();
