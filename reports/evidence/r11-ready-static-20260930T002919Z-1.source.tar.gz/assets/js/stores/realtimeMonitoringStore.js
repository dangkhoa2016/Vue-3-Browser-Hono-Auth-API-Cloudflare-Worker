const { defineStore } = Pinia;
import { DEFAULT_ADMIN_PAGE_SIZE, resolveAdminPageSize } from '../constants/pagination.js';
import {
  apiClient,
  API_ENDPOINTS,
  buildRealtimeMonitoringThreatResolveEndpoint,
  buildRealtimeMonitoringAlertRuleToggleEndpoint
} from '../api.js';
import { getToastStore } from '../appServices.js';
import {
  API_ERROR_CODES,
  CAPABILITY_KEYS,
  createUnsupportedError,
  isCapabilitySupported,
  isUnsupportedError,
  readCapability,
  mergeCapabilityMap,
  readErrorCode
} from '../api/backendContract.js';
import { i18n } from '../i18n.js';
import { useMainStore } from './mainStore.js';

const getDefaultAdminLimit = () => {
  try {
    const mainStore = useMainStore();
    return resolveAdminPageSize(mainStore.adminPageSize, DEFAULT_ADMIN_PAGE_SIZE);
  } catch (error) {
    return DEFAULT_ADMIN_PAGE_SIZE;
  }
};

export const useRealtimeMonitoringStore = defineStore('realtimeMonitoring', {
  state: () => ({
    timestamp: null,
    status: null,
    overview: null,
    realtime: null,
    users: null,
    security: null,
    performance: null,
    metadata: null,
    liveDashboard: null,
    recentEvents: {
      count: 0,
      events: []
    },
    threats: {
      activeThreats: [],
      resolvedThreats: [],
      recentThreats: []
    },
    alertsStatus: null,
    alertsHistory: {
      alerts: [],
      pagination: { page: 1, limit: getDefaultAdminLimit(), total: 0, totalPages: 1 }
    },
    alertsRules: null,
    alertsRulesLoading: false,
    alertChannels: null,
    timeline: { points: [] },
    health: null,
    latestAnalysis: null,
    latestSimulation: null,
    latestIncident: null,
    statusRequestedOnce: false,
    capabilities: null,
    monitoringUnsupportedCode: null,
    exportUnsupportedCode: null,
    loading: false,
    actionLoading: false,
    error: null,
    lastUpdated: null
  }),

  getters: {
    activeThreatCount: (state) => {
      if (typeof state.threats?.activeThreatsCount === 'number') return state.threats.activeThreatsCount;
      if (Array.isArray(state.threats?.activeThreats)) return state.threats.activeThreats.length;
      return 0;
    },
    resolvedThreatCount: (state) => {
      if (typeof state.threats?.resolvedThreatsCount === 'number') return state.threats.resolvedThreatsCount;
      if (Array.isArray(state.threats?.resolvedThreats)) return state.threats.resolvedThreats.length;
      return 0;
    },
    alertsCount: (state) => {
      if (typeof state.alertsStatus?.activeAlerts === 'number') return state.alertsStatus.activeAlerts;
      if (Array.isArray(state.alertsHistory?.alerts)) return state.alertsHistory.alerts.length;
      return 0;
    },
    isMonitoringActive: (state) => Boolean(
      state.status?.isActive
      ?? state.status?.monitoringActive
      ?? state.status?.monitoring?.active
      ?? state.realtime?.isActive
      ?? state.overview?.monitoringActive
    ),
    isContinuousMonitoringSupported: (state) => isCapabilitySupported(state.capabilities, CAPABILITY_KEYS.CONTINUOUS_MONITORING),
    isContinuousMonitoringConfirmed: (state) => readCapability(state.capabilities, CAPABILITY_KEYS.CONTINUOUS_MONITORING) !== null
  },

  actions: {
    captureCapabilities(payload) {
      this.capabilities = mergeCapabilityMap(this.capabilities, payload);
      return this.capabilities;
    },

    normalizeError(err) {
      return err?.response?.data?.message
        || err?.response?.data?.error
        || err?.message
        || i18n.global.t('message.errors.unknown_error');
    },

    showSuccessToast(message) {
      if (!message) {
        return;
      }

      const toastStore = getToastStore();
      if (toastStore?.success) {
        toastStore.success(message);
      }
    },

    async fetchRecentEvents() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_EVENTS_RECENT);
        const payload = response?.data?.data || {};
        const events = Array.isArray(payload.events) ? payload.events : [];

        this.recentEvents = {
          count: Number(payload.count) || events.length,
          events
        };
        this.lastUpdated = new Date().toISOString();
        return this.recentEvents;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async fetchMonitoringStatus() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_STATUS);
        this.captureCapabilities(response?.data);
        const payload = response?.data?.data || {};
        const resolvedIsActive = typeof payload?.isActive === 'boolean'
          ? payload.isActive
          : (typeof payload?.monitoring?.active === 'boolean' ? payload.monitoring.active : undefined);

        this.status = {
          ...(this.status || {}),
          ...(payload && typeof payload === 'object' ? payload : {}),
          ...(typeof resolvedIsActive === 'boolean' ? { isActive: resolvedIsActive } : {})
        };

        if (typeof resolvedIsActive === 'boolean') {
          this.realtime = {
            ...(this.realtime || {}),
            isActive: resolvedIsActive
          };
        }

        this.lastUpdated = new Date().toISOString();
        return this.status;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async fetchThreats() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_THREATS);
        const payload = response?.data?.data || {};
        this.threats = {
          ...(this.threats || {}),
          ...(payload && typeof payload === 'object' ? payload : {})
        };
        this.lastUpdated = new Date().toISOString();
        return this.threats;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async resolveThreat(threatId, payload = {}) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(
          buildRealtimeMonitoringThreatResolveEndpoint(threatId),
          payload
        );

        try {
          await this.fetchThreats();
        } catch (_error) {
        }

        this.lastUpdated = new Date().toISOString();
        return response?.data || null;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    applySnapshot(snapshot = {}) {
      if (!snapshot || typeof snapshot !== 'object') {
        return;
      }

      if (snapshot.timestamp) {
        this.timestamp = snapshot.timestamp;
      }

      if (snapshot.status) {
        this.status = snapshot.status;
      }
      if (snapshot.overview) {
        this.overview = snapshot.overview;
      }
      if (snapshot.realtime) {
        this.realtime = snapshot.realtime;
      }
      if (snapshot.threats) {
        this.threats = snapshot.threats;
      }
      if (snapshot.alertsStatus) {
        this.alertsStatus = snapshot.alertsStatus;
      }
      if (snapshot.alertsHistory) {
        this.alertsHistory = snapshot.alertsHistory;
      }
      if (snapshot.timeline) {
        this.timeline = snapshot.timeline;
      }
      if (snapshot.health) {
        this.health = snapshot.health;
      }
      if (snapshot.users) {
        this.users = snapshot.users;
      }
      if (snapshot.security) {
        this.security = snapshot.security;
      }
      if (snapshot.metadata) {
        this.metadata = snapshot.metadata;
      }
    },

    async fetchDashboardData() {
      this.loading = true;
      this.error = null;

      try {
        const [
          statusRes,
          overviewRes,
          realtimeRes,
          threatsRes,
          alertsStatusRes,
          alertsHistoryRes,
          timelineRes,
          healthRes
        ] = await Promise.all([
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_STATUS),
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_OVERVIEW),
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_REALTIME),
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_THREATS),
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_STATUS),
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_HISTORY),
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_TIMELINE),
          apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_HEALTH)
        ]);

        const statusPayload = statusRes?.data?.data || {};
        const overviewPayload = overviewRes?.data?.data || null;
        const realtimePayload = realtimeRes?.data?.data || {};
        const threatsPayload = threatsRes?.data?.data || this.threats;
        const alertsStatusPayload = alertsStatusRes?.data?.data || null;
        const alertsHistoryPayload = alertsHistoryRes?.data?.data || this.alertsHistory;
        const timelinePayload = timelineRes?.data?.data || this.timeline;
        const healthPayload = healthRes?.data?.data || null;

        const resolvedIsActive = typeof statusPayload?.isActive === 'boolean'
          ? statusPayload.isActive
          : (typeof statusPayload?.monitoring?.active === 'boolean' ? statusPayload.monitoring.active : undefined);

        this.status = {
          ...(this.status || {}),
          ...(statusPayload && typeof statusPayload === 'object' ? statusPayload : {}),
          ...(typeof resolvedIsActive === 'boolean' ? { isActive: resolvedIsActive } : {})
        };

        this.overview = overviewPayload;
        this.threats = threatsPayload;
        this.alertsStatus = alertsStatusPayload;
        this.alertsHistory = alertsHistoryPayload;
        this.timeline = timelinePayload;
        this.health = healthPayload;

        if (realtimePayload && realtimePayload.overview && realtimePayload.timeline && realtimePayload.users && realtimePayload.security) {
          this.applySnapshot(realtimePayload);
        } else if (
          realtimePayload.status ||
          realtimePayload.overview ||
          realtimePayload.realtime ||
          realtimePayload.threats ||
          realtimePayload.alertsStatus ||
          realtimePayload.alertsHistory ||
          realtimePayload.timeline ||
          realtimePayload.health
        ) {
          this.applySnapshot(realtimePayload);
        } else {
          this.realtime = realtimePayload;
        }

        if (typeof resolvedIsActive === 'boolean') {
          this.realtime = {
            ...(this.realtime || {}),
            isActive: resolvedIsActive
          };
        }

        this.lastUpdated = new Date().toISOString();
      } catch (error) {
        this.error = this.normalizeError(error);
      } finally {
        this.loading = false;
      }
    },

    async startMonitoring(intervalMs = 5000, enableThreatDetection = true) {
      this.actionLoading = true;
      this.error = null;
      this.monitoringUnsupportedCode = null;

      if (!isCapabilitySupported(this.capabilities, CAPABILITY_KEYS.CONTINUOUS_MONITORING)) {
        this.monitoringUnsupportedCode = API_ERROR_CODES.UNSUPPORTED_MONITORING_MODE;
        this.actionLoading = false;

        throw createUnsupportedError(API_ERROR_CODES.UNSUPPORTED_MONITORING_MODE, {
          capability: CAPABILITY_KEYS.CONTINUOUS_MONITORING,
          status: 422
        });
      }

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_START, {
          intervalMs,
          enableThreatDetection
        });
        this.captureCapabilities(response?.data);
        const payload = response?.data?.data || {};
        const confirmedActive = typeof payload?.isActive === 'boolean'
          ? payload.isActive
          : (typeof payload?.monitoring?.active === 'boolean' ? payload.monitoring.active : null);

        this.status = {
          ...(this.status || {}),
          ...(payload && typeof payload === 'object' ? payload : {}),
          ...(confirmedActive === null ? {} : { isActive: confirmedActive })
        };

        if (!this.realtime || typeof this.realtime !== 'object') {
          this.realtime = {};
        }
        this.realtime = {
          ...this.realtime,
          ...(confirmedActive === null ? {} : { isActive: confirmedActive }),
          lastUpdated: payload?.startedAt || new Date().toISOString()
        };
        this.lastUpdated = new Date().toISOString();
        return response?.data || null;
      } catch (error) {
        if (isUnsupportedError(error)) {
          this.monitoringUnsupportedCode = API_ERROR_CODES.UNSUPPORTED_MONITORING_MODE;
          this.error = this.normalizeError(error);
          return null;
        }

        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async stopMonitoring() {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_STOP, {});
        const payload = response?.data?.data || {};
        this.status = {
          ...(this.status || {}),
          ...(payload && typeof payload === 'object' ? payload : {}),
          isActive: typeof payload?.isActive === 'boolean' ? payload.isActive : false
        };

        if (!this.realtime || typeof this.realtime !== 'object') {
          this.realtime = {};
        }
        this.realtime = {
          ...this.realtime,
          isActive: false,
          lastUpdated: new Date().toISOString()
        };
        this.lastUpdated = new Date().toISOString();
        return response?.data || null;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async analyzeThreats(hours = 1) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_ANALYZE, { hours });
        this.showSuccessToast(response?.data?.message);
        this.latestAnalysis = response?.data?.data || null;

        if (this.latestAnalysis && typeof this.latestAnalysis === 'object') {
          const threatsDetected = Number(this.latestAnalysis.threatsDetected);
          const anomalies = Number(this.latestAnalysis.anomalies);

          if (!Number.isNaN(threatsDetected)) {
            this.overview = {
              ...(this.overview || {}),
              threatsDetected
            };
          }

          if (!Number.isNaN(anomalies)) {
            this.overview = {
              ...(this.overview || {}),
              anomaliesDetected: anomalies
            };
          }

          if (this.latestAnalysis.generatedAt) {
            this.realtime = {
              ...(this.realtime || {}),
              lastUpdated: this.latestAnalysis.generatedAt
            };
          }
        }

        this.lastUpdated = new Date().toISOString();
        return this.latestAnalysis;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async simulateEvent(payload = { eventType: 'test_event', data: { test: true } }) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_SIMULATE, payload);
        this.showSuccessToast(response?.data?.message);
        this.latestSimulation = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.latestSimulation;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async configureAlerts(payload = {}) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_CONFIGURE, payload);
        this.alertsStatus = response?.data?.data || this.alertsStatus;
        this.lastUpdated = new Date().toISOString();
        return this.alertsStatus;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async fetchAlertsHistory(filters = {}) {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_HISTORY, {
          params: filters
        });
        this.alertsHistory = response?.data?.data || this.alertsHistory;
        this.lastUpdated = new Date().toISOString();
        return this.alertsHistory;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async sendManualAlert(payload = {}) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_SEND, payload);

        try {
          await Promise.all([
            this.fetchAlertsHistory(),
            this.fetchMonitoringStatus()
          ]);
        } catch (_error) {
        }

        this.lastUpdated = new Date().toISOString();
        return response?.data || null;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async fetchAlertRules() {
      this.alertsRulesLoading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_RULES);
        this.alertsRules = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.alertsRules;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.alertsRulesLoading = false;
      }
    },

    async createAlertRule(payload = {}) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_RULES, payload);
        const result = response?.data || null;

        this.showSuccessToast(result?.message);

        try {
          await this.fetchAlertRules();
        } catch (_error) {
        }

        this.lastUpdated = new Date().toISOString();
        return result;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async toggleAlertRule(ruleId, enabled) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.put(
          buildRealtimeMonitoringAlertRuleToggleEndpoint(ruleId),
          { enabled }
        );

        try {
          await this.fetchAlertRules();
        } catch (_error) {
        }

        this.lastUpdated = new Date().toISOString();
        return response?.data || null;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async fetchAlertChannels() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_CHANNELS);
        this.alertChannels = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.alertChannels;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async createAlertChannel(payload = {}) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_CHANNELS, payload);
        const result = response?.data || null;

        this.showSuccessToast(result?.message);

        try {
          await this.fetchAlertChannels();
        } catch (_error) {
        }

        this.lastUpdated = new Date().toISOString();
        return result;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async testAlertSystem() {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_ALERTS_TEST, {});
        const result = response?.data || null;
        const systemStatus = result?.data?.systemStatus || {};

        if (systemStatus.rules) {
          this.alertsRules = systemStatus.rules;
        }

        if (systemStatus.channels) {
          this.alertChannels = systemStatus.channels;
        }

        this.showSuccessToast(result?.message);
        this.lastUpdated = new Date().toISOString();
        return result;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async fetchDashboardOverview() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_OVERVIEW);
        this.overview = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.overview;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async fetchLiveDashboard() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_LIVE);
        const payload = response?.data?.data || {};
        this.liveDashboard = payload;

        if (payload && typeof payload === 'object' && (payload.overview || payload.timeline || payload.users || payload.security)) {
          this.applySnapshot(payload);
        }

        this.lastUpdated = new Date().toISOString();
        return this.liveDashboard;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async fetchDashboardTimeline(hours = 24) {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_TIMELINE, {
          params: { hours }
        });
        this.timeline = response?.data?.data || this.timeline;
        this.lastUpdated = new Date().toISOString();
        return this.timeline;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async fetchSecurityDashboard() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_SECURITY);
        this.security = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.security;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async fetchPerformanceDashboard(options = {}) {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_PERFORMANCE);
        if (options?.showToast) {
          this.showSuccessToast(response?.data?.message);
        }
        this.performance = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.performance;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async exportDashboard(options = {}) {
      this.actionLoading = true;
      this.error = null;

      try {
        const format = String(options.format || 'json').toLowerCase();
        const timeRange = options.timeRange || 'last_24h';
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_EXPORT, {
          format,
          timeRange
        });

        const payload = response?.data;
        const metadata = payload?.data?.metadata || payload?.metadata || {};
        const fileMeta = payload?.meta || {};
        const content = payload?.data;

        const failureEnvelope = payload?.success === false
          || Boolean(payload?.error)
          || Boolean(payload?.data?.error)
          || Boolean(readErrorCode(payload));

        if (failureEnvelope) {
          this.exportUnsupportedCode = isUnsupportedError(payload)
            ? API_ERROR_CODES.UNSUPPORTED_EXPORT_OPTION
            : null;
          this.error = this.normalizeError({ response: { data: payload } });
          return null;
        }

        if (content === null || content === undefined || (typeof content === 'object' && !Array.isArray(content) && Object.keys(content).length === 0)) {
          this.error = this.normalizeError({ response: { data: { error: { message: 'Export returned no data' } } } });
          return null;
        }

        let fileContent = '';
        let mimeType = 'application/json;charset=utf-8';
        let extension = format === 'csv' ? 'csv' : 'json';

        if (format === 'csv' && typeof content === 'string') {
          fileContent = content;
          mimeType = 'text/csv;charset=utf-8';
        } else {
          fileContent = JSON.stringify(content, null, 2);
          mimeType = 'application/json;charset=utf-8';
          extension = 'json';
        }

        const filename = fileMeta?.filename || metadata?.filename || `realtime-monitoring-${Date.now()}.${extension}`;
        if (typeof fileMeta?.contentType === 'string' && fileMeta.contentType.trim()) {
          mimeType = fileMeta.contentType;
        }
        const blob = new Blob([fileContent], { type: mimeType });
        const url = window.URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = filename;
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        window.URL.revokeObjectURL(url);

        this.lastUpdated = new Date().toISOString();
        return payload;
      } catch (error) {
        if (isUnsupportedError(error)) {
          this.exportUnsupportedCode = API_ERROR_CODES.UNSUPPORTED_EXPORT_OPTION;
        }
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async clearDashboardCache(key = null) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.delete(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_CACHE, {
          params: key ? { key } : {}
        });
        this.showSuccessToast(response?.data?.message);
        this.lastUpdated = new Date().toISOString();
        return response?.data || null;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async fetchDashboardHealth() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_HEALTH);
        this.health = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.health;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.loading = false;
      }
    },

    async createIncident(payload = {}) {
      this.actionLoading = true;
      this.error = null;

      try {
        const response = await apiClient.post(API_ENDPOINTS.REALTIME_MONITORING_INCIDENTS_CREATE, payload);
        this.showSuccessToast(response?.data?.message);
        this.latestIncident = response?.data?.data || null;
        this.lastUpdated = new Date().toISOString();
        return this.latestIncident;
      } catch (error) {
        this.error = this.normalizeError(error);
        return null;
      } finally {
        this.actionLoading = false;
      }
    },

    async reload() {
      await this.fetchMonitoringStatus();
      await this.refreshSnapshot();
    },

    async refreshSnapshot() {
      this.loading = true;
      this.error = null;

      try {
        const response = await apiClient.get(API_ENDPOINTS.REALTIME_MONITORING_DASHBOARD_REALTIME);
        const payload = response?.data?.data || {};

        // New server payload shape
        if (payload.overview && payload.timeline && payload.users && payload.security) {
          this.applySnapshot(payload);
          this.timeline = payload.timeline;
          this.liveDashboard = payload;
        } else if (
          payload.status ||
          payload.overview ||
          payload.realtime ||
          payload.threats ||
          payload.alertsStatus ||
          payload.alertsHistory ||
          payload.timeline ||
          payload.health
        ) {
          this.applySnapshot(payload);
          this.liveDashboard = payload;
        } else {
          this.realtime = payload;
          this.liveDashboard = payload;
          if (typeof payload?.isActive === 'boolean') {
            this.status = {
              ...(this.status || {}),
              isActive: payload.isActive
            };
          }
        }

        this.lastUpdated = new Date().toISOString();
      } catch (error) {
        this.error = this.normalizeError(error);
      } finally {
        this.loading = false;
      }
    }
  }
});
