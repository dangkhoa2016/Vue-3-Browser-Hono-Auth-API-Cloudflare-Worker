# Frontend Execution Log — frontend-remediation-r9

Cwd `/content/frontend-r9-work`, branch `remediation/round6-wip`, `head=a1db43b7e432795c41c727324d87c66f63c22cbb`.
node v20.19.0, npm 10.8.2, Playwright 1.56.1, git 2.43.0, Linux x86_64. **Chưa commit** — xem handoff §2.

`head` ở trên là identity *Git*, không phải identity *nội dung*. Nội dung mỗi run thật nằm trong
`source_digest` của chính `.meta` của run đó, và bốn run R9 đều là
`94c04d16e89d5439a5b512a845d6365a9d677fac90f1fd8cede4f644c9c13cb1` với `source_drift: none`.

## Task1 — Intake, restore, baseline

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `sha256sum /content/sample_data/frontend-remediation-r8-review-package.zip` | 0 | `9830aac7…d32f1` |
| 2 | inventory ZIP (1136 members) | 0 | 0 absolute / traversal / symlink / special / duplicate |
| 3 | `sha256sum -c MANIFEST.sha256` | 0 | 822 payload files |
| 4 | `git bundle verify` + `git fsck --full` | 0 | HEAD `a1db43b`, tree `55033e4`, 98 commits |
| 5 | extract preserving ZIP modes (không dùng `ZipFile.extractall`) | 0 | `extractall` làm mất executable bit |
| 6 | overlay 12 tracked modifications + 13 untracked + `reports/` | 0 | khớp inventory §1 của plan R9 |
| 7 | `git diff --check` | 0 | sạch |
| 8 | `npm --prefix tests ci --ignore-scripts` | 0 | |
| 9 | `npm --prefix tests run test:static` | 0 | baseline R8 |
| 10 | `npm --prefix tests run test:unit` | 0 | baseline R8: 270 tests / 269 pass / 1 skip |
| 11 | `npm --prefix tests run test:loopback` | 0 | 8/8 |
| 12 | `npx playwright test --list` | 0 | **36 tests / 4 files** — thiếu seed smoke, xem Task2 |

Cột "Exit" ở #9–#12 là exit của producer khi chạy trực tiếp để lấy baseline, không phải qua gate wrapper.

## Task2 — FR10-01: discovery không được bỏ suite

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `node --test tests/regression/browser-discovery.test.mjs` | 0 | 6/6 |
| 2 | mutation: đổi matcher về `session-seed-smock` | 1 | test đỏ đúng kỳ vọng, chứng minh test bắt được typo |
| 3 | khôi phục matcher | 0 | |
| 4 | `npx playwright test --list` | 0 | **38 tests / 5 files**, gồm 2 case `session-seed-smoke` |
| 5 | `npx playwright test --list session-seed-smoke` | 0 | 2 tests, không phải 0 |

## Task3 — FR10-02: validator ràng buộc claim với run/source/tier

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `node --test tests/regression/validate-reports.test.mjs` | 1 | RED: probe fixture của review trả `problems=[]` |
| 2 | `node --test tests/regression/source-identity.test.mjs` | 0 | 15/15 |
| 3 | validator + suite sau khi viết lại | 0 | 39/39, gồm fixture thật của review trong `tools/../` |
| 4 | `node tools/validate-reports.mjs --mode draft` | 1 | 8 problem: FR10-01…08 chưa có row |
| 5 | thêm 8 row FR10 vào matrix | 1 | 1 problem: row FR10-07 trỏ file chưa tồn tại — validator đúng |
| 6 | sửa row FR10-07 trỏ `tools/run-browser-gate.sh` | 0 | 22 rows, 0 problem |
| 7 | `node tools/frontend-run-claims.mjs --all` | 0 | 32 run khai báo, 3 artefact bị bỏ qua (không có manifest) |
| 8 | copy `evidence/r8/` của R8 package vào `reports/evidence/` | 0 | 113 file, để citation mang sang R9 resolve được |
| 9 | `node --test tests/regression/*.test.mjs` | 0 | 290/290, 0 skip (skip của R8 nay chạy thật) |

`--allow-problems` **không** được dùng ở bất kỳ bước nào. Ba artefact bị bỏ qua là
`baseline-browser-20260928T011842Z` (lần chạy tay trước khi có identity wrapper), được báo ra tường minh
thay vì khai báo bằng số bịa.

## FR10-01 runtime — browser trên một source identity

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `tools/run-frontend-gate.sh --label r9-browser -- npm run test:browser` | 0 | **38/38**, 12.9m, drift `none` |

Chạy qua `run-frontend-gate.sh`, **không** qua `tools/run-browser-gate.sh`: wrapper đó `rm -rf` một
scratch root dùng chung và luôn ghi `.install-ok` cho install nó không kiểm — đúng FR10-07, và review
cấm chạy nó trên máy reviewer. Sửa wrapper là Task7.

## Gate R9

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `tools/run-frontend-gate.sh --label r9-static -- npm run test:static` | 1 | run đầu: reports chưa có row FR10 |
| 2 | `tools/run-frontend-gate.sh --label r9-unit -- npm run test:unit` | 0 | 290/290 |
| 3 | `tools/run-frontend-gate.sh --label r9-loopback -- npm run test:loopback` | 0 | 8/8 |
| 4 | `tools/run-frontend-gate.sh --label r9-static -- npm run test:static` | 0 | 12/12 CDN pin, validator xanh |
| 5 | `tools/frontend-run-claims.mjs --all` | 0 | sidecar sinh lại sau khi handoff thay đổi |
| 6 | `node tools/validate-reports.mjs --mode draft` | 0 | 22 rows, 133 evidence files, 32 run claims |

Run `r9-static-20260928T081737Z-1` exit 1 được giữ lại, không xóa. Sidecar khai báo nó, validator báo
warning, và không report nào trích dẫn nó làm bằng chứng cho một gate xanh. Đó là điểm của việc giữ.

## Vòng gate cuối (sau khi văn bản report đã ổn định)

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `tools/run-frontend-gate.sh --label r9-final-unit -- npm run test:unit` | 0 | 291/291, 0 skip |
| 2 | `tools/run-frontend-gate.sh --label r9-final-loopback -- npm run test:loopback` | 0 | 8/8 |
| 3 | `tools/run-frontend-gate.sh --label r9-final-static -- npm run test:static` | 0 | validator xanh |
| 4 | `node tools/frontend-run-claims.mjs --all` | 0 | sidecar sinh lại sau khi handoff trỏ run cuối |
| 5 | `node tools/validate-reports.mjs --mode draft` | 0 | 22 rows, 0 problem |

Ba run cuối cùng content digest `74deaf79…`, `source_drift: none`. Run browser **không** chạy lại ở vòng
này: các file nó nạp giống hệt byte, chỉ digest toàn cây đổi vì `tools/` và `tests/regression/` đã đổi.
Task12 chạy lại browser trên cây cuối, và khi đó mọi run sẽ cùng một digest.

Số test unit đi 270 (R8) → 290 → 291: `browser-discovery.test.mjs` +6, `validate-reports.test.mjs`
+40, `source-identity.test.mjs` +2, và 1 test vốn bị skip ở R8 (real-report validation) nay chạy thật
và xanh. Không có test nào bị xóa; chênh lệch là cộng thêm, và cả ba đều nằm trong
`reports/FRONTEND-FINDING-MATRIX.tsv`.

---

# Frontend Execution Log — frontend-remediation-r7

Source identity cho mọi lệnh dưới đây (trừ khi ghi khác):
`branch=remediation/round6-wip head=a1db43b7e432795c41c727324d87c66f63c22cbb tree=55033e41514957bbd7c13289661018aa6980a91c`
Cwd `/tmp/opencode/r7/repo`, node v20.19.0, npm 10.8.2, git 2.43.0, Linux x86_64, Ubuntu 24.04.

## Task1 — Intake, restore, evidence harness

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `sha256sum r6-task7-full.zip` | 0 | `bfdc3b49…7504` khớp §1 |
| 2 | python3 zipfile inventory (478 entries) | 0 | 0 absolute / traversal / backslash / symlink / duplicate; entries ở root |
| 3 | `unzip -q … -d /tmp/opencode/r7/artifact` | 0 | explicit destination; `cd r6-task7-full` sẽ hỏng (FA8-07) |
| 4 | `sha256sum -c --quiet MANIFEST.sha256` | 0 | 321 entries |
| 5 | `git clone --no-checkout --branch remediation/round6-wip <bundle> repo` | 0 | HEAD `a1db43b`, tree `55033e4`, 98 HEAD / 117 all |
| 6 | `git bundle verify …` | 0 | complete history, 11 refs |
| 7 | `git fsck --full` | 0 | sạch |
| 8 | `git checkout remediation/round6-wip` | 0 | status sạch trước patch |
| 9 | `git apply --whitespace=error-all patches/working-tree-changes.patch` | 0 | 6 modified |
| 10 | `git apply patches/new-file-browser-fixture.patch` | 0 | 1 untracked |
| 11 | so sánh byte 293 file repo vs `source-tree/` | 0 | 293/293 khớp, 0 lệch, 0 chỉ-có-ở-một-bên |
| 12 | `git diff --check` | 0 | sạch |
| 13 | pre-work backup (2 bundle + 2 patch + untracked + 293 hash) | 0 | `/tmp/opencode/r7/prework/` |
| 14 | tạo `tools/run-frontend-gate.sh` (mới) | 0 | wrapper bằng chứng |
| 15 | wrapper self-test `exit 7` | 7 | exit của producer giữ nguyên |
| 16 | wrapper self-test timeout 2s | 124 | nonzero |
| 17 | wrapper self-test `--timeout 0` | 2 | reject trước khi chạy |
| 18 | wrapper self-test success | 0 | |
| 19 | `npm --prefix tests ci --ignore-scripts --no-audit --no-fund` | 0 | 30 packages |
| 20 | `npm --prefix tests run test:static` | 0 | 11/11 CDN pin exact |
| 21 | `npm --prefix tests run test:unit` | 0 | 188 pass / 0 fail / 0 cancelled / 0 skipped, 24 suites |
| 22 | `node --test regression/*.test.mjs` (discovery đối chiếu) | 0 | lần 1: 187 pass + **1 cancelled**; lần 2: 188 pass, 0 cancelled → R7-OBS-01 |
| 23 | `npm --prefix tests run test:loopback` | 0 | 8 pass / 0 fail |
| 24 | `npx --prefix tests playwright install chromium` | 0 | binary về `~/.cache/ms-playwright` |
| 25 | `chromium.launch()` probe | fail | thiếu libatk/atk-bridge/atspi/xcomposite |
| 26 | `apt-get install -y libatk1.0-0t64 libatk-bridge2.0-0t64 libatspi2.0-0t64 libxcomposite1 libasound2t64` | 0 | **có owner cho phép**; 9 gói mới, 0 upgrade, 0 remove |
| 27 | `chromium.launch()` probe lại | 0 | `LAUNCH OK 141.0.7390.37` |
| 28 | `npm --prefix tests run test:browser` | **0** | **32/32 pass (11.0m)** |

Ghi chú môi trường: bước 26 là thay đổi system **ngoài phạm vi dự án frontend**; đã hỏi owner và được
cho phép trong session này. Không có thay đổi nào khác ngoài `/tmp/opencode/r7/` và các gói apt nêu trên.

## Baseline numbers (đã tự chạy, không phải log của vòng trước)

| Gate | Exit | Kết quả |
| --- | --- | --- |
| static | 0 | 11/11 pins |
| unit | 0 | 188 / 0 / 0 / 0, 24 suites |
| loopback | 0 | 8 pass |
| browser | 0 | 32 pass |

## Task2..10

(chưa chạy — sẽ bổ sung theo từng task)

## Task2 (FA8-01) — CLOSED

| # | Lệnh | Exit | Kết quả |
| --- | --- | --- | --- |
| 1 | `npm --prefix tests run test:unit` (gates file) | 0 | **194/194** sau 3 case refresh-commit mới + refresh-lock-pin 3/3 |
| 2 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** — gồm FA8-01 two-tab case (roles đảo: arriving tab rotate, winner tab chờ) |
| 3 | mutation: release refresh lock trước commit | fail | node test 4/5 đỏ; browser đỏ tại assert winner 0 dispatch |

## Task3 (FA8-02) — CLOSED

| # | Lệnh | Exit | Kết quả |
| --- | --- | --- | --- |
| 1 | `npm --prefix tests run test:unit` (gates file) | 0 | **199/199** sau 4 subtest deadline mới |
| 2 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** |

## Task4 (FA8-03/04) — CLOSED

| # | Lệnh | Exit | Kết quả |
| --- | --- | --- | --- |
| 1 | `node --test regression/harness-boundaries.test.mjs` | 0 | 21/21 policy + typed-allowance case (RED khi allowlist chỉ origin: 4 đỏ; allowance không phân kind: 7 đỏ) |
| 2 | `npx playwright test -g "egress boundary"` | 0 | 2/2 — probe FA8-03 thành Image load thật, refused + count; mutation origin-only → đỏ |
| 3 | `npm --prefix tests run test:unit` (gates file) | 0 | **220/220** |
| 4 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** (12.1m) — đợt đầu 27 đỏ vì guard chặn font bootstrap-icons (đã thêm version-directory rule), 3 đỏ vì count kỳ vọng không khớp noise có điều kiện (đã hỗ trợ `[atLeast,atMost]`), sau đó sạch |
| 5 | `npm --prefix tests run test:unit` (gates file) | 0 | **220/220** — kèm FA8-02 follow-up (backstop 2×→min(8×,15s)) chạy 5/5 ổn định |
| 6 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** (11.9m) sau khi đổi backstop |

## Task5..10

(chưa chạy — sẽ bổ sung theo từng task)
