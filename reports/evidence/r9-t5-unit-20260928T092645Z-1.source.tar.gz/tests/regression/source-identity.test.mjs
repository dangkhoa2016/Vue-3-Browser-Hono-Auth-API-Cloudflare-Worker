/**
 * FR9-05 — the identity a gate run records has to be the *content* of the source, not its shape.
 *
 * The gate wrapper used to record `status_sha256`, the hash of `git status --porcelain`. That is a hash
 * of file *names*: it says which paths differ from HEAD and nothing about what is in them. So editing
 * the bytes of a file that is already `M` left the recorded identity untouched, and two runs against
 * different source carried the same identity — including a red run and a green one. An untracked
 * directory collapsed to a single `?? reports/` line, so everything underneath it was unnamed, and the
 * `tree=` field made it read like a precise answer while naming the *base* tree rather than the tree
 * that was tested.
 *
 * Every case below is therefore written as a pair: the same edit, observed through the old status hash
 * and through the content digest. Where the status hash does not move, that is the defect being pinned
 * shut — a test that only checked "the digest changed" would still pass if the digest were accidentally
 * constant.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import {
  chmodSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readlinkSync,
  rmSync,
  symlinkSync,
  utimesSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gunzipSync } from 'node:zlib';

import {
  IDENTITY_SCHEMA,
  buildManifest,
  buildSnapshot,
  collectSourcePaths,
  digestOf,
  splitUstarPath,
  symlinkTarget,
} from '../../tools/frontend-source-identity.mjs';

const TOOL = fileURLToPath(new URL('../../tools/frontend-source-identity.mjs', import.meta.url));

/** A throwaway repository shaped like this one: a committed baseline plus the dirty delta a round leaves. */
function makeRepo() {
  const repo = mkdtempSync(join(tmpdir(), 'frontend-identity-'));
  const git = (...args) => execFileSync('git', ['-C', repo, ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
  git('init', '--quiet');
  git('config', 'user.email', 'identity@example.test');
  git('config', 'user.name', 'identity');

  const write = (path, content, mode = 0o644) => {
    const absolute = join(repo, path);
    mkdirSync(dirname(absolute), { recursive: true });
    writeFileSync(absolute, content);
    chmodSync(absolute, mode);
  };

  write('index.html', '<script src="https://unpkg.com/vue@3.5.43/dist/vue.global.js"></script>\n');
  write('assets/js/api/sessionCoordinator.js', 'export const A = 1;\n');
  write('tests/regression/some.test.mjs', "import { test } from 'node:test';\n");
  write('tests/package.json', '{ "name": "verification" }\n');
  write('tests/package-lock.json', '{ "lockfileVersion": 3 }\n');
  write('reports/FRONTEND-HANDOFF.vi.md', 'handoff\n');
  git('add', '--all');
  git('commit', '--quiet', '-m', 'baseline');

  // The delta a remediation round actually leaves behind: a file already modified, new untracked
  // helpers, and a new evidence directory. The wrapper and the browser helper are *untracked* on
  // purpose — that is the shape R7 left, and an untracked file is the one `git status` names as a
  // single line no matter how much is under it.
  write('assets/js/api/sessionCoordinator.js', 'export const A = 2;\n');
  write('tests/browser/helpers/browser-fixture.mjs', 'export const guard = true;\n');
  write('tools/run-frontend-gate.sh', '#!/usr/bin/env bash\n# wrapper\n', 0o755);
  write('reports/evidence/old.log', 'previous run\n');
  return { repo, write, git };
}

/** The identity the R7 wrapper recorded: names, not content. */
const statusHash = (repo) => execFileSync('git', ['-C', repo, 'status', '--porcelain'], { encoding: 'utf8' });

const withRepo = (fn) => {
  const fixture = makeRepo();
  try {
    return fn(fixture);
  } finally {
    rmSync(fixture.repo, { recursive: true, force: true });
  }
};

test('editing the bytes of an already-modified file changes the identity, and the old status hash does not', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    const statusBefore = statusHash(repo);
    assert.match(statusBefore, /^ M assets\/js\/api\/sessionCoordinator\.js$/m,
      'the fixture really is a file that git already calls modified');

    write('assets/js/api/sessionCoordinator.js', 'export const A = 2; // one more byte\n');

    const after = buildManifest(repo);
    assert.equal(statusHash(repo), statusBefore,
      'this is the defect: the file was already M, so the status text — and its hash — cannot move');
    assert.notEqual(after.digest, before.digest,
      'the content digest has to move, because the source the next run would test is not the same source');
  });
});

test('the bytes of an untracked helper change the identity, even though the status names only its directory', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    // The whole untracked tree collapses to one line. Nothing in it is identified, which is the other
    // half of the same defect: `?? tools/` is equally true of a one-line wrapper and of a full suite.
    const statusBefore = statusHash(repo);
    assert.match(statusBefore, /^\?\? tools\/$/m);

    write('tools/run-frontend-gate.sh', '#!/usr/bin/env bash\n# a different wrapper\n', 0o755);

    const after = buildManifest(repo);
    assert.equal(statusHash(repo), statusBefore, 'the status line is unchanged, so the edit is not on the record');
    assert.notEqual(after.digest, before.digest);
  });
});

test('an executable bit is part of the identity', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    assert.equal(before.files.find((file) => file.path === 'tools/run-frontend-gate.sh').mode, '100755');

    write('tools/run-frontend-gate.sh', '#!/usr/bin/env bash\n# wrapper\n', 0o644);

    const after = buildManifest(repo);
    assert.equal(after.files.find((file) => file.path === 'tools/run-frontend-gate.sh').mode, '100644');
    assert.notEqual(after.digest, before.digest, 'losing the executable bit changes what the tool can do');
  });
});

test('adding and deleting a file both change the identity', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);

    write('tests/regression/harness-boundaries.test.mjs', "import { test } from 'node:test';\n");
    const added = buildManifest(repo);
    assert.notEqual(added.digest, before.digest);
    assert.ok(added.files.some((file) => file.path === 'tests/regression/harness-boundaries.test.mjs'));

    rmSync(join(repo, 'tests/regression/harness-boundaries.test.mjs'));
    const removed = buildManifest(repo);
    assert.notEqual(removed.digest, added.digest);
    assert.equal(removed.digest, before.digest, 'a deleted file puts the identity back where it was');
  });
});

test('the same tree produces the same digest however the filesystem feels about it', () => {
  withRepo(({ repo }) => {
    const first = buildManifest(repo);
    // Touching mtimes is what a checkout, a copy or a `touch` does, and none of it changes the source.
    for (const file of first.files) {
      const stamp = new Date(Date.UTC(1999, 0, 1));
      utimesSync(join(repo, file.path), stamp, stamp);
    }
    const second = buildManifest(repo);
    assert.equal(second.digest, first.digest, 'mtime is not identity');
    assert.deepEqual(second.files, first.files);
  });
});

test('evidence written by a run is outside the identity, so a run cannot invalidate its own record', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    // What the wrapper does after the producer finishes: a log, a manifest and a snapshot, all under
    // reports/evidence. If those were hashed, the digest would change the instant the run recorded it
    // and every run would read as having drifted from itself.
    write('reports/evidence/unit-20260928T000000Z.log', 'pass 220\n');
    write('reports/evidence/unit-20260928T000000Z.meta', 'exit: 0\n');
    write('reports/evidence/unit-20260928T000000Z.manifest.json', '{ "digest": "..." }\n');
    assert.equal(buildManifest(repo).digest, before.digest);
    assert.ok(!collectSourcePaths(repo).some((path) => path.startsWith('reports/evidence/')));
  });
});

test('the run-claims sidecar is outside the identity, so a run can be recorded against the tree it ran', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    // The sidecar declares each run's tier, exit code, counts and source digest, so it is written after
    // the runs it describes. If it were hashed, every run's digest would be a function of the previous
    // round's reporting and no run could ever match the tree that records it.
    write('reports/FRONTEND-RUN-CLAIMS.json', '{ "schema": "frontend-run-claims/1", "runs": [] }\n');
    assert.equal(buildManifest(repo).digest, before.digest);
    assert.ok(!collectSourcePaths(repo).includes('reports/FRONTEND-RUN-CLAIMS.json'));
  });
});

test('the reports prose is inside the identity, so editing a report moves the digest', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    // The sidecar is excluded because it is a record *about* runs. The prose is not: it is written by the
    // same hands as the code, and a digest that ignores it cannot tell two delivered trees apart.
    write('reports/FRONTEND-HANDOFF.vi.md', '# Handoff\n\n| unit | 314/314 |\n');
    assert.notEqual(buildManifest(repo).digest, before.digest);
  });
});

test('node_modules, git and the Playwright output directories are not source', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    write('tests/node_modules/playwright/index.js', 'module.exports = 1;\n');
    write('tests/test-results/.last-run.json', '{ "status": "passed" }\n');
    write('tests/playwright-report/index.html', '<html></html>\n');
    assert.equal(buildManifest(repo).digest, before.digest);
  });
});

test('an env-shaped path is excluded by name even inside an included tree', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    write('assets/js/.env.production', 'SECRET=fake\n');
    const manifest = buildManifest(repo);
    assert.equal(manifest.digest, before.digest);
    assert.ok(!collectSourcePaths(repo).some((path) => path.includes('.env')), 'no credential can reach a manifest');
  });
});

test('a manifest names what was in the run, and the base tree is labelled as the base', () => {
  withRepo(({ repo }) => {
    const manifest = buildManifest(repo);
    assert.equal(manifest.schema, IDENTITY_SCHEMA);
    assert.equal(manifest.digest, digestOf(manifest.files));
    assert.ok(manifest.repo.head, 'HEAD is recorded');
    assert.ok(manifest.repo.baseTree, 'and the base tree, named as the base rather than as "source"');
    assert.equal(manifest.repo.branch, manifest.repo.branch);
    assert.deepEqual(manifest.files.map((file) => file.path), [...manifest.files.map((file) => file.path)].sort(),
      'a sorted manifest is what makes the digest independent of directory order');
    for (const file of manifest.files) {
      assert.match(file.mode, /^100(644|755)$/);
      assert.equal(typeof file.size, 'number');
      assert.match(file.sha256, /^[0-9a-f]{64}$/);
    }
  });
});

test('a snapshot restores every file the manifest names, with the mode the manifest recorded', () => {
  withRepo(({ repo }) => {
    const manifest = buildManifest(repo);
    const archive = buildSnapshot(repo, manifest.files);
    const target = mkdtempSync(join(tmpdir(), 'frontend-restore-'));
    try {
      writeFileSync(join(target, 'snapshot.tar.gz'), archive);
      execFileSync('tar', ['-xzf', 'snapshot.tar.gz'], { cwd: target, stdio: 'pipe' });
      for (const file of manifest.files) {
        const restored = join(target, file.path);
        const actual = readFileSync(restored);
        assert.equal(actual.length, file.size, `${file.path} size`);
        assert.equal(execFileSync('sha256sum', [restored], { encoding: 'utf8' }).slice(0, 64), file.sha256,
          `${file.path} content`);
        const executable = (execFileSync('stat', ['-c', '%a', restored], { encoding: 'utf8' }).trim().endsWith('5'));
        assert.equal(executable, file.mode === '100755', `${file.path} mode`);
      }
    } finally {
      rmSync(target, { recursive: true, force: true });
    }
  });
});

test('the same content snapshots to the same bytes, and a changed byte changes them', () => {
  withRepo(({ repo, write }) => {
    const first = buildSnapshot(repo, buildManifest(repo).files);
    const second = buildSnapshot(repo, buildManifest(repo).files);
    assert.deepEqual(first, second, 'a snapshot that varies run to run cannot be compared across runs');

    write('assets/js/api/sessionCoordinator.js', 'export const A = 3;\n');
    assert.notDeepEqual(buildSnapshot(repo, buildManifest(repo).files), first);
  });
});

test('the CLI writes what the library builds, and reports the digest on stdout', () => {
  withRepo(({ repo }) => {
    const out = join(repo, 'reports', 'evidence', 'cli.manifest.json');
    const printed = execFileSync('node', [TOOL, '--repo', repo, '--out', out], { encoding: 'utf8' });
    const written = JSON.parse(readFileSync(out, 'utf8'));
    assert.equal(written.digest, buildManifest(repo).digest);
    assert.match(printed, new RegExp(written.digest), 'the digest the wrapper records is the digest on stdout');

    // `--print-digest` alone is what the wrapper pipes into its metadata, so it has to be the only
    // thing on stdout: a line of prose there would end up inside a recorded hash field.
    assert.equal(
      execFileSync('node', [TOOL, '--repo', repo, '--out', out, '--print-digest', '--quiet'], { encoding: 'utf8' }).trim(),
      written.digest
    );
  });
});

test('a usage error is exit 2 and an unreadable repository is exit 3, not a zero that looks like a pass', () => {
  const statusOf = (args) => {
    try {
      execFileSync('node', [TOOL, ...args], { stdio: 'pipe' });
      return 0;
    } catch (error) {
      return error.status;
    }
  };
  assert.equal(statusOf([]), 2, 'no arguments is a usage error');
  assert.equal(statusOf(['--nonsense']), 2, 'an unknown option is a usage error');
  assert.equal(statusOf(['--repo', '/nonexistent-repo', '--out', '/tmp/unused.json']), 3,
    'a repository that cannot be read is distinguishable from a usage error');
});

/* ------------------------------------------------------------------------------------------------
 * FR10-05 — a snapshot has to restore the tree it claims to describe.
 *
 * Both defects here are the same shape: the manifest was right and the archive was wrong, so every
 * digest in the review package could be checked and reproduce while the files behind them were filed
 * under names that do not exist. Neither shows up as a hash mismatch, which is exactly why they survived
 * R7 and R8.
 * ---------------------------------------------------------------------------------------------- */

/**
 * A ustar reader written from the format rather than from the writer.
 *
 * A round-trip checked with the same code that produced the archive proves the writer agrees with itself.
 * This one agrees with the *specification*: `name` at 0 (100 bytes), `prefix` at 345 (155 bytes), joined
 * with a single `/`, and the entry's type at 156. If the writer and this reader were derived from each
 * other, the long-path bug would pass in both directions at once.
 */
const BLOCK = 512;

const readUstar = (gzipped) => {
  const tar = gunzipSync(gzipped);
  const entries = [];
  for (let at = 0; at + BLOCK <= tar.length; at += BLOCK) {
    const header = tar.subarray(at, at + BLOCK);
    if (header.every((byte) => byte === 0)) continue;

    const readField = (offset, length) => {
      const raw = header.subarray(offset, offset + length);
      const end = raw.indexOf(0);
      return raw.subarray(0, end === -1 ? raw.length : end).toString('utf8');
    };
    const name = readField(0, 100);
    const prefix = readField(345, 155);
    const size = parseInt(readField(124, 12).trim() || '0', 8);
    const type = readField(156, 1) || '0';
    const mode = readField(100, 8).trim();

    // The checksum, recomputed the way a reader does it: the checksum field itself reads as spaces.
    const sum = (() => {
      const copy = Buffer.from(header);
      copy.write('        ', 148, 8, 'ascii');
      let total = 0;
      for (const byte of copy) total += byte;
      return total;
    })();
    const recorded = parseInt(readField(148, 7).trim() || '0', 8);
    if (sum !== recorded) throw new Error(`bad ustar checksum for ${name}: ${sum} != ${recorded}`);

    const bodyStart = at + BLOCK;
    entries.push({
      path: prefix ? `${prefix}/${name}` : name,
      mode,
      type,
      size,
      body: tar.subarray(bodyStart, bodyStart + size),
    });
    at += Math.ceil(size / BLOCK) * BLOCK;
  }
  return entries;
};

test('FR10-05: a path longer than the name field is split at a separator, not at a byte offset', async (t) => {
  await t.test('the review\'s exact case is refused rather than stored under a name that does not exist', () => {
    // `tools/` + 110 a's + `.mjs` has exactly one separator, and using it leaves a 114-byte name — over
    // the field. The old writer cut at `length - 100` and stored a *different path* whose hash was
    // correct, so a reader restored `tools/aaaa…/…mjs` and a report could point at a file that never
    // existed. There is no honest encoding for this path in ustar without PAX, so the answer is an error.
    const path = `tools/${'a'.repeat(110)}.mjs`;
    assert.throws(() => splitUstarPath(path), /cannot be stored in a ustar header/);
    assert.throws(() => splitUstarPath(path), /no "\/" that leaves a name of at most 100 bytes/);
  });

  await t.test('a path that fits the name field needs no split at all', () => {
    // A reader uses `name` alone when `prefix` is empty, so the empty prefix must not be mistaken for a
    // real one — joining unconditionally would produce a leading slash and an absolute path.
    const path = `tools/${'a'.repeat(40)}.mjs`;
    const { name, prefix } = splitUstarPath(path);
    assert.equal(prefix, '', 'and it is recorded as no prefix, not as a slash');
    assert.equal(name, path);
  });

  await t.test('a path too long for the name field is split at a separator that fits', () => {
    const path = `tools/${'a'.repeat(40)}/${'b'.repeat(60)}.mjs`;
    const { name, prefix } = splitUstarPath(path);

    assert.equal(`${prefix}/${name}`, path, 'a reader joins the two fields with one slash');
    assert.ok(Buffer.byteLength(name) <= 100, 'and the name fits its field');
    assert.ok(Buffer.byteLength(prefix) <= 155, 'and the prefix fits its field');
    assert.ok(prefix.startsWith('tools/'), 'and the split landed on a real separator, not a byte offset');
  });

  await t.test('a multi-byte name is split on whole characters', () => {
    // `é` is two bytes. Cutting at an arbitrary offset is what produced half a character in a field, and
    // a reader decoding that field would either throw or substitute U+FFFD — a different path, again.
    const path = `tools/${'\u00e9'.repeat(60)}/${'\u00fc'.repeat(30)}.mjs`;
    const { name, prefix } = splitUstarPath(path);
    const joined = `${prefix}/${name}`;

    assert.equal(joined, path);
    assert.equal(Buffer.from(joined, 'utf8').length, Buffer.byteLength(path, 'utf8'), 'no character was lost');
    assert.ok(!joined.includes('\ufffd'), 'and none was replaced by a decoding error');
  });
});

test('FR10-05: a snapshot restores the paths, modes and bytes the manifest names', async (t) => {
  await t.test('the whole file set round-trips, including a long path and an executable', () => {
    const { repo } = makeRepo();
    try {
      const longPath = `tools/${'a'.repeat(30)}/${'b'.repeat(30)}.mjs`;
      // The awkward files are added before the manifest that is checked, so they are part of it.
      mkdirSync(join(repo, dirname(longPath)), { recursive: true });
      writeFileSync(join(repo, longPath), 'export const deep = true;\n');
      writeFileSync(join(repo, 'tools', 'runner.sh'), '#!/usr/bin/env bash\n', { mode: 0o755 });

      const withExtras = buildManifest(repo);
      const entries = readUstar(buildSnapshot(repo, withExtras.files));
      const byPath = new Map(entries.map((entry) => [entry.path, entry]));

      for (const file of withExtras.files) {
        const entry = byPath.get(file.path);
        assert.ok(entry, `${file.path} is in the manifest and must be in the archive`);
        assert.equal(entry.size, file.size, `${file.path} restores with the recorded size`);
        // The manifest records a git mode, the archive records a unix mode, and the translation has to
        // happen: `100644` applied as a permission set is `0100644`, which no restore will reproduce.
        const expectedMode = file.kind === 'symlink' ? 0o777 : parseInt(file.mode.slice(-3), 8);
        assert.equal(parseInt(entry.mode, 8), expectedMode, `${file.path} restores with the recorded mode`);
        if (file.kind !== 'symlink') {
          assert.equal(
            entry.body.toString('utf8'),
            readFileSync(join(repo, file.path), 'utf8'),
            `${file.path} restores with the bytes that were hashed`
          );
        }
      }

      // The executable bit is inside the identity, so a snapshot that lost it would restore a tree whose
      // modes no longer match the digest that describes it.
      assert.equal(parseInt(byPath.get('tools/runner.sh').mode, 8), 0o755, 'an executable file restores executable');
      assert.ok(byPath.has(longPath), 'and a path longer than the name field restores under its own name');
      assert.equal(byPath.get(longPath).path, longPath, 'at the path the manifest recorded, not a mangled one');

      assert.equal(entries.length, withExtras.files.length, 'and nothing extra came along');
    } finally { rmSync(repo, { recursive: true, force: true }); }
  });

  await t.test('the system tar agrees, which is the reader that actually matters', () => {
    const { repo } = makeRepo();
    const out = join(repo, 'snapshot.tar.gz');
    try {
      const manifest = buildManifest(repo);
      writeFileSync(out, buildSnapshot(repo, manifest.files));

      // Written outside the repository's own identity scope, so reading it back does not perturb what is
      // being checked.
      const listed = execFileSync('tar', ['-tzf', out], { encoding: 'utf8' }).trim().split('\n').sort();
      assert.deepEqual(listed, manifest.files.map((file) => file.path).sort(),
        'GNU tar reads back exactly the paths the manifest names');
    } finally { rmSync(repo, { recursive: true, force: true }); }
  });
});

test('FR10-05: a symlink is recorded as a link, and never read through', async (t) => {
  await t.test('a .mjs symlink pointing at a .env file brings no secret into the manifest', () => {
    const { repo } = makeRepo();
    try {
      // The review's probe. The link's *name* passes the secret policy — it is a `.mjs` — so following it
      // was the only thing standing between a fixture credential and a tarball that ships with the review.
      writeFileSync(join(repo, '.env'), 'FAKE_REVIEW_SECRET_NOT_REAL\n');
      symlinkSync('../.env', join(repo, 'tools', 'alias.mjs'));

      const manifest = buildManifest(repo);
      const link = manifest.files.find((file) => file.path === 'tools/alias.mjs');

      assert.ok(link, 'the link is in the identity rather than quietly omitted');
      assert.equal(link.kind, 'symlink');
      assert.equal(link.target, '../.env', 'recorded as the path it points at');
      assert.equal(link.targetExcluded, true, 'and flagged as reaching a path the policy excludes');

      const serialised = JSON.stringify(manifest);
      assert.ok(!serialised.includes('FAKE_REVIEW_SECRET_NOT_REAL'),
        'the credential must not appear anywhere in the manifest');
      assert.ok(!gunzipSync(buildSnapshot(repo, manifest.files)).toString('utf8').includes('FAKE_REVIEW_SECRET_NOT_REAL'),
        'nor anywhere in the snapshot');

      // The tar entry is a link, not a copy: type `2`, body = the target path.
      const entry = readUstar(buildSnapshot(repo, manifest.files)).find((e) => e.path === 'tools/alias.mjs');
      assert.equal(entry.type, '2', 'stored as a symlink entry');
      assert.equal(entry.body.toString('utf8'), '../.env', 'whose body is the target, not the file');
    } finally { rmSync(repo, { recursive: true, force: true }); }
  });

  await t.test('a link inside the repository is allowed, and the tree round-trips as links', () => {
    const { repo } = makeRepo();
    try {
      writeFileSync(join(repo, 'assets', 'js', 'real.js'), 'export const real = 1;\n');
      symlinkSync('real.js', join(repo, 'assets', 'js', 'alias.js'));

      const manifest = buildManifest(repo);
      const entry = readUstar(buildSnapshot(repo, manifest.files)).find((e) => e.path === 'assets/js/alias.js');

      assert.equal(entry.type, '2');
      assert.equal(entry.body.toString('utf8'), 'real.js');
      assert.equal(symlinkTarget(repo, 'assets/js/alias.js').inRepo, true);
    } finally { rmSync(repo, { recursive: true, force: true }); }
  });

  await t.test('a link that leaves the repository is refused, and says so', () => {
    const { repo } = makeRepo();
    try {
      symlinkSync('/etc/hostname', join(repo, 'tools', 'escape.mjs'));
      assert.throws(() => buildManifest(repo), /outside the repository/);
      assert.throws(() => buildManifest(repo), /cannot be reconstructed or checked/);
    } finally { rmSync(repo, { recursive: true, force: true }); }
  });

  await t.test('the digest still changes when a link retargets', () => {
    const { repo } = makeRepo();
    try {
      writeFileSync(join(repo, 'assets', 'js', 'one.js'), '1\n');
      writeFileSync(join(repo, 'assets', 'js', 'two.js'), '2\n');
      symlinkSync('one.js', join(repo, 'assets', 'js', 'alias.js'));

      const before = buildManifest(repo).digest;
      rmSync(join(repo, 'assets', 'js', 'alias.js'));
      symlinkSync('two.js', join(repo, 'assets', 'js', 'alias.js'));
      const after = buildManifest(repo).digest;

      assert.notEqual(before, after, 'a link is part of the source, so retargeting it moves the identity');
      assert.equal(readlinkSync(join(repo, 'assets', 'js', 'alias.js')), 'two.js');
    } finally { rmSync(repo, { recursive: true, force: true }); }
  });
});
