#!/usr/bin/env bash
# run-browser-gate.sh — run the browser suite against a frozen copy of the work tree.
#
# Why: the browser suite is the long pole (tens of minutes), and it has to run against a source that
# cannot move while it runs. Editing the working tree in parallel is the normal way to spend that time,
# and `run-frontend-gate.sh` would — correctly — report INVALID_SOURCE_DRIFT for exactly that. So the
# browser gate runs in its own checkout: the source is synced in, the run is recorded there, and the
# evidence is copied back to the real reports directory with the identity that actually produced it.
#
# The copy is a real copy, not a symlink farm, so a `node_modules` installed once is reused and the
# source is a genuine snapshot rather than a view of files that are still moving.
#
# Usage: tools/run-browser-gate.sh [--label NAME] [-- extra playwright args]

set -u

SELF_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SELF_DIR}/.." && pwd)"
RUN_ROOT="${FRONTEND_BROWSER_RUN_ROOT:-/tmp/opencode/frontend-browser-run}"
SCRATCH="${RUN_ROOT}/worktree"

LABEL="browser"
if [ "${1:-}" = "--label" ]; then LABEL="${2:?--label needs a value}"; shift 2; fi
if [ "${1:-}" = "--" ]; then shift; fi

mkdir -p "${RUN_ROOT}"

# --- sync a frozen copy --------------------------------------------------------
# Everything the browser run reads, nothing it writes. `reports/evidence` is excluded so evidence
# accumulates in the real reports directory instead of being mirrored both ways.
if [ -d "${SCRATCH}" ]; then rm -rf "${SCRATCH}"; fi
mkdir -p "${SCRATCH}"
tar -C "${REPO_ROOT}" \
  --exclude=./.git --exclude=./tests/node_modules --exclude=./tests/test-results \
  --exclude=./tests/playwright-report --exclude=./reports/evidence \
  -cf - . | tar -C "${SCRATCH}" -xf -
mkdir -p "${SCRATCH}/reports/evidence"
if [ -d "${REPO_ROOT}/.git" ]; then cp -a "${REPO_ROOT}/.git" "${SCRATCH}/.git"; fi
# Reuse the install rather than paying for it every run; the lockfile is part of the recorded identity, so
# a run whose install does not match the lockfile cannot happen silently.
if [ -d "${REPO_ROOT}/tests/node_modules" ]; then
  cp -a "${REPO_ROOT}/tests/node_modules" "${SCRATCH}/tests/node_modules"
fi
# The browsers themselves are a machine-level cache, not part of the tree.
mkdir -p "${SCRATCH}/tests/node_modules"
: > "${SCRATCH}/tests/node_modules/.install-ok"

# --- run -----------------------------------------------------------------------
# No `--no-snapshot` here. The snapshot is what makes this evidence reconstructable, and the copy-back
# below expects one; a gate that recorded manifests but no content could not be replayed, which is the
# whole reason the content identity was built in the first place (FR9-05).
set +e
bash "${SCRATCH}/tools/run-frontend-gate.sh" --label "${LABEL}" --cwd "${SCRATCH}/tests" \
  --no-gate-install -- npm run test:browser -- "$@"
RC=$?
set -e

# --- bring the evidence home ---------------------------------------------------
# The metadata names the snapshot digest, so the record travels with the source it describes.
DEST="${REPO_ROOT}/reports/evidence"
mkdir -p "${DEST}"
# One glob per suffix, not two: an exact-name glob followed by a broad one matches the same file twice,
# and the duplicate would be copied again under a random name — two files claiming to be the same run,
# with only one of them named after the run.
for suffix in log meta source-before.manifest.json source-after.manifest.json source.tar.gz; do
  # The glob parts are deliberately unquoted. `"${LABEL}-*-1.${suffix}"` is one quoted word, so the `*`
  # would be a literal asterisk, the loop would run once with a name that does not exist, and the evidence
  # would stay in the scratch tree — a gate that reported success while the reports directory kept none
  # of it. The path prefix stays quoted so a run root with a space in it still works.
  for file in "${SCRATCH}/reports/evidence/${LABEL}"-*-1."${suffix}"; do
    [ -e "${file}" ] || continue
    base="$(basename "${file}")"
    target="${DEST}/browser-${base}"
    [ -e "${target}" ] && target="${DEST}/browser-${base%.${suffix}}-${RANDOM}.${suffix}"
    cp "${file}" "${target}"
  done
done

printf 'run-browser-gate: exit %s; evidence in %s\n' "${RC}" "${DEST}" >&2
exit "${RC}"
