#!/usr/bin/env node
/**
 * frontend-source-identity.mjs — what source a gate run actually tested.
 *
 * Why this exists (FR9-05): the gate wrapper used to record
 * `head=<sha> tree=<sha> branch=<name> status_sha256=<sha of `git status --porcelain`` and call that
 * source identity. It is not one. `git status --porcelain` names *which* paths differ, never what is
 * in them, so editing the bytes of a file that is already `M` leaves the hash untouched and a run
 * against different source carries the same identity as the run before it. An untracked directory
 * collapses to a single `?? reports/` line, so the several hundred kilobytes under it are unnamed too.
 * The `tree` field made it worse by looking precise: it is the *base* tree, the code before the
 * changes being tested, and `source:` in the report was reading like the tested tree when it was not.
 *
 * So identity here is the content: a sorted manifest of `{path, mode, size, sha256}` for every file
 * the gates read, hashed into one digest. Change a byte of a modified file, add a file, delete a file,
 * flip an executable bit, and the digest changes. Same tree, different mtime, and it does not.
 *
 * The manifest is *the record*, and the optional snapshot beside it makes the run reconstructable: the
 * digest says which source produced a result, and the tarball says what that source was, without
 * having to stage a single owner file to get a tree hash for it.
 *
 * Usage:
 *   node tools/frontend-source-identity.mjs --repo <path> --out <manifest.json> [--snapshot <tar.gz>]
 *                                            [--print-digest] [--quiet]
 *
 * Exit codes: 0 written; 2 usage error; 3 the repository could not be read.
 *
 * Nothing here prints file contents, and secrets are excluded by path policy rather than by guessing.
 */

import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { closeSync, mkdirSync, openSync, readdirSync, readFileSync, statSync, writeSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

/** Writes a buffer to `path`, replacing it. One descriptor, so a failure cannot leave a half file. */
const writeFile = (path, data) => {
  const fd = openSync(path, 'w');
  try {
    writeSync(fd, data);
  } finally {
    closeSync(fd);
  }
};

export const IDENTITY_SCHEMA = 'frontend-source-identity/1';

/**
 * What the gates read, and therefore what a digest has to name.
 *
 * A gate can only be about code it loaded. The application, the no-build loader, the test harness and
 * its lockfile, the static gates in `tools/`, and the reports a run appends its own evidence to — all
 * of it decides the answer, so all of it is in the manifest. Documentation, screenshots and CI config
 * are not executed by any gate and are left out deliberately rather than by accident.
 */
export const INCLUDE_ROOTS = [
  'assets',
  'vue',
  'tools',
  'tests/regression',
  'tests/browser',
  'reports',
];

/** Individual files that decide what the gates do. */
export const INCLUDE_FILES = [
  'index.html',
  'tests/package.json',
  'tests/package-lock.json',
];

/**
 * What is left out, and why.
 *
 * The first three are not source: `.git` is the repository, `node_modules` is an install of it, and the
 * Playwright output directories are written *by* a run. The rest is evidence, and evidence is the one
 * thing a gate must not be able to hash into itself: the wrapper writes a manifest per run, so if those
 * files were included the digest would change the moment the run recorded it and every run would look
 * like it had drifted from itself.
 *
 * `.env`-shaped paths are excluded by name so a real credential cannot reach a manifest even if somebody
 * adds one to the tree; nothing in the gates reads them.
 */
export const EXCLUDE_PREFIXES = [
  '.git',
  'node_modules',
  'tests/test-results',
  'tests/playwright-report',
  'reports/evidence',
];

/** Never hashed, never snapshotted, whatever else the policy says. */
export const EXCLUDE_NAME_PATTERN = /(^|\/)(\.env(\..*)?|.*\.pem|.*\.key|id_rsa(\.pub)?)$/;

const toPosix = (value) => value.split(sep).join('/');

/** The git mode (`100644`, `100755`) git itself would record, so a manifest is comparable with a tree. */
const gitMode = (mode) => `100${mode & 0o111 ? '755' : '644'}`;

const isExcluded = (posixPath) => {
  if (EXCLUDE_NAME_PATTERN.test(posixPath)) return true;
  return EXCLUDE_PREFIXES.some((prefix) => posixPath === prefix || posixPath.startsWith(`${prefix}/`));
};

const shouldInclude = (posixPath) => {
  if (isExcluded(posixPath)) return false;
  if (INCLUDE_FILES.includes(posixPath)) return true;
  return INCLUDE_ROOTS.some((root) => posixPath === root || posixPath.startsWith(`${root}/`));
};

/**
 * Every included file under `repo`, as POSIX paths relative to it, in sorted order.
 *
 * Walking the tree rather than reading `git ls-files` is deliberate: the untracked files *are* the ones
 * a status-based identity cannot name, so they have to be in the manifest, and a walk finds them
 * without staging anything.
 */
export function collectSourcePaths(repo) {
  const found = [];
  const walk = (absolute) => {
    const entries = readdirSync(absolute, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1));
    for (const entry of entries) {
      const child = join(absolute, entry.name);
      const posix = toPosix(relative(repo, child));
      if (isExcluded(posix)) continue;
      if (entry.isDirectory()) {
        walk(child);
        continue;
      }
      // A symlink is recorded as itself: what the gates read is the bytes the link points at, and a
      // link into an excluded tree is content this run cannot claim to have tested.
      if (!entry.isFile() && !entry.isSymbolicLink()) continue;
      if (shouldInclude(posix)) found.push(posix);
    }
  };
  walk(repo);
  return found.sort();
}

const sha256File = (absolute) => {
  const digest = createHash('sha256');
  digest.update(readFileSync(absolute));
  return digest.digest('hex');
};

/** `git status --porcelain` is kept as *metadata* — it names paths, so it explains a change, not proves one. */
const gitState = (repo) => {
  const run = (...args) => {
    try {
      return execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    } catch (_error) {
      return null;
    }
  };
  const status = run('status', '--porcelain');
  return {
    head: run('rev-parse', 'HEAD'),
    // The base tree, explicitly named as such. The tested tree is the `digest` below; calling this
    // "source" is what made the old metadata read like an identity when it was not one.
    baseTree: run('rev-parse', 'HEAD^{tree}'),
    branch: run('rev-parse', '--abbrev-ref', 'HEAD'),
    statusSha256: status === null ? null : createHash('sha256').update(status).digest('hex'),
    statusEntryCount: status === null ? null : status.split('\n').filter(Boolean).length,
  };
};

/** The one hash everything else is checked against. Paths and modes are inside it, not beside it. */
export const digestOf = (files) => {
  const digest = createHash('sha256');
  for (const file of files) {
    digest.update(`${JSON.stringify(file)}\n`);
  }
  return digest.digest('hex');
};

export function buildManifest(repo, { generatedAt = new Date().toISOString() } = {}) {
  const root = resolve(repo);
  const paths = collectSourcePaths(root);
  const files = paths.map((posix) => {
    const absolute = join(root, posix);
    const stats = statSync(absolute);
    return {
      path: posix,
      mode: gitMode(stats.mode),
      size: stats.size,
      sha256: sha256File(absolute),
    };
  });
  return {
    schema: IDENTITY_SCHEMA,
    generatedAt,
    repo: gitState(root),
    policy: { includeRoots: INCLUDE_ROOTS, includeFiles: INCLUDE_FILES, excludePrefixes: EXCLUDE_PREFIXES },
    fileCount: files.length,
    digest: digestOf(files),
    files,
  };
}

/* ------------------------------------------------------------------------------------------------
 * A deterministic tar of the same files, so a run can be reconstructed.
 *
 * Written here rather than shelled out to because "deterministic" has to mean the same thing on every
 * machine: entries sorted by path, owner and mode from the manifest, and mtime/uid/gid fixed at zero,
 * so re-snapshotting identical content produces identical bytes and a diff between two snapshots says
 * something about the source rather than about the clock.
 * ---------------------------------------------------------------------------------------------- */

const BLOCK = 512;

const octal = (value, width) => value.toString(8).padStart(width - 1, '0') + '\0';

const tarHeader = ({ path, mode, size, type = '0' }) => {
  const name = Buffer.from(path, 'utf8');
  // ustar splits long names into a prefix field rather than a PAX record, which keeps this dependency
  // free and the output byte-stable. Paths longer than the whole header are refused rather than
  // silently truncated, because a truncated name restores the wrong file.
  if (name.length > 100) {
    const cut = name.length - 100;
    const prefix = name.subarray(0, cut).toString('utf8');
    if (Buffer.byteLength(prefix) > 155) throw new Error(`path too long for a ustar snapshot: ${path}`);
    const header = Buffer.alloc(BLOCK);
    header.write(name.subarray(cut).toString('utf8'), 0, 100, 'utf8');
    header.write(octal(parseInt(mode, 8), 8), 100, 8, 'ascii');
    header.write(octal(0, 8), 108, 8, 'ascii');
    header.write(octal(0, 8), 116, 8, 'ascii');
    header.write(octal(size, 12), 124, 12, 'ascii');
    header.write(octal(0, 12), 136, 12, 'ascii');
    header.write('        ', 148, 8, 'ascii');
    header.write(type, 156, 1, 'ascii');
    header.write('ustar\0', 257, 6, 'ascii');
    header.write('00', 263, 2, 'ascii');
    header.write(prefix, 345, 155, 'utf8');
    let checksum = 0;
    for (const byte of header) checksum += byte;
    header.write(octal(checksum, 7), 148, 7, 'ascii');
    header.write(' ', 155, 1, 'ascii');
    return header;
  }
  const header = Buffer.alloc(BLOCK);
  header.write(name.toString('utf8'), 0, 100, 'utf8');
  header.write(octal(parseInt(mode, 8), 8), 100, 8, 'ascii');
  header.write(octal(0, 8), 108, 8, 'ascii');
  header.write(octal(0, 8), 116, 8, 'ascii');
  header.write(octal(size, 12), 124, 12, 'ascii');
  header.write(octal(0, 12), 136, 12, 'ascii');
  header.write('        ', 148, 8, 'ascii');
  header.write(type, 156, 1, 'ascii');
  header.write('ustar\0', 257, 6, 'ascii');
  header.write('00', 263, 2, 'ascii');
  let checksum = 0;
  for (const byte of header) checksum += byte;
  header.write(octal(checksum, 7), 148, 7, 'ascii');
  header.write(' ', 155, 1, 'ascii');
  return header;
};

const pad = (size) => (size % BLOCK === 0 ? Buffer.alloc(0) : Buffer.alloc(BLOCK - (size % BLOCK)));

/** A gzip of the same content at the same level every time, so a snapshot is comparable byte for byte. */
export function buildSnapshot(repo, files) {
  const parts = [];
  for (const file of files) {
    parts.push(tarHeader(file));
    const body = readFileSync(join(repo, file.path));
    parts.push(body, pad(body.length));
  }
  parts.push(Buffer.alloc(BLOCK * 2));
  return gzipSync(Buffer.concat(parts), { level: 9, mtime: 0 });
}

/* -------------------------------------------------------------------------------------------------- */

const usage = () => {
  process.stderr.write(
    'usage: frontend-source-identity.mjs --repo <path> --out <manifest.json> '
    + '[--snapshot <tar.gz>] [--print-digest] [--quiet]\n'
  );
};

const main = (argv) => {
  let repo = null;
  let out = null;
  let snapshot = null;
  let printDigest = false;
  let quiet = false;

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--repo') repo = argv[++index];
    else if (arg === '--out') out = argv[++index];
    else if (arg === '--snapshot') snapshot = argv[++index];
    else if (arg === '--print-digest') printDigest = true;
    else if (arg === '--quiet') quiet = true;
    else if (arg === '-h' || arg === '--help') { usage(); return 0; }
    else { process.stderr.write(`frontend-source-identity: unknown option ${arg}\n`); usage(); return 2; }
  }

  if (!repo || !out) { usage(); return 2; }

  let manifest;
  try {
    manifest = buildManifest(repo);
  } catch (error) {
    process.stderr.write(`frontend-source-identity: could not read ${repo}: ${error.message}\n`);
    return 3;
  }

  mkdirSync(dirname(resolve(out)), { recursive: true });
  writeFile(resolve(out), Buffer.from(`${JSON.stringify(manifest, null, 2)}\n`, 'utf8'));

  if (snapshot) {
    mkdirSync(dirname(resolve(snapshot)), { recursive: true });
    writeFile(resolve(snapshot), buildSnapshot(resolve(repo), manifest.files));
  }

  if (printDigest) process.stdout.write(`${manifest.digest}\n`);
  if (!quiet) {
    process.stdout.write(
      `frontend-source-identity: ${manifest.fileCount} files, digest ${manifest.digest}\n`
      + `  manifest: ${out}${snapshot ? `\n  snapshot: ${snapshot}` : ''}\n`
    );
  }
  return 0;
};

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  process.exitCode = main(process.argv.slice(2));
}
