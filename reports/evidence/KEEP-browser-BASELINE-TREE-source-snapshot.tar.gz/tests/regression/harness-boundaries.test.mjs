/**
 * FA8-03 / FA8-04 — the boundaries the browser suite is supposed to enforce on *itself*.
 *
 * Both findings are about tests that pass when they should not, so a test about them has to be able to
 * fail in exactly the same way. Neither of these needs a browser: the egress policy is a pure decision
 * and the page-problem collector only ever listens to events, so both are driven directly here. The
 * browser-level proof that the guard is actually installed on every context is a separate case in
 * `browser/harness-egress.spec.mjs`, because that one is about Playwright wiring.
 *
 * The round6 code fails these on behaviour:
 *   - the egress allowlist was a set of *origins*, so any path on unpkg was allowed, including
 *     `not-a-pinned-dependency@latest` — an unpinned artifact from an allowed host;
 *   - `allowError()` pushed one pattern into a single list that was then matched against console
 *     errors, page errors and failed requests alike, so a broad allowance for a refused HTTP request
 *     also swallowed an unrelated uncaught `pageerror` that merely contained the same word.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

import {
  PINNED_ARTIFACTS,
  ORIGIN_SCOPED_ALLOWANCES,
  API_ORIGIN,
  STATIC_ORIGIN,
  collectPageProblems,
  createEgressPolicy,
} from '../browser/helpers/browser-fixture.mjs';

const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');

/** A page stand-in that only does what the collector uses of a page. */
const fakePage = () => {
  const emitter = new EventEmitter();
  return {
    on: (event, handler) => emitter.on(event, handler),
    emit: (event, payload) => emitter.emit(event, payload)
  };
};

const consoleError = (text) => ({ type: () => 'error', text: () => text });
const failedRequest = ({ method = 'GET', url = 'http://127.0.0.1:4173/x', errorText = 'net::ERR_ABORTED' } = {}) => ({
  method: () => method,
  url: () => url,
  failure: () => ({ errorText })
});

/* ------------------------------------------------------------------------------------------------
 * FA8-03 — the allowlist is the pinned artifacts, not the hosts that serve them.
 * ---------------------------------------------------------------------------------------------- */

test('the egress allowlist is the exact pinned artifacts the loader names, and nothing else', async (t) => {
  const policy = createEgressPolicy();

  await t.test('every pinned artifact is derived from the loader, so the list cannot drift', () => {
    // The same files `tools/check-cdn-pins.cjs` scans. If the two lists diverge, the guard and the static
    // gate end up disagreeing about what "pinned" means, which is how `index.html`'s three runtime
    // dependencies went missing and the guard refused the app's own boot.
    const sources = ['index.html', 'vue/Loader.js', 'assets/js/init.js', 'assets/js/appServices.js']
      .map((file) => readFileSync(join(REPO_ROOT, file), 'utf8'))
      .join('\n');
    const referenced = [...sources.matchAll(/https:\/\/(?:unpkg\.com|cdn\.jsdelivr\.net)\/[^"'\s)]+/g)]
      .map((match) => match[0]);

    assert.ok(referenced.length > 0, 'the app really does name pinned CDN artifacts');
    assert.deepEqual(
      [...PINNED_ARTIFACTS].sort(),
      [...new Set(referenced)].sort(),
      'the allowlist is exactly what the app asks for — no more, no less'
    );
  });

  await t.test('every allowlisted artifact names an exact version', () => {
    // An allowlist entry without a version is a host rule wearing a path rule's clothes: the difference
    // between `axios@1.20.0` and whatever is published next is the whole point of pinning.
    for (const artifact of PINNED_ARTIFACTS) {
      assert.match(artifact, /@\d+\.\d+\.\d+/, `${artifact} is not pinned to an exact version`);
    }
  });

  await t.test('a pinned artifact is allowed', () => {
    for (const artifact of PINNED_ARTIFACTS) {
      assert.equal(policy.reasonFor(artifact), null, `${artifact} is pinned and must be allowed`);
    }
    assert.equal(policy.reasonFor('https://unpkg.com/axios@1.20.0/dist/axios.min.js'), null);
  });

  await t.test('an unpinned artifact on an allowed host is blocked', () => {
    // This is the review's probe. The host is allowlisted, the path is not, and the version is
    // `@latest` — exactly the shape of a dependency that nobody pinned.
    const probed = 'https://unpkg.com/not-a-pinned-dependency@latest/index.js?FAKE_marker=1';
    assert.notEqual(policy.reasonFor(probed), null, 'an unpinned path on unpkg must be refused');
    assert.equal(policy.allows(probed), false);
  });

  await t.test('the right path at the wrong version is blocked', () => {
    // The strongest form of the same mistake: everything about the URL is right except the version, and
    // an origin-only allowlist cannot see the difference.
    const bumped = 'https://unpkg.com/axios@1.21.0/dist/axios.min.js';
    assert.equal(policy.reasonFor('https://unpkg.com/axios@1.20.0/dist/axios.min.js'), null);
    assert.notEqual(policy.reasonFor(bumped), null, 'a bumped version is not the pinned artifact');
  });

  await t.test('a runtime artifact inside a pinned dependency inherits its pin', () => {
    // bootstrap-icons ships its fonts as relative `url(...)`s from its stylesheet, so no source file in
    // this repo names `bootstrap-icons.woff2`. The browser resolves it against the stylesheet's own URL,
    // wherever that is. It must be allowed — but because it still sits inside the *version* directory of
    // the pinned dependency, not because the host is allowed.
    const fonts = [
      'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/fonts/bootstrap-icons.woff2?1bb88866b4085542c8ed5fb61b9393dd',
      'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/fonts/bootstrap-icons.woff?1bb88866b4085542c8ed5fb61b9393dd'
    ];
    for (const font of fonts) {
      assert.equal(policy.reasonFor(font), null, `${font} is inside a pinned dependency's own directory`);
    }
    // The same shape in any other version directory is the wrong version, and in any other package is
    // unpinned — the inherit-the-pin rule must not become a host rule.
    assert.notEqual(
      policy.reasonFor('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/fonts/bootstrap-icons.woff2'),
      null,
      'a bumped version directory is not pinned'
    );
    assert.notEqual(
      policy.reasonFor('https://cdn.jsdelivr.net/npm/other-package@1.11.0/font/fonts/x.woff2'),
      null,
      'a file inside a directory named after a package nobody pinned must be refused'
    );
  });

  await t.test('the loopback fixture origins are allowed', () => {
    assert.equal(policy.reasonFor(`${STATIC_ORIGIN}/`), null);
    assert.equal(policy.reasonFor(`${API_ORIGIN}/api/auth/refresh_token`), null);
  });

  await t.test('any other origin is blocked, including a lookalike host', () => {
    for (const url of [
      'https://evil.example.com/x.js',
      'https://unpkg.com.evil.example/x.js',
      'https://not-unpkg.com/axios@1.20.0/dist/axios.min.js',
      'http://127.0.0.1:4173.evil.example/x.js',
      'https://10.0.0.1/x.js'
    ]) {
      assert.equal(policy.allows(url), false, `${url} must not be allowed`);
    }
  });

  await t.test('the build CDNs that have no pinnable path are allowed, and say why', () => {
    // Tailwind's build endpoint and the Google Fonts stylesheet are named by origin, not by a versioned
    // artifact, so they cannot be pinned the way a package can. They stay allowed — the app does not
    // boot without them — but each one carries the reason it cannot be tightened, because an allowance
    // nobody can account for is how an allowlist rots back into a list of hosts.
    for (const entry of ORIGIN_SCOPED_ALLOWANCES) {
      assert.ok(entry.reason && entry.reason.length > 20, `${entry.origin} must say why it is scoped`);
      assert.equal(policy.reasonFor(`${entry.origin}/anything-at-all`), null);
    }
    assert.ok(
      ORIGIN_SCOPED_ALLOWANCES.some((entry) => entry.origin === 'https://cdn.tailwindcss.com'),
      'the Tailwind build endpoint is one of them'
    );
  });

  await t.test('a blocked URL says why, so a failure is readable', () => {
    const reason = policy.reasonFor('https://unpkg.com/not-a-pinned-dependency@latest/index.js');
    assert.match(reason, /not one of the pinned artifacts/);
  });
});

/* ------------------------------------------------------------------------------------------------
 * FA8-04 — an allowance covers the thing it names, and only that thing.
 * ---------------------------------------------------------------------------------------------- */

test('a problem allowance is typed, so it cannot cover an unrelated failure that shares a word', async (t) => {
  await t.test('an allowance must say which kind of problem it is about', () => {
    const problems = collectPageProblems(fakePage());
    assert.throws(
      () => problems.allowError(/401/, 'untyped allowances are how a broad filter starts'),
      /kind/,
      'an allowance without a kind must be refused outright'
    );
  });

  await t.test('an allowance for a refused request does not swallow an uncaught page error', () => {
    const page = fakePage();
    const problems = collectPageProblems(page);
    problems.allowError(
      { kind: 'console' },
      /Failed to load resource|Network Error|401|Request failed/i,
      'the one request the stand-in refused on purpose, which axios logs as an error'
    );

    page.emit('console', consoleError('Failed to load resource: the server responded with 401'));
    page.emit('pageerror', new Error('Unexpected programming failure: CORS sentinel'));

    assert.deepEqual(
      problems.problems().map((entry) => entry.kind),
      ['pageerror'],
      'the console error was declared, the uncaught page error was not, so it is still reported'
    );
  });

  await t.test('a canary with the same words but a different source still fails', () => {
    const page = fakePage();
    const problems = collectPageProblems(page);
    problems.allowError(
      { kind: 'console' },
      /CORS/i,
      'the loader reports a blocked stylesheet as a console error'
    );
    page.emit('console', consoleError('CORS policy blocked a stylesheet'));
    page.emit('pageerror', new Error('CORS'));

    assert.equal(problems.problems().length, 1, 'the matching console error is covered');
    assert.equal(problems.problems()[0].kind, 'pageerror', 'and the page error is not');
  });

  await t.test('a failed-request allowance is scoped to the request it names', () => {
    const page = fakePage();
    const problems = collectPageProblems(page);
    problems.allowError(
      { kind: 'requestfailed', method: 'POST', url: /\/api\/auth\/refresh_token$/ },
      /ERR_ABORTED/,
      'navigating to the new endpoint aborts exactly the chunk/refresh the router had already asked for'
    );

    page.emit('requestfailed', failedRequest({
      method: 'POST',
      url: 'http://127.0.0.1:18788/api/auth/refresh_token',
      errorText: 'net::ERR_ABORTED'
    }));
    page.emit('requestfailed', failedRequest({
      method: 'GET',
      url: 'http://127.0.0.1:4173/assets/chunk.js',
      errorText: 'net::ERR_ABORTED'
    }));

    const reported = problems.problems();
    assert.equal(reported.length, 1, 'the unrelated aborted request is still reported');
    assert.match(reported[0].text, /chunk\.js/);
  });

  await t.test('an allowance for a method does not cover the same path with another method', () => {
    const page = fakePage();
    const problems = collectPageProblems(page);
    problems.allowError(
      { kind: 'requestfailed', method: 'POST', url: /\/api\/auth\/logout$/ },
      /ERR_ABORTED/,
      'the logout this case triggers is aborted on purpose'
    );
    page.emit('requestfailed', failedRequest({ method: 'GET', url: 'http://127.0.0.1:18788/api/auth/logout' }));

    assert.equal(problems.problems().length, 1, 'a GET of the same path is a different request');
  });

  await t.test('an allowance may state how many problems it expects', () => {
    const page = fakePage();
    const problems = collectPageProblems(page);
    problems.allowError({ kind: 'console', count: 1 }, /refused once/, 'exactly one refused request is expected');
    page.emit('console', consoleError('refused once'));
    page.emit('console', consoleError('refused once'));
    assert.deepEqual(problems.problems().map((entry) => entry.text), ['refused once'], 'the second one is over the declared count');

    const under = collectPageProblems(fakePage());
    under.allowError({ kind: 'console', count: 2 }, /refused twice/, 'two refused requests are expected');
    assert.throws(() => under.expectClean(), /expected \[2, 2\] but matched 0/);
  });

  await t.test('a count may be a range, for noise that is conditional but never legitimate twice', () => {
    // Whether a refused request is logged at all is the browser's mood, not the app's contract, so a
    // case must be able to say "at most one" without pretending it always happens. But the ceiling is
    // still a failure: the same refusal is never legitimate twice, and a floor above zero still demands
    // its share.
    const maybePage = fakePage();
    const maybe = collectPageProblems(maybePage);
    maybe.allowError({ kind: 'console', count: [0, 2] }, /maybe refused/, 'the browser may or may not log this');
    // zero occurrences: the case survives
    maybe.expectClean();
    // one occurrence is fine, and it cannot be anything else
    const onePage = fakePage();
    const one = collectPageProblems(onePage);
    one.allowError({ kind: 'console', count: [0, 1] }, /maybe refused/, 'the browser may or may not log this');
    onePage.emit('console', consoleError('maybe refused'));
    one.expectClean();
    // two occurrences of a refusal a case said happens at most once is a blanket, and must fail
    const twicePage = fakePage();
    const twice = collectPageProblems(twicePage);
    twice.allowError({ kind: 'console', count: [0, 1] }, /maybe refused/, 'the browser may or may not log this');
    twicePage.emit('console', consoleError('maybe refused'));
    twicePage.emit('console', consoleError('maybe refused'));
    assert.throws(() => twice.expectClean(), /maybe refused/, 'the second occurrence is beyond the ceiling and cannot be excused');
    // a floor above zero is still a demand, not a hope
    const demandedPage = fakePage();
    const demanded = collectPageProblems(demandedPage);
    demanded.allowError({ kind: 'console', count: [1, 1] }, /must happen/, 'the case needs one of these');
    assert.throws(() => demanded.expectClean(), /expected \[1, 1\]/, 'a floor of one is a demand');
    demandedPage.emit('console', consoleError('must happen'));
    demanded.expectClean();
  });

  await t.test('the reason is still mandatory', () => {
    const problems = collectPageProblems(fakePage());
    assert.throws(() => problems.allowError({ kind: 'console' }, /401/, ''), /reason/);
  });

  await t.test('an uncaught page error is reported with no allowance at all', () => {
    const page = fakePage();
    const problems = collectPageProblems(page);
    page.emit('pageerror', new Error('TypeError: cannot read properties of undefined'));
    assert.equal(problems.problems().length, 1);
    assert.equal(problems.problems()[0].kind, 'pageerror');
  });
});
