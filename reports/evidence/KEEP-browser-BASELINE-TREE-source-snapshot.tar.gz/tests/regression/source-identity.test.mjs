/**
 * FR9-05 — the identity a gate run records has to be the *content* of the source, not its shape.
 *
 * The gate wrapper used to record `status_sha256`, the hash of `git status --porcelain`. That is a hash
 * of file *names*: it says which paths differ from HEAD and nothing about what is in them. So editing
 * the bytes of a file that is already `M` left the recorded identity untouched, and two runs against
 * different source carried the same identity — including a red run and a green one. An untracked
 * directory collapsed to a single `?? reports/` line, so everything underneath it was unnamed, and the
 * `tree=` field made it read like a precise answer while naming the *base* tree rather than the tree
 * that was tested.
 *
 * Every case below is therefore written as a pair: the same edit, observed through the old status hash
 * and through the content digest. Where the status hash does not move, that is the defect being pinned
 * shut — a test that only checked "the digest changed" would still pass if the digest were accidentally
 * constant.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { chmodSync, mkdirSync, mkdtempSync, readFileSync, rmSync, utimesSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  IDENTITY_SCHEMA,
  buildManifest,
  buildSnapshot,
  collectSourcePaths,
  digestOf,
} from '../../tools/frontend-source-identity.mjs';

const TOOL = fileURLToPath(new URL('../../tools/frontend-source-identity.mjs', import.meta.url));

/** A throwaway repository shaped like this one: a committed baseline plus the dirty delta a round leaves. */
function makeRepo() {
  const repo = mkdtempSync(join(tmpdir(), 'frontend-identity-'));
  const git = (...args) => execFileSync('git', ['-C', repo, ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
  git('init', '--quiet');
  git('config', 'user.email', 'identity@example.test');
  git('config', 'user.name', 'identity');

  const write = (path, content, mode = 0o644) => {
    const absolute = join(repo, path);
    mkdirSync(dirname(absolute), { recursive: true });
    writeFileSync(absolute, content);
    chmodSync(absolute, mode);
  };

  write('index.html', '<script src="https://unpkg.com/vue@3.5.43/dist/vue.global.js"></script>\n');
  write('assets/js/api/sessionCoordinator.js', 'export const A = 1;\n');
  write('tests/regression/some.test.mjs', "import { test } from 'node:test';\n");
  write('tests/package.json', '{ "name": "verification" }\n');
  write('tests/package-lock.json', '{ "lockfileVersion": 3 }\n');
  write('reports/FRONTEND-HANDOFF.vi.md', 'handoff\n');
  git('add', '--all');
  git('commit', '--quiet', '-m', 'baseline');

  // The delta a remediation round actually leaves behind: a file already modified, new untracked
  // helpers, and a new evidence directory. The wrapper and the browser helper are *untracked* on
  // purpose — that is the shape R7 left, and an untracked file is the one `git status` names as a
  // single line no matter how much is under it.
  write('assets/js/api/sessionCoordinator.js', 'export const A = 2;\n');
  write('tests/browser/helpers/browser-fixture.mjs', 'export const guard = true;\n');
  write('tools/run-frontend-gate.sh', '#!/usr/bin/env bash\n# wrapper\n', 0o755);
  write('reports/evidence/old.log', 'previous run\n');
  return { repo, write, git };
}

/** The identity the R7 wrapper recorded: names, not content. */
const statusHash = (repo) => execFileSync('git', ['-C', repo, 'status', '--porcelain'], { encoding: 'utf8' });

const withRepo = (fn) => {
  const fixture = makeRepo();
  try {
    return fn(fixture);
  } finally {
    rmSync(fixture.repo, { recursive: true, force: true });
  }
};

test('editing the bytes of an already-modified file changes the identity, and the old status hash does not', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    const statusBefore = statusHash(repo);
    assert.match(statusBefore, /^ M assets\/js\/api\/sessionCoordinator\.js$/m,
      'the fixture really is a file that git already calls modified');

    write('assets/js/api/sessionCoordinator.js', 'export const A = 2; // one more byte\n');

    const after = buildManifest(repo);
    assert.equal(statusHash(repo), statusBefore,
      'this is the defect: the file was already M, so the status text — and its hash — cannot move');
    assert.notEqual(after.digest, before.digest,
      'the content digest has to move, because the source the next run would test is not the same source');
  });
});

test('the bytes of an untracked helper change the identity, even though the status names only its directory', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    // The whole untracked tree collapses to one line. Nothing in it is identified, which is the other
    // half of the same defect: `?? tools/` is equally true of a one-line wrapper and of a full suite.
    const statusBefore = statusHash(repo);
    assert.match(statusBefore, /^\?\? tools\/$/m);

    write('tools/run-frontend-gate.sh', '#!/usr/bin/env bash\n# a different wrapper\n', 0o755);

    const after = buildManifest(repo);
    assert.equal(statusHash(repo), statusBefore, 'the status line is unchanged, so the edit is not on the record');
    assert.notEqual(after.digest, before.digest);
  });
});

test('an executable bit is part of the identity', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    assert.equal(before.files.find((file) => file.path === 'tools/run-frontend-gate.sh').mode, '100755');

    write('tools/run-frontend-gate.sh', '#!/usr/bin/env bash\n# wrapper\n', 0o644);

    const after = buildManifest(repo);
    assert.equal(after.files.find((file) => file.path === 'tools/run-frontend-gate.sh').mode, '100644');
    assert.notEqual(after.digest, before.digest, 'losing the executable bit changes what the tool can do');
  });
});

test('adding and deleting a file both change the identity', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);

    write('tests/regression/harness-boundaries.test.mjs', "import { test } from 'node:test';\n");
    const added = buildManifest(repo);
    assert.notEqual(added.digest, before.digest);
    assert.ok(added.files.some((file) => file.path === 'tests/regression/harness-boundaries.test.mjs'));

    rmSync(join(repo, 'tests/regression/harness-boundaries.test.mjs'));
    const removed = buildManifest(repo);
    assert.notEqual(removed.digest, added.digest);
    assert.equal(removed.digest, before.digest, 'a deleted file puts the identity back where it was');
  });
});

test('the same tree produces the same digest however the filesystem feels about it', () => {
  withRepo(({ repo }) => {
    const first = buildManifest(repo);
    // Touching mtimes is what a checkout, a copy or a `touch` does, and none of it changes the source.
    for (const file of first.files) {
      const stamp = new Date(Date.UTC(1999, 0, 1));
      utimesSync(join(repo, file.path), stamp, stamp);
    }
    const second = buildManifest(repo);
    assert.equal(second.digest, first.digest, 'mtime is not identity');
    assert.deepEqual(second.files, first.files);
  });
});

test('evidence written by a run is outside the identity, so a run cannot invalidate its own record', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    // What the wrapper does after the producer finishes: a log, a manifest and a snapshot, all under
    // reports/evidence. If those were hashed, the digest would change the instant the run recorded it
    // and every run would read as having drifted from itself.
    write('reports/evidence/unit-20260928T000000Z.log', 'pass 220\n');
    write('reports/evidence/unit-20260928T000000Z.meta', 'exit: 0\n');
    write('reports/evidence/unit-20260928T000000Z.manifest.json', '{ "digest": "..." }\n');
    assert.equal(buildManifest(repo).digest, before.digest);
    assert.ok(!collectSourcePaths(repo).some((path) => path.startsWith('reports/evidence/')));
  });
});

test('node_modules, git and the Playwright output directories are not source', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    write('tests/node_modules/playwright/index.js', 'module.exports = 1;\n');
    write('tests/test-results/.last-run.json', '{ "status": "passed" }\n');
    write('tests/playwright-report/index.html', '<html></html>\n');
    assert.equal(buildManifest(repo).digest, before.digest);
  });
});

test('an env-shaped path is excluded by name even inside an included tree', () => {
  withRepo(({ repo, write }) => {
    const before = buildManifest(repo);
    write('assets/js/.env.production', 'SECRET=fake\n');
    const manifest = buildManifest(repo);
    assert.equal(manifest.digest, before.digest);
    assert.ok(!collectSourcePaths(repo).some((path) => path.includes('.env')), 'no credential can reach a manifest');
  });
});

test('a manifest names what was in the run, and the base tree is labelled as the base', () => {
  withRepo(({ repo }) => {
    const manifest = buildManifest(repo);
    assert.equal(manifest.schema, IDENTITY_SCHEMA);
    assert.equal(manifest.digest, digestOf(manifest.files));
    assert.ok(manifest.repo.head, 'HEAD is recorded');
    assert.ok(manifest.repo.baseTree, 'and the base tree, named as the base rather than as "source"');
    assert.equal(manifest.repo.branch, manifest.repo.branch);
    assert.deepEqual(manifest.files.map((file) => file.path), [...manifest.files.map((file) => file.path)].sort(),
      'a sorted manifest is what makes the digest independent of directory order');
    for (const file of manifest.files) {
      assert.match(file.mode, /^100(644|755)$/);
      assert.equal(typeof file.size, 'number');
      assert.match(file.sha256, /^[0-9a-f]{64}$/);
    }
  });
});

test('a snapshot restores every file the manifest names, with the mode the manifest recorded', () => {
  withRepo(({ repo }) => {
    const manifest = buildManifest(repo);
    const archive = buildSnapshot(repo, manifest.files);
    const target = mkdtempSync(join(tmpdir(), 'frontend-restore-'));
    try {
      writeFileSync(join(target, 'snapshot.tar.gz'), archive);
      execFileSync('tar', ['-xzf', 'snapshot.tar.gz'], { cwd: target, stdio: 'pipe' });
      for (const file of manifest.files) {
        const restored = join(target, file.path);
        const actual = readFileSync(restored);
        assert.equal(actual.length, file.size, `${file.path} size`);
        assert.equal(execFileSync('sha256sum', [restored], { encoding: 'utf8' }).slice(0, 64), file.sha256,
          `${file.path} content`);
        const executable = (execFileSync('stat', ['-c', '%a', restored], { encoding: 'utf8' }).trim().endsWith('5'));
        assert.equal(executable, file.mode === '100755', `${file.path} mode`);
      }
    } finally {
      rmSync(target, { recursive: true, force: true });
    }
  });
});

test('the same content snapshots to the same bytes, and a changed byte changes them', () => {
  withRepo(({ repo, write }) => {
    const first = buildSnapshot(repo, buildManifest(repo).files);
    const second = buildSnapshot(repo, buildManifest(repo).files);
    assert.deepEqual(first, second, 'a snapshot that varies run to run cannot be compared across runs');

    write('assets/js/api/sessionCoordinator.js', 'export const A = 3;\n');
    assert.notDeepEqual(buildSnapshot(repo, buildManifest(repo).files), first);
  });
});

test('the CLI writes what the library builds, and reports the digest on stdout', () => {
  withRepo(({ repo }) => {
    const out = join(repo, 'reports', 'evidence', 'cli.manifest.json');
    const printed = execFileSync('node', [TOOL, '--repo', repo, '--out', out], { encoding: 'utf8' });
    const written = JSON.parse(readFileSync(out, 'utf8'));
    assert.equal(written.digest, buildManifest(repo).digest);
    assert.match(printed, new RegExp(written.digest), 'the digest the wrapper records is the digest on stdout');

    // `--print-digest` alone is what the wrapper pipes into its metadata, so it has to be the only
    // thing on stdout: a line of prose there would end up inside a recorded hash field.
    assert.equal(
      execFileSync('node', [TOOL, '--repo', repo, '--out', out, '--print-digest', '--quiet'], { encoding: 'utf8' }).trim(),
      written.digest
    );
  });
});

test('a usage error is exit 2 and an unreadable repository is exit 3, not a zero that looks like a pass', () => {
  const statusOf = (args) => {
    try {
      execFileSync('node', [TOOL, ...args], { stdio: 'pipe' });
      return 0;
    } catch (error) {
      return error.status;
    }
  };
  assert.equal(statusOf([]), 2, 'no arguments is a usage error');
  assert.equal(statusOf(['--nonsense']), 2, 'an unknown option is a usage error');
  assert.equal(statusOf(['--repo', '/nonexistent-repo', '--out', '/tmp/unused.json']), 3,
    'a repository that cannot be read is distinguishable from a usage error');
});
