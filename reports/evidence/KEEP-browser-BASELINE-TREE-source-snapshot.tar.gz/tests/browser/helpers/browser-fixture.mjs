/**
 * Shared browser fixture: the boundaries a browser run is not allowed to cross, and the barriers it is
 * allowed to wait on.
 *
 * Two things here exist because "the test passed" was previously achievable without either.
 *
 * **Egress.** Binding the servers to 127.0.0.1 is not a browser guard: the page can still reach any
 * host the machine can, and a suite that quietly fetched something from the internet would still
 * report green. `installEgressGuard()` runs on the browser context *before* any page exists, allows
 * exactly the loopback fixture origins plus the pinned CDN origin the app loads its runtime from, and
 * records — and aborts — everything else. `egress-canary.spec.mjs` proved it fires and is not part of
 * the suite; a guard nobody has seen fail is a comment.
 *
 * **Barriers.** `navigator.locks.query()` is an observable answer to "is the writer request queued?",
 * and the stand-in's hold/release control is an observable answer to "has the server finished
 * answering?". Together they replace `waitForTimeout(1200)` with something a report can stand behind.
 *
 * @see fake-api.mjs for the stand-in this talks to.
 */

import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { expect } from '@playwright/test';

/** The static server for this worktree, and the stand-in API. Loopback only. */
export const STATIC_ORIGIN = `http://127.0.0.1:${process.env.FRONTEND_STATIC_PORT || 4173}`;
export const API_ORIGIN = `http://127.0.0.1:${process.env.FRONTEND_API_PORT || 18788}`;

const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');

/**
 * The exact artifacts the app is allowed to load from a package CDN.
 *
 * These are read out of the loader rather than written down here, because a hand-kept copy of a list
 * that already exists in the source is a list that will be right until the day somebody bumps a version
 * and forgets this file. `check-cdn-pins` fails the run on an unpinned reference, so the two together
 * mean the allowlist can only ever be as wide as the loader's own pinned references.
 *
 * The unit is the *artifact*, not the host (FA8-03). An origin allowlist cannot tell
 * `axios@1.20.0/dist/axios.min.js` from `axios@1.21.0/...` or from a package nobody pinned at all, and
 * both of those are exactly what a "the app loads from unpkg" rule waves through.
 */
const PINNED_ARTIFACT_PATTERN = /https:\/\/(?:unpkg\.com|cdn\.jsdelivr\.net)\/[^"'\s)]+/g;

/**
 * The files that name the app's pinned CDN dependencies.
 *
 * This is the same list `tools/check-cdn-pins.cjs` scans, and it has to stay the same list: that script
 * is what fails the run when a reference is not pinned to an exact version, and this is what turns those
 * references into the allowlist. Deriving one from a different set of files would mean the two disagree
 * about what "pinned" means — which is how `index.html`'s three runtime dependencies (vue itself, the
 * SFC loader and vue-i18n) went missing from the first version of this list, and how the guard ended up
 * refusing the app's own boot.
 */
const CDN_REFERENCE_FILES = ['index.html', 'vue/Loader.js', 'assets/js/init.js', 'assets/js/appServices.js'];

const readPinnedArtifacts = () => {
  const found = new Set();
  for (const file of CDN_REFERENCE_FILES) {
    let source = '';
    try {
      source = readFileSync(join(REPO_ROOT, file), 'utf8');
    } catch (_error) {
      continue;
    }
    for (const match of source.matchAll(PINNED_ARTIFACT_PATTERN)) found.add(match[0]);
  }
  return [...found].sort();
};

export const PINNED_ARTIFACTS = readPinnedArtifacts();

/**
 * The CDNs the app reaches that cannot be pinned the way a package can.
 *
 * Tailwind is served as a build from a bare host with no versioned path, and the Google Fonts stylesheet
 * is a query-addressed family list. There is no artifact to pin, so these are allowed by origin — which
 * is a real limitation of the policy and is recorded as one, next to the reason, rather than left as an
 * unexplained host in a list of hosts. Everything else has to match a pinned artifact exactly.
 */
export const ORIGIN_SCOPED_ALLOWANCES = [
  {
    origin: 'https://cdn.tailwindcss.com',
    reason: 'Tailwind is served as a runtime build from a bare host with no versioned path, so there is no artifact to pin; the loader installs it at boot and the app does not render without it.'
  },
  {
    origin: 'https://fonts.googleapis.com',
    reason: 'The loader requests Noto families from a query-addressed stylesheet rather than a versioned file, so the exact request cannot be pinned to an artifact.'
  },
  {
    origin: 'https://fonts.gstatic.com',
    reason: 'The font binaries that the stylesheet above points at are content-addressed by Google and are not named by the loader at all.'
  }
];

/**
 * The fixture servers, on every name the loopback answers to.
 *
 * `127.0.0.1` and `localhost` are different origins to a browser, so the endpoint-switch cases reach the
 * same stand-in through both. Enumerating the hostnames here keeps that legitimate move working while
 * still refusing a *port* nothing in this run started — a blanket "any loopback" rule would let a case
 * quietly talk to whatever else the machine happens to be listening on.
 */
const LOOPBACK_HOSTNAMES = ['127.0.0.1', 'localhost', '[::1]'];

const fixtureOrigin = (origin) => new URL(origin);

export const FIXTURE_ORIGINS = [...new Set(
  [STATIC_ORIGIN, API_ORIGIN].flatMap((origin) => {
    const parsed = fixtureOrigin(origin);
    return LOOPBACK_HOSTNAMES.map((hostname) => `${parsed.protocol}//${hostname}:${parsed.port}`);
  })
)];

const artifactKey = (url) => `${url.origin}${url.pathname}`;

/**
 * The egress decision, as a pure function of a URL, so it can be tested without a browser.
 *
 * `reasonFor()` returns `null` for anything allowed and a sentence for anything refused. A guard that can
 * only say yes or no produces failures nobody can act on; this one can say "this is the pinned artifact"
 * and "this is the same host at a version nobody pinned".
 *
 * A pinned *stylesheet* references fonts through relative `url(...)`s that no source file names, so the
 * allowlist cannot be only the exact strings — it has to be the exact strings plus whatever the runtime
 * resolves inside those artifacts' own version directories. That is still a pin: a request under
 * `bootstrap-icons@1.11.0/` cannot be "the wrong version", because the version is part of the directory.
 * What it is not is a host rule — `bootstrap-icons@1.11.1/` and `@latest/` get refused all the same.
 */
export function createEgressPolicy({
  pinnedArtifacts = PINNED_ARTIFACTS,
  originScoped = ORIGIN_SCOPED_ALLOWANCES,
  fixtureOrigins = FIXTURE_ORIGINS
} = {}) {
  const artifacts = new Set();
  const versionDirs = new Map();
  for (const raw of pinnedArtifacts) {
    const url = new URL(raw);
    artifacts.add(`${url.origin}${url.pathname}`);
    const slash = url.pathname.lastIndexOf('/');
    const dir = url.pathname.slice(0, slash + 1);
    const list = versionDirs.get(url.origin) ?? [];
    list.push(dir);
    versionDirs.set(url.origin, list);
  }
  const scoped = new Map(originScoped.map((entry) => [entry.origin, entry.reason]));
  const fixture = new Set(fixtureOrigins);

  return {
    /** @returns {string|null} null when the request is allowed, otherwise why it is not. */
    reasonFor(raw) {
      let url;
      try {
        url = new URL(raw);
      } catch (_error) {
        return `"${raw}" is not an absolute URL, so this suite will not decide whether it is one of ours`;
      }
      // A scheme with no origin of its own (`data:`, `blob:`) is not egress. Refusing to parse one must
      // not turn into a hang, and blocking it would break the app rather than test it.
      if (!['http:', 'https:'].includes(url.protocol)) return null;
      if (fixture.has(url.origin)) return null;
      if (artifacts.has(artifactKey(url))) return null;
      if ((versionDirs.get(url.origin) ?? []).some((dir) => url.pathname.startsWith(dir))) {
        // A resource inside a pinned dependency's own version directory, e.g. the font files a pinned
        // stylesheet references by relative path. It inherits the dependency's pin instead of opening
        // the host: a wrong version is a different directory.
        return null;
      }
      if (scoped.has(url.origin)) return null;
      return `${url.origin}${url.pathname} is not one of the pinned artifacts the loader names, and `
        + `${url.origin} is not an allowed build CDN (${[...scoped.keys()].join(', ')})`;
    },
    allows(raw) {
      return this.reasonFor(raw) === null;
    }
  };
}

export const egressPolicy = createEgressPolicy();

const isLoopback = (hostname) => ['127.0.0.1', 'localhost', '::1', '[::1]'].includes(hostname);

/**
 * Installs the outbound guard on a context, before any page is created.
 *
 * Every decision is recorded with its reason, so a red run says which rule refused a request rather than
 * only that something was refused.
 *
 * @returns {{blocked: Array, requests: Array, policy: object}}
 */
export async function installEgressGuard(context, { policy = egressPolicy } = {}) {
  const blocked = [];
  const requests = [];

  await context.route('**/*', async (route) => {
    const request = route.request();
    const reason = policy.reasonFor(request.url());

    requests.push({
      url: request.url(),
      method: request.method(),
      allowed: reason === null,
      reason
    });

    if (reason === null) {
      await route.continue();
      return;
    }

    // Record before refusing: a run that is going to be debugged needs the evidence even though the
    // request is not made.
    blocked.push({ url: request.url(), method: request.method(), reason });
    await route.abort('blockedbyclient');
  });

  return {
    blocked,
    requests,
    policy,
    /**
     * Declares that this case means to provoke egress, and how many refusals it expects.
     *
     * The teardown treats any blocked request as a failure, because a guard that blocks something and
     * lets the suite report green has verified nothing. A negative-control case is the one legitimate
     * exception, and it has to say how many it wanted — otherwise "the guard works" is a case that
     * blocks nothing and passes for the wrong reason.
     */
    expectBlocked(count) {
      const seen = blocked.splice(0, count === undefined ? blocked.length : count);
      if (count !== undefined) {
        expect(seen.length, `the case provoked ${seen.length} blocked request(s) but declared ${count}`).toBe(count);
      }
      return seen;
    }
  };
}

/** A context with the guard already installed, for tests that need more than one page. */
export async function newGuardedContext(browser, options = {}) {
  const context = await browser.newContext(options);
  const guard = await installEgressGuard(context, options.egress);
  return { context, guard };
}

/** The kinds of problem a page can produce. An allowance has to name one of them. */
const PROBLEM_KINDS = ['console', 'pageerror', 'requestfailed'];

/**
 * Collects console errors, uncaught page errors and failed requests.
 *
 * A negative case is allowed to produce errors, but it has to name the one it expects: a filter that
 * accepts anything teaches the suite nothing.
 *
 * The three kinds are kept apart on purpose (FA8-04). One shared list of patterns, matched against every
 * kind, meant that an allowance written for a refused HTTP request also swallowed an uncaught `pageerror`
 * that merely contained the same word — so a case could fail loudly in the product and still report
 * green. An uncaught exception has to be declared as an uncaught exception to be tolerated.
 */
export function collectPageProblems(page, { label = 'page' } = {}) {
  const consoleErrors = [];
  const consoleWarnings = [];
  const pageErrors = [];
  const failedRequests = [];
  const allowances = [];

  page.on('console', (message) => {
    // Warnings are collected because the product reports some settled states there — "a temporary
    // refresh failure; keeping the current session" is how the app says it did *not* end the
    // session, which is a barrier a test can wait on instead of sleeping.
    if (message.type() === 'error') consoleErrors.push(message.text());
    if (message.type() === 'warning') consoleWarnings.push(message.text());
  });
  page.on('pageerror', (error) => pageErrors.push(`${label}: ${error.message}`));
  page.on('requestfailed', (request) => {
    // A request the guard refused is reported by the guard, not twice here.
    if (request.failure()?.errorText === 'net::ERR_BLOCKED_BY_CLIENT') return;
    failedRequests.push(`${request.method()} ${request.url()} — ${request.failure()?.errorText}`);
  });

  // Every problem as one shape, so an allowance can be matched against the kind and the request rather
  // than against a sentence that happens to contain a status code.
  const events = () => [
    ...consoleErrors.map((text) => ({ kind: 'console', text })),
    ...pageErrors.map((text) => ({ kind: 'pageerror', text })),
    ...failedRequests.map((text) => {
      const match = /^(\w+) (\S+) — (.+)$/.exec(text) || [];
      return { kind: 'requestfailed', text, method: match[1] || '', url: match[2] || '', errorText: match[3] || '' };
    })
  ];

  // An allowance may be a substring or a pattern, because "Network Error" is a literal axios string
  // while a stack of request URLs is not. `String.includes` throws on a RegExp, so both go through
  // the same test rather than only the one that happens to work.
  const matches = (text, pattern) => (pattern instanceof RegExp ? pattern.test(text) : text.includes(pattern));

  const covered = (event) => {
    for (const allowance of allowances) {
      if (allowance.matched >= allowance.limit) continue;
      if (allowance.kind !== event.kind) continue;
      if (allowance.method && allowance.method !== event.method) continue;
      if (allowance.url && !matches(event.url, allowance.url)) continue;
      if (!matches(event.text, allowance.pattern)) continue;
      allowance.matched += 1;
      return true;
    }
    return false;
  };

  const render = (event) => `${event.kind}: ${event.text}`;

  /** The problems nobody declared, as `{ kind, text, … }` so a failure report can say which kind it was. */
  const problems = () => events().filter((event) => !covered(event));

  return {
    consoleErrors,
    consoleWarnings,
    pageErrors,
    failedRequests,
    /**
     * Declares one expected problem, and exactly which kind of problem it is.
     *
     * `scope.kind` is required — that is the whole point. `method` and `url` narrow a failed-request
     * allowance to one specific request, so allowing the abort this case causes does not also excuse an
     * unrelated one. `count` states how many the case expects, so an allowance cannot quietly grow into
     * a blanket.
     *
     * The reason is mandatory and is never part of the match: it is there to be read, not to narrow the
     * pattern until the pattern happens to pass.
     *
     * @param {{kind: string, method?: string, url?: string|RegExp, count?: number}} scope
     * @param {string|RegExp} pattern
     * @param {string} reason
     */
    allowError(scope, pattern, reason) {
      if (typeof scope === 'string' || scope instanceof RegExp) {
        throw new TypeError(
          'an allowance must name the kind of problem it covers, e.g. { kind: "console" }. '
          + 'One pattern for every kind is how an unrelated page error gets excused by an HTTP allowance.'
        );
      }
      const { kind, method = null, url = null, count = null } = scope || {};
      if (!PROBLEM_KINDS.includes(kind)) {
        throw new TypeError(`an allowance must name the kind of problem it covers: one of ${PROBLEM_KINDS.join(', ')}`);
      }
      if (!reason) throw new Error('an expected error needs a reason, or it is just a filter');
      if (typeof pattern !== 'string' && !(pattern instanceof RegExp)) {
        throw new TypeError('an allowance is a string or a RegExp');
      }
      if (pattern instanceof RegExp) {
        pattern = pattern.source.length > 400 ? new RegExp(pattern.source.slice(0, 400)) : pattern;
      }
      // A count may be a single number or a range `[atLeast, atMost]`. A range is for noise that is part
      // of the app's real behaviour but is *conditional* — the browser does not always log a refused
      // request, so a case that only sometimes trips it must be able to say "at most one" rather than
      // pretend it always happens. A single number is `[n, n]`; only a floor above zero makes "it never
      // happened" a failure, and the ceiling is what stops an allowance from quietly becoming a blanket.
      const [countMin, countMax] = Array.isArray(count)
        ? count
        : (count === null ? [0, null] : [count, count]);
      if (countMin !== null && (!Number.isInteger(countMin) || countMin < 0)) {
        throw new TypeError('an allowance count is a non-negative integer or a range of two of them');
      }
      if (countMax !== null && countMax !== Infinity && (!Number.isInteger(countMax) || countMax < countMin)) {
        throw new TypeError('an allowance count ceiling must be an integer at least the floor, or Infinity');
      }
      allowances.push({ kind, method, url, pattern, reason, count, countMin, countMax, matched: 0, limit: countMax ?? Infinity });
      return pattern;
    },
    get allowedErrors() {
      return allowances.map((allowance) => ({ ...allowance }));
    },
    problems,
    /** Waits for the app to *say* something, which is a settlement signal rather than a duration. */
    async waitForWarning(pattern, { timeout = 25_000 } = {}) {
      await expect
        .poll(() => consoleWarnings.some((text) => pattern.test(text)),
          { timeout, message: `no console warning matched ${pattern}` })
        .toBe(true);
      return consoleWarnings.filter((text) => pattern.test(text));
    },
    expectClean() {
      const outstanding = problems();
      // An allowance that declared a count and did not see it is a case that no longer does what it
      // says. An allowance with a floor of zero is admitting the noise is conditional, so seeing nothing
      // is not a failure — but the ceiling still is, because the same refusal is never legitimate twice.
      const miscounted = allowances
        .filter((allowance) => {
          const floor = allowance.countMin ?? 0;
          const ceiling = allowance.countMax ?? Infinity;
          return allowance.matched < floor || allowance.matched > ceiling;
        })
        .map((allowance) => `allowance for ${allowance.kind} expected `
          + `[${allowance.countMin ?? 0}, ${allowance.countMax ?? '∞'}] but matched ${allowance.matched} (${allowance.reason})`);
      const unused = allowances
        .filter((allowance) => allowance.matched === 0 && (allowance.countMin ?? 0) > 0)
        .map((allowance) => `allowance for ${allowance.kind} never matched anything: ${allowance.pattern} (${allowance.reason})`);

      expect([...outstanding.map(render), ...miscounted, ...unused],
        'the page produced problems that were not expected').toEqual([]);
    }
  };
}

/** The writer lock the app serialises session writes with. One name, so the tests can query it. */
export const WRITER_LOCK = 'frontend-session-write:auth-session-record';

/**
 * The cross-tab refresh coordination lock.
 *
 * This cannot be imported from the product: the app's modules are browser ESM loaded by
 * `<script type="module">`, and Playwright's Node loader treats them as CommonJS. So the value is
 * restated here and *pinned* instead — `tests/regression/refresh-lock-pin.test.mjs` reads the product
 * source and fails if the two ever disagree. A hard-coded copy with nothing checking it would be a
 * barrier that silently stops observing anything the day the product renames its lock.
 *
 * Tests match on the prefix: the suffix is the identity and session, which a test should not have to
 * reconstruct to ask "is a rotation queued?".
 */
export const REFRESH_LOCK_PREFIX = 'frontend-refresh:';

/**
 * `navigator.locks.query()` from the page: what the browser says about held and queued lock requests.
 * This is the observable that replaces "wait a second and hope the request is queued".
 */
export const lockState = (page) => page.evaluate(async (name) => {
  if (!navigator.locks?.query) return { supported: false, held: 0, pending: 0 };
  const snapshot = await navigator.locks.query();
  const mine = snapshot.held.filter((entry) => entry.name === name);
  const queued = snapshot.pending.filter((entry) => entry.name === name);
  return {
    supported: true,
    held: mine.length,
    pending: queued.length,
    heldModes: mine.map((entry) => entry.mode),
    pendingModes: queued.map((entry) => entry.mode)
  };
}, WRITER_LOCK);

/** Waits until a lock request for the writer lock is genuinely queued in the browser. */
export async function waitForPendingWriterLock(page, { timeout = 20_000 } = {}) {
  await expect
    .poll(async () => (await lockState(page)).pending, { timeout, message: 'no writer-lock request became pending' })
    .toBeGreaterThan(0);
}

/** Waits until no writer-lock request is queued and none is held, i.e. the writer finished. */
export async function waitForWriterLockFree(page, { timeout = 30_000 } = {}) {
  await expect
    .poll(async () => {
      const state = await lockState(page);
      return state.pending + state.held;
    }, { timeout, message: 'a writer-lock request never finished' })
    .toBe(0);
}

/**
 * The control plane of the stand-in.
 *
 * Every call is refused loudly if the base is not a loopback test endpoint: the Node side of a browser
 * run has the same reachability the page does, and an unguarded `fetch` here would be exactly the hole
 * the browser guard closes.
 */
export function controlPlane({ base = API_ORIGIN } = {}) {
  const parsed = new URL(base);
  if (!isLoopback(parsed.hostname)) {
    throw new Error(`the control plane may only address a loopback test endpoint, not ${base}`);
  }

  const post = async (path, patch) => {
    const response = await fetch(`${base}${path}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(patch ?? {})
    });
    if (!response.ok) throw new Error(`control ${path} answered ${response.status}`);
    return response.json();
  };

  return {
    base,
    reset: () => post('/__fake/reset'),
    setConfig: (patch) => post('/__fake/config', patch),
    /** Holds matching responses open until released, so nothing in a test has to guess a duration. */
    hold: (routes) => post('/__fake/hold', { routes }),
    release: (routes) => post('/__fake/release', { routes }),
    requests: async () => (await (await fetch(`${base}/__fake/requests`)).json()).requests,
    /** What the peer has finished answering, as `{ method, path, status }`. */
    completed: async () => (await (await fetch(`${base}/__fake/completed`)).json()).completed,
    sessions: async () => (await (await fetch(`${base}/__fake/sessions`)).json()).sessions,
    held: async () => (await (await fetch(`${base}/__fake/held`)).json()),
    ready: async () => (await (await fetch(`${base}/__fake/ready`)).json())
  };
}

/* ------------------------------------------------------------------------------------------------
 * The session helpers every browser spec needs.
 *
 * These lived in `session-invariants.spec.mjs` and were copied into `session-flow.spec.mjs`, which is
 * how the two files ended up disagreeing about what "signed in" means. They are here now so that a
 * browser spec cannot get a weaker boundary than the suite next to it: one record key, one DOM
 * definition of signed in, one way to hold a lock, one set of collectors.
 * ---------------------------------------------------------------------------------------------- */

/** The one canonical record, and the per-key mirror older code still reads. */
export const RECORD_KEY = 'auth-session-record';
export const LEGACY_KEYS = ['user', 'token', 'expires_at', 'refresh_token', 'refresh_expires_at'];
export const noLegacyBearers = Object.fromEntries(LEGACY_KEYS.map((key) => [key, null]));

export const readSessionRecord = (page) => page.evaluate((key) => {
  const raw = window.localStorage.getItem(key);
  return raw === null ? null : JSON.parse(raw);
}, RECORD_KEY);

export const readLegacyKeys = (page) => page.evaluate((keys) => (
  Object.fromEntries(keys.map((key) => [key, window.localStorage.getItem(key)]))
), LEGACY_KEYS);

export const readApiBaseUrl = (page) => page.evaluate(() => window.localStorage.getItem('api-base-url'));

/**
 * Waits for a condition on the stored record.
 *
 * The predicate is serialised into the page, so it takes everything it needs as an argument: one that
 * closed over a test variable would be evaluated against `undefined` over there, which is a confusing
 * way to be told "not defined".
 */
export const waitForRecord = (page, predicate, arg = null) => page.waitForFunction(
  ({ key, source, expected }) => {
    const raw = window.localStorage.getItem(key);
    const record = raw === null ? null : JSON.parse(raw);
    // eslint-disable-next-line no-new-func
    return new Function('record', 'arg', `return (${source})(record, arg);`)(record, expected);
  },
  { key: RECORD_KEY, source: predicate.toString(), expected: arg },
  { timeout: 25_000 }
);

export const isState = (state) => (record, arg) => record?.state === arg;
export const versionAbove = (record, arg) => Number.isInteger(record?.version) && record.version > arg;
export const noUsableSession = (record) => record?.state !== 'active' || !record?.accessToken;

/**
 * Points the app at the loopback API and switches the shipped mock adapter off.
 *
 * `requestTimeoutMs` exists for the cases that hold a response open on purpose: the app's own request
 * timeout is 15s, and a hold that outlasts it is answered by the *client* giving up, not by the peer —
 * which would quietly turn "a late answer arrived" into "the client timed out first".
 */
export const useLiveApi = (page, apiBase = API_ORIGIN, { requestTimeoutMs = null } = {}) => page.addInitScript(({ base, timeout }) => {
  window.localStorage.setItem('api-base-url', base);
  window.localStorage.setItem('mock-api', 'false');
  if (timeout) window.localStorage.setItem('api-request-timeout-ms', String(timeout));
}, { base: apiBase, timeout: requestTimeoutMs });

/** Waits for the app to have booted far enough to have read its configuration. */
export const waitForApp = (page) => page.waitForFunction(
  () => document.body && document.body.innerText.length > 0 && window.localStorage.getItem('api-base-url') !== null,
  null,
  { timeout: 45_000 }
);

/** The DOM state that means "this tab has a session", and the one that means it does not. */
export const expectSignedIn = async (page) => {
  await expect(page.getByTestId('user-menu-toggle').first()).toBeVisible({ timeout: 25_000 });
  await expect(page.locator('button[title]', { hasText: /login|đăng nhập/i }).first()).toBeHidden();
};

export const expectSignedOut = async (page) => {
  await expect(page.getByTestId('user-menu-toggle')).toHaveCount(0, { timeout: 25_000 });
  await expect(page.locator('button[title]', { hasText: /login|đăng nhập/i }).first()).toBeVisible();
};

/**
 * Who the signed-in DOM says it is.
 *
 * "Signed in" as an icon is not an identity: a tab can render a user menu for a session it does not own,
 * which is the exact failure a cross-tab case has to catch. So the name comes off the toggle and the
 * email out of the panel it opens, and the menu is closed again — a later `logoutViaUi` clicks that same
 * toggle, which would close an open menu instead of opening it.
 */
export const signedInUser = async (page) => {
  const toggle = page.getByTestId('user-menu-toggle').first();
  await expect(toggle).toBeVisible({ timeout: 25_000 });
  const name = String((await toggle.getAttribute('title')) ?? '');

  await toggle.click();
  // The panel has no test id of its own, so the email is the one line in it that looks like an email.
  const emailLine = page.locator('div.truncate').filter({ hasText: /@/ }).last();
  await emailLine.waitFor({ state: 'visible', timeout: 15_000 });
  const email = String(await emailLine.innerText()).trim();
  await toggle.click();
  await emailLine.waitFor({ state: 'hidden', timeout: 15_000 });

  return { name, email };
};

export const logoutViaUi = async (page) => {
  await page.getByTestId('user-menu-toggle').first().click({ timeout: 20_000 });
  await page.getByTestId('logout-menu-item').first().click();
  await page.getByTestId('confirm-modal-confirm').click();
};

/**
 * Fills in the real login form and waits for the record, without navigating.
 *
 * A test that needs to sign in *while something else is in flight* must not reload: a reload destroys
 * the very promise it is trying to race. The modal may already be open (the app opens it when a
 * session ends), so both paths are handled.
 */
export async function submitLoginForm(page, { email = 'browser@example.test', password = 'fake-password' } = {}) {
  const emailField = page.locator('#email');
  if (!(await emailField.isVisible().catch(() => false))) {
    await page.locator('button[title]', { hasText: /login|đăng nhập/i }).first().click();
    await emailField.waitFor({ state: 'visible', timeout: 30_000 });
  }
  await emailField.fill(email);
  await page.locator('#password').fill(password);
  await page.getByTestId('login-submit').click();
  await waitForRecord(page, isState('active'), 'active');
  await expectSignedIn(page);
}

export async function signIn(page, { expired = false, ...credentials } = {}) {
  // An already-expired access token is what puts the app on the refresh path, instead of a test that
  // waits an hour for the clock to do it.
  if (expired) await setFixtureConfig({ accessTtlSeconds: -60 });
  await page.goto('/');
  await waitForApp(page);
  await submitLoginForm(page, credentials);
}

/**
 * Holds the writer lock from another tab, for real.
 *
 * The point is not a fake queue: a second page of the same origin really does hold the browser's
 * writer lock, and the session writer in the first page really does wait on it. The flag is set only
 * once the lock is granted, so "waiting" is never confused with "has not started yet".
 */
export async function holdWriterLock(page) {
  await page.evaluate((name) => new Promise((resolve) => {
    navigator.locks.request(name, () => new Promise((release) => {
      window.__releaseWriterLock = release;
      window.__writerLockHeld = true;
      resolve();
    }));
  }), WRITER_LOCK);
  await page.waitForFunction(() => window.__writerLockHeld === true, null, { timeout: 10_000 });
}

export const releaseWriterLock = (page) => page.evaluate(() => {
  if (window.__releaseWriterLock) window.__releaseWriterLock();
  window.__writerLockHeld = false;
});

/**
 * Counts `storage` events per key in the page.
 *
 * Adoption is a *read*, so a tab that observed a tombstone must not write one. "It did not write" has
 * no positive signal to wait for, but it has a countable one: this tab's own writes are not events,
 * while another tab's are — so the number of events a key received is the number of writes that
 * happened, and "exactly one" is an assertion rather than a sleep.
 */
export async function installStorageWatcher(page) {
  await page.addInitScript(() => {
    window.__storageEvents = Object.create(null);
    window.addEventListener('storage', (event) => {
      if (!event || !event.key) return;
      window.__storageEvents[event.key] = (window.__storageEvents[event.key] || 0) + 1;
      (window.__storageEventLog ||= []).push({ key: event.key, newValue: event.newValue });
    });
  });
  return {
    count: (key) => page.evaluate((k) => window.__storageEvents?.[k] ?? 0, key),
    log: () => page.evaluate(() => window.__storageEventLog ?? [])
  };
}

/** The default stand-in control plane, for specs that address the loopback API directly. */
export const control = controlPlane({ base: API_ORIGIN });
export const setFixtureConfig = (patch) => control.setConfig(patch);

/** A request the stand-in has received. "The server saw it" is not a guess. */
export const waitForFixtureRequest = (path, { control: plane = control } = {}) => expect
  .poll(async () => (await plane.requests()).some((entry) => entry.path === path),
    { timeout: 20_000, message: `the stand-in never received ${path}` })
  .toBe(true);

/** A response the stand-in has finished sending. */
export const waitForFixtureResponse = (path, status, { control: plane = control } = {}) => expect
  .poll(async () => (await plane.completed()).some((entry) => entry.path === path && (status === undefined || entry.status === status)),
    { timeout: 20_000, message: `the stand-in never finished answering ${path}` })
  .toBe(true);

/**
 * Parks a response **in the browser**, before it reaches the peer.
 *
 * The peer's own hold answers late but keeps the peer's request open, which is not the same thing: the
 * peer's request is already being handled, so anything with a deadline on the client side — a request
 * timeout, a lock lease, a single-flight window — expires while the answer is parked, and the case ends
 * up measuring the client's impatience instead of the race. Parking at the browser means the peer has
 * not seen the request at all, so "the client is waiting" and "the peer has answered" are two separate,
 * separately observable states.
 *
 * @returns {{parked: () => Array, waitForParked: (fragment?: string) => Promise<Array>, release: () => Promise<number>}}
 */
export async function holdBrowserResponse(context, pathFragment) {
  const parked = [];
  let releasing = false;
  const waiters = [];

  const settle = () => {
    while (waiters.length > 0) waiters.shift()();
  };

  await context.route(`**${pathFragment}**`, async (route) => {
    if (releasing) {
      // After a release the route is transparent: the egress guard is the only thing left in the chain.
      await route.fallback();
      return;
    }
    parked.push(route);
    settle();
  });

  return {
    parked: () => [...parked],
    /** Resolves once a request matching the fragment is parked, i.e. the client is waiting for it. */
    async waitForParked(fragment = pathFragment) {
      if (parked.some((route) => route.request().url().includes(fragment))) return parked;
      await new Promise((resolve) => waiters.push(resolve));
      return parked;
    },
    async release() {
      releasing = true;
      const held = parked.splice(0, parked.length);
      for (const route of held) await route.continue();
      return held.length;
    }
  };
}
