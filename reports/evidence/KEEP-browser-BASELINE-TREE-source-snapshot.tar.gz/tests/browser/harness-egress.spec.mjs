/**
 * FA8-03 — the egress guard, proved against a real browser.
 *
 * `regression/harness-boundaries.test.mjs` proves the *policy* as a pure function. That is not the same
 * claim: a policy can be exactly right while nothing ever installs it, and the round6 suite was in
 * precisely that state for two of its spec files. So this case is about the wiring:
 *
 *   - the shared `context` fixture refused an unpinned artifact from a host the app legitimately uses,
 *     which only happens if the route handler ran before the request left the page;
 *   - the same case confirms the pinned artifact from that host still loads, so a guard that refuses
 *     everything would not pass either;
 *   - a spec that takes Playwright's stock `{ page }` and never asks for a guard gets the guard anyway,
 *     which is the part that used to be a README claim rather than a fact.
 *
 * The negative controls are the review's two probes: a path on an allowed host that nobody pinned, and
 * a version of a real dependency that is not the pinned one. Both must be *refused and counted* — a
 * guard that aborts without reporting has not told anyone anything.
 */

import { test, expect } from './fixtures.js';
import { PINNED_ARTIFACTS, collectPageProblems, useLiveApi, waitForApp } from './helpers/browser-fixture.mjs';

/** A dependency the app never asked for, on a host the app does use. */
const UNPINNED_ON_ALLOWED_HOST = 'https://unpkg.com/not-a-pinned-dependency@latest/index.js?FAKE_marker=1';

/** The right path at a version nobody pinned. */
const WRONG_VERSION_OF_A_REAL_DEPENDENCY = 'https://unpkg.com/axios@1.21.0/dist/axios.min.js';

test.describe('the egress boundary, proved rather than assumed', () => {
  test('the shared context refuses an unpinned artifact on a host the app legitimately uses', async ({ context }) => {
    const guard = (await import('./fixtures.js')).currentGuard.value;
    expect(guard, 'the shared context fixture installs a guard').not.toBeNull();

    const page = await context.newPage();
    const problems = collectPageProblems(page, { label: 'probe' });
    await useLiveApi(page);
    await page.goto('/');
    await waitForApp(page);

    const outcome = await page.evaluate(async ({ unpinned, bumped }) => {
      const attempt = (url) => new Promise((resolve) => {
        const image = new Image();
        image.onload = () => resolve('loaded');
        image.onerror = () => resolve('refused');
        image.src = url;
        setTimeout(() => resolve('hung'), 5_000);
      });
      return { unpinned: await attempt(unpinned), bumped: await attempt(bumped) };
    }, { unpinned: UNPINNED_ON_ALLOWED_HOST, bumped: WRONG_VERSION_OF_A_REAL_DEPENDENCY });

    expect(outcome, 'the app may not reach anything the loader does not name, at any version')
      .toEqual({ unpinned: 'refused', bumped: 'refused' });

    const refusedUrls = guard.blocked.map((entry) => entry.url);
    expect(refusedUrls, 'and the guard reported why, not just that it fired').toContain(UNPINNED_ON_ALLOWED_HOST);
    expect(refusedUrls).toContain(WRONG_VERSION_OF_A_REAL_DEPENDENCY);
    for (const entry of guard.blocked) {
      expect(entry.reason, `${entry.url} was refused without a reason`).toMatch(/not one of the pinned artifacts/);
    }

    // A guard that refuses everything would have produced the same two refusals, so the allow half of
    // the policy is proved in the same run.
    expect(PINNED_ARTIFACTS, 'the real dependencies are still named by the loader').toContain(
      'https://unpkg.com/axios@1.20.0/dist/axios.min.js'
    );
    expect(guard.requests.some((entry) => entry.allowed), 'and allowed requests really are being allowed')
      .toBe(true);

    guard.expectBlocked(2);
    // A refused request surfaces twice — as a failed request and as a console error from the browser —
    // and both are the two requests this case provoked on purpose. Declaring them separately is the
    // point of the typed allowance: one declaration would have covered an unrelated console error too.
    problems.allowError({ kind: 'requestfailed', count: 2, url: /not-a-pinned-dependency|axios@1\.21\.0/ },
      'net::ERR_BLOCKED_BY_CLIENT',
      'the two requests this case provokes on purpose are refused by the guard it is testing');
    problems.allowError({ kind: 'console', count: 2 }, /net::ERR_BLOCKED_BY_CLIENT/,
      'the browser logs each of those two refusals as a resource-load console error');
    problems.expectClean();
  });

  test('a spec that never asks for a guard still gets one', async ({ page }) => {
    // This is the round6 defect, restated as a test. `backend-contract-mock.spec.mjs` and
    // `session-seed-smoke.spec.mjs` took the stock `{ page }` and ran with no boundary; nothing failed,
    // because nothing was watching. Here the page is the plain fixture page — no `newGuardedContext`,
    // no `installEgressGuard` — and egress is still refused.
    const guard = (await import('./fixtures.js')).currentGuard.value;
    expect(guard, 'the stock page comes from a context that already has a guard').not.toBeNull();

    const outcome = await page.evaluate(() => new Promise((resolve) => {
      const image = new Image();
      image.onload = () => resolve('loaded');
      image.onerror = () => resolve('refused');
      image.src = 'https://evil.example.com/probe.js';
      setTimeout(() => resolve('hung'), 5_000);
    }));

    expect(outcome, 'an unexpected origin is refused on a page that never opted in').toBe('refused');
    expect(guard.blocked.map((entry) => entry.url)).toContain('https://evil.example.com/probe.js');
    guard.expectBlocked(1);
  });
});
