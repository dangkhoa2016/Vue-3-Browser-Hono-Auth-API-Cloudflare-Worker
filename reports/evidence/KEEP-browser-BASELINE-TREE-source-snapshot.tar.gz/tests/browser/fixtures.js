/**
 * The `test` every browser spec in this suite imports instead of Playwright's.
 *
 * It exists because of FA8-03. Two of the specs took Playwright's stock `{ page }` and never installed
 * the egress guard, so those files ran with no network boundary at all while the README claimed every
 * context had one — and nothing in the run could have noticed, because a run with no guard and a run
 * with a permissive guard both report green.
 *
 * So the boundary is no longer something a spec remembers to ask for. It is part of the `context`
 * fixture, installed before any page can exist, and the two things a guard is usually assumed to do are
 * done here rather than hoped for:
 *
 *   - a blocked request *fails* the test. Aborting a request does not fail anything by itself; a guard
 *     that quietly blocks half the suite's network and reports success has verified nothing.
 *   - a page that never asked for the guard gets a context that cannot reach anything, which is a louder
 *     failure than a spec that quietly has no boundary.
 *
 * Specs that need several tabs still call `newGuardedContext(browser)`, which uses the same policy.
 */

import { test as base, expect } from '@playwright/test';

import { installEgressGuard } from './helpers/browser-fixture.mjs';

/** The guard installed for the current test, so a spec can assert on what was refused. */
export const currentGuard = { value: null };

export const test = base.extend({
  context: async ({ context }, use, testInfo) => {
    const guard = await installEgressGuard(context);
    currentGuard.value = guard;

    try {
      await use(context);
    } finally {
      // A guard nobody has seen refuse something is a comment, so refusing something is a failure.
      // The one legitimate exception is a case that deliberately provokes egress, and it says so by
      // clearing the list before it finishes.
      expect(guard.blocked, `the guard refused ${guard.blocked.length} request(s) in "${testInfo.title}"; `
        + 'a case that means to provoke egress must call guard.expectBlocked() instead')
        .toEqual([]);
    }
  }
});

export { expect };
export const { describe } = base;
