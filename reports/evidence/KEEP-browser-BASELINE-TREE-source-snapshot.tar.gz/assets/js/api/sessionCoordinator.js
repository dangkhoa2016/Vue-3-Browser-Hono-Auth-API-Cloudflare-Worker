/**
 * sessionCoordinator.js — single-flight and cross-tab coordination for access-token refresh.
 *
 * Why this exists (F04): refresh used to be guarded by a per-store boolean, so N parallel
 * requests in one tab, or two tabs sharing `localStorage`, could each mint a new token. The
 * backend contract (v1) answers the losing race with HTTP 409 `REFRESH_ALREADY_ROTATED` and
 * promises at most one successor, so the client must adopt the winner instead of retrying.
 *
 * Policy implemented here:
 * - one refresh in flight per session context (`ensureFreshSession` shares a single promise per
 *   context; a new context never waits for, and is never served by, an older flight);
 * - the lifecycle channel is named after the **API identity only**. Naming it after the session
 *   meant a tab that opened before the login subscribed to an empty namespace and never heard the
 *   login that happened in another tab (review FA-02);
 * - before refreshing inside a cross-tab lock, re-read the persisted snapshot instead of using a
 *   stale refresh-token snapshot;
 * - on a refresh conflict, wait a bounded time for the winning session and adopt it; when no
 *   winner appears, ask for a new login — never loop and never mint another token;
 * - a rejected refresh token is `invalid` (clear the session); 429/5xx/network are `temporary`
 *   (keep the session, do not retry in a loop);
 * - every outcome is validated against the context that started the operation before it can have
 *   a side effect, so a refresh that resolves late cannot replace or clear a newer session;
 * - adopting a record is **read-only**: it hydrates memory and never writes storage or raises the
 *   snapshot version, so a storage listener cannot cause a write loop between tabs (review FA-02).
 *
 * Design record: FRONTEND-SESSION-DESIGN.vi.md §4.
 */

export const REFRESH_CONFLICT_CODES = ['REFRESH_ALREADY_ROTATED'];
export const DEFAULT_CONFLICT_TIMEOUT_MS = 5000;
export const DEFAULT_POLL_INTERVAL_MS = 100;
export const DEFAULT_REFRESH_LOCK_TIMEOUT_MS = 5000;

/** Refresh outcomes that are not a token. `unavailable` is this module's reduced-mode refusal. */
export const REFRESH_OUTCOME_KIND = Object.freeze({
  OK: 'ok',
  STALE: 'stale',
  ADOPTED: 'adopted',
  CONFLICT: 'conflict',
  TEMPORARY: 'temporary',
  INVALID: 'invalid',
  UNAVAILABLE: 'unavailable'
});

/** Lifecycle messages. They carry metadata only — never a token. */
export const SESSION_EVENT_TYPE = Object.freeze({
  SESSION: 'session',
  ENDED: 'ended'
});

export const SESSION_CHANNEL_PREFIX = 'frontend-session:';
export const REFRESH_LOCK_PREFIX = 'frontend-refresh:';

export function isRefreshConflict(status, code) {
  if (status === 409) return true;
  return typeof code === 'string' && REFRESH_CONFLICT_CODES.includes(code.toUpperCase());
}

export function classifyRefreshError(error) {
  const status = error?.response?.status ?? null;
  const code = error?.response?.data?.error?.code ?? error?.code ?? null;

  if (isRefreshConflict(status, code)) {
    return { kind: 'conflict', status, code };
  }

  if (status === 401 || status === 403) {
    return { kind: 'invalid', status, code };
  }

  if (status === 429 || (status !== null && status >= 500)) {
    return { kind: 'temporary', status, code };
  }

  if (status === null) {
    return { kind: 'temporary', status, code };
  }

  return { kind: 'invalid', status, code };
}

const createDefaultChannelFactory = (name) => {
  if (typeof BroadcastChannel === 'undefined') return null;
  try {
    return new BroadcastChannel(name);
  } catch (_error) {
    return null;
  }
};

const getDefaultLocks = () => {
  try {
    return typeof navigator !== 'undefined' ? navigator.locks : null;
  } catch (_error) {
    return null;
  }
};

/**
 * The credential pair a rotation replaces, named with the lifecycle it belongs to.
 *
 * Handing this to the store is what makes a rotation checkable: the writer compares it with the
 * record under the lock and refuses anything that is neither it nor the successor. It is a plain
 * value, derived from what was read rather than from what is remembered, and it is never published
 * on the lifecycle channel or logged.
 *
 * @param {object|null} session
 * @returns {{identity: string, sessionId: string, accessToken: string, refreshToken: string}|null}
 */
export function rotationPredecessor(session) {
  if (!session || !session.accessToken || !session.refreshToken) return null;
  return {
    identity: String(session.identity ?? ''),
    sessionId: String(session.sessionId ?? ''),
    accessToken: session.accessToken,
    refreshToken: session.refreshToken,
  };
}

/**
 * Takes a lock without letting the wait be unbounded, and without letting a late grant run anyway.
 *
 * `Promise.race` alone is not a timeout: the queued request stays in the lock manager and is granted
 * later, which then performs the work the caller already stopped waiting for. So the fence is
 * installed first, the callback checks it on entry, and the deadline settles the caller. A granted
 * request that finds the fence closed returns the fenced result without dispatching anything.
 *
 * @returns {Promise<*>} the callback's result, or the fenced result once the deadline passes
 */
export async function acquireWithDeadline(locks, name, run, { timeoutMs, now = () => Date.now(), fence = null } = {}) {
  if (!locks || typeof locks.request !== 'function') return run();

  let closed = false;
  let granted = false;
  let timer = null;
  const startedAt = now();
  const deadline = Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : null;

  const guarded = async () => {
    // The callback only runs once the lock is ours, so this is the moment the *wait* is over.
    granted = true;
    if (closed) return fence ? await fence('lock-acquisition-timeout') : null;
    return run();
  };

  if (deadline === null) return locks.request(name, guarded);

  const acquisition = locks.request(name, guarded);
  // Only the wait for the lock is bounded. `run()` itself is the network call and the commit that
  // follows, and those have their own timeouts.
  //
  // The Web Locks API keeps the lock until the callback settles, so `acquisition` does not resolve when
  // the lock is *granted* — it resolves when the work is done. Racing it against the deadline without
  // noticing that difference abandons any refresh slower than the deadline: the caller is handed the
  // fence while the request is still in flight, and when the answer finally arrives it is dropped on the
  // floor. The server has rotated the token by then, so the client is left holding a credential the peer
  // no longer accepts — a rotation the app paid for and threw away. So the deadline only settles the
  // caller while the lock is still somebody else's.
  //
  // The deadline is kept by two independent measures, because either one on its own can lie (FA8-02).
  // The wall clock says whether the deadline has been *reached*, which is why a timer that fires a little
  // early must re-arm instead of fencing a request that is still legitimately waiting. But a wall clock
  // can stop advancing or step backwards — and when it does, a single timer that just returns leaves the
  // caller waiting on a promise nothing will ever resolve, which turns the bound that exists to survive a
  // slow peer into the thing that hangs. So the timer's own intervals are counted as well: that budget is
  // spent whether or not the clock agrees, and whichever measure arrives first ends the wait. The budget is
  // deliberately *well past* the deadline (see below), so it only ever applies to a clock that is not
  // keeping time at all, and a merely coarse clock is still honoured on its own terms.
  const timeout = new Promise((resolve) => {
    const step = Math.min(50, Math.max(1, Math.ceil(deadline / 8)));
    // The counted budget is a backstop for a clock that never reaches the deadline at all — one that has
    // stopped or stepped backwards. A clock that is merely coarse still reaches the deadline, and must be
    // honoured on its own terms rather than preempted: the timer's own intervals cannot be trusted to
    // advance at their nominal rate on a loaded machine, so a budget too close to the deadline races the
    // very clock it exists to replace. It is kept deliberately far away (`8×`, capped) and only ever bites
    // the clock that is not keeping time at all.
    const budget = Math.min(deadline * 8, 15_000);
    let spent = 0;

    const tick = () => {
      if (granted || closed) return;
      if (now() - startedAt >= deadline || spent + step >= budget) {
        closed = true;
        resolve(fence ? fence('lock-acquisition-timeout') : null);
        return;
      }
      spent += step;
      timer = setTimeout(tick, step);
      if (timer && typeof timer.unref === 'function') timer.unref();
    };

    timer = setTimeout(tick, step);
    if (timer && typeof timer.unref === 'function') timer.unref();
  });

  try {
    return await Promise.race([acquisition, timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export function createSessionCoordinator(options = {}) {
  const {
    getIdentity = () => '',
    getSessionId = () => '',
    readSessionState = () => ({ status: 'absent', record: null }),
    readPersistedSession = null,
    /**
     * Reports whether this tab may take part in a token rotation at all.
     *
     * A tab that cannot serialise its writers has no honest way to commit a successor record, so
     * `false` here refuses the rotation *before* the network. It is deliberately separate from
     * `readSessionState`: a reduced-mode tab must not decide that by reading the shared record,
     * because the record it would read belongs to a session that is not its own.
     */
    canRotate = () => true,
    /**
     * The session this tab holds **in memory only**, used as the credential source while rotation is
     * unavailable. Never the shared record.
     */
    readMemorySession = () => null,
    performRefresh,
    applySession,
    /**
     * Adopts a record another writer already committed. A read, never a write: the record is in
     * storage already, so rotating it again would raise the version for nothing and turn a read
     * into a cross-tab write race (FR6-F). A caller that supplies none cannot confirm such a
     * commit, so the default refuses and the refresh reports no token.
     */
    adoptCommitted = null,
    onInvalidSession = async () => {},
    onTemporaryFailure = () => {},
    conflictTimeoutMs = DEFAULT_CONFLICT_TIMEOUT_MS,
    pollIntervalMs = DEFAULT_POLL_INTERVAL_MS,
    /**
     * How long a refresh may wait for the cross-tab coordination lock. Without a deadline, a
     * holder that never releases turns a refresh into a promise that never settles, and the caller's
     * request hangs forever. Exceeding it is reported as `unavailable`, never as a failed session.
     */
    lockTimeoutMs = DEFAULT_REFRESH_LOCK_TIMEOUT_MS,
    now = () => Date.now(),
    channelFactory = createDefaultChannelFactory,
    storageListenerTarget = null,
    storageListenerKey = 'auth-session-record',
    locks = getDefaultLocks(),
  } = options;

  const flights = new Map();
  let channel = null;
  let channelName = '';
  const sessionListeners = new Set();
  let storageListenerBound = false;

  /**
   * `applySession` is the store's guarded writer and resolves with a `CommitResult`, so a rotation
   * this coordinator did not actually commit must never be read back as a usable session. A commit
   * that reports `stale` means another writer won the lock; `unavailable` means the tab is in
   * reduced mode and promises nothing durable. Both mean "no token from here".
   */
  const isCommitted = (result) => result?.status === 'applied';

  const adoptCommittedSession = async (session, meta) => {
    if (typeof adoptCommitted === 'function') return adoptCommitted(session, meta);
    return { status: 'stale', record: null, reason: 'adoption-unsupported' };
  };

  const rotationAvailable = () => {
    try {
      return canRotate() !== false;
    } catch (_error) {
      // An unreadable policy is a refusal, not a permission: a rotation nobody can account for is
      // exactly the case this guard exists for.
      return false;
    }
  };

  // `readPersistedSession` is the historical name for "the usable session". Keep accepting it so a
  // caller does not have to be rewritten, but prefer the state reader when it is supplied: a
  // tombstone has to stay observable.
  const readState = typeof readSessionState === 'function' ? readSessionState : null;

  /**
   * The session this tab may present to a request, or null.
   *
   * In reduced mode the shared record is off limits: it is written by a tab that can serialise
   * writers and it describes *that* lifecycle. Reading it here is how a memory-only session for one
   * user ended up refreshing with another user's persisted refresh token (FR6-C). The only permitted
   * source in that mode is this tab's own memory, and only for the identity in context.
   */
  const readUsable = (context = null) => {
    if (!rotationAvailable()) {
      const own = typeof readMemorySession === 'function' ? readMemorySession() : null;
      if (!own || !own.accessToken) return null;
      const identity = context?.identity ?? getIdentity();
      if (identity && own.identity && own.identity !== identity) return null;
      return own;
    }

    if (readState) {
      const observed = readState();
      return observed && observed.status === 'active' ? observed.record : null;
    }
    return typeof readPersistedSession === 'function' ? readPersistedSession() : null;
  };
  const readStateOrEmpty = () => (readState ? readState() : { status: 'active', record: readUsable() });

  const contextKey = (context) => `${context?.identity ?? getIdentity()}|${context?.epoch ?? 'any'}`;

  const ensureChannel = () => {
    // Identity only: a tab that has not logged in yet must already listen on the namespace the
    // other tabs publish to.
    const name = `${SESSION_CHANNEL_PREFIX}${getIdentity()}`;

    if (channel && channelName === name) {
      return channel;
    }

    if (channel) {
      try { channel.close(); } catch (_error) { /* already closed */ }
      channel = null;
      channelName = '';
    }

    const created = channelFactory(name);
    channel = created;
    channelName = created ? name : '';

    if (created && typeof created.addEventListener === 'function') {
      created.addEventListener('message', (event) => {
        for (const listener of [...sessionListeners]) {
          try {
            listener(event?.data);
          } catch (error) {
            console.warn('[sessionCoordinator] session listener failed:', error);
          }
        }
      });
    }

    return channel;
  };

  const onRemoteSession = (listener) => {
    ensureChannel();
    sessionListeners.add(listener);
    return () => sessionListeners.delete(listener);
  };

  const publishSession = (session) => {
    const active = ensureChannel();
    if (!active || typeof active.postMessage !== 'function') return;
    try {
      // Only identity/sessionId/version travel between tabs. Tokens stay in the record; each
      // receiver re-reads and validates it, so no bearer is broadcast.
      active.postMessage({
        type: session ? SESSION_EVENT_TYPE.SESSION : SESSION_EVENT_TYPE.ENDED,
        identity: getIdentity(),
        sessionId: session?.sessionId ?? getSessionId(),
        version: session?.version ?? null
      });
    } catch (error) {
      console.warn('[sessionCoordinator] could not publish session:', error);
    }
  };

  /**
   * The storage event is the fallback for a browser without `BroadcastChannel`, for a tab that was
   * closed when the message was sent, and for a listener that was not bound yet. It carries the
   * same metadata and the receiver still re-reads the canonical record itself.
   */
  const bindStorageFallback = () => {
    if (storageListenerBound) return () => {};
    if (!storageListenerTarget || typeof storageListenerTarget.addEventListener !== 'function') {
      return () => {};
    }

    storageListenerBound = true;
    const handler = (event) => {
      if (event && event.key && event.key !== storageListenerKey) return;
      for (const listener of [...sessionListeners]) {
        try {
          listener({ type: SESSION_EVENT_TYPE.SESSION, identity: getIdentity(), source: 'storage' });
        } catch (error) {
          console.warn('[sessionCoordinator] session listener failed:', error);
        }
      }
    };

    storageListenerTarget.addEventListener('storage', handler);
    return () => {
      storageListenerBound = false;
      try { storageListenerTarget.removeEventListener('storage', handler); } catch (_error) { /* noop */ }
    };
  };

  const delay = (ms) => new Promise((resolve) => { setTimeout(resolve, ms); });

  const readWinner = (previousRefreshToken, context = null) => {
    const persisted = readUsable(context);
    if (!persisted) return null;
    if (previousRefreshToken && persisted.refreshToken === previousRefreshToken) return null;
    if (!persisted.accessToken) return null;
    return persisted;
  };

  /** Waits a bounded time for the tab that won the refresh race to publish its session. */
  const waitForWinner = async (previousRefreshToken, timeoutMs, context = null) => {
    const deadline = now() + timeoutMs;

    return new Promise((resolve) => {
      let settled = false;
      let poller = null;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        if (poller) clearInterval(poller);
        unsubscribe();
        resolve(value);
      };

      poller = setInterval(() => {
        const winner = readWinner(previousRefreshToken, context);
        if (winner) {
          finish(winner);
          return;
        }
        if (now() >= deadline) {
          finish(null);
        }
      }, pollIntervalMs);

      const unsubscribe = onRemoteSession(() => {
        const winner = readWinner(previousRefreshToken, context);
        if (winner) finish(winner);
      });

      const immediate = readWinner(previousRefreshToken, context);
      if (immediate) finish(immediate);
    });
  };

  const refreshWithCoordination = async (context, options = {}) => {
    const identity = context?.identity ?? getIdentity();
    const generationSnapshot = context?.epoch ?? null;

    // Reduced mode, and it is the *first* thing this function does: no lock is taken, no shared
    // record is read and no request is dispatched. A tab that cannot commit a successor record must
    // not spend a refresh token to find out (FR6-C).
    if (!rotationAvailable()) {
      return { kind: REFRESH_OUTCOME_KIND.UNAVAILABLE, reason: 'no-writer-serialization' };
    }

    const snapshot = readUsable(context) || {};
    const previousRefreshToken = snapshot.refreshToken || null;

    // The bearer that failed has already been replaced — by the flight this caller joined a moment
    // ago, or by another tab. Spending the refresh token again would race the rotation the server
    // already performed, and a backend that rotates strictly answers the second call with a
    // conflict. This is a read, so it needs no lock: it only skips a network call that has nothing
    // left to learn.
    const superseded = options.accessTokenUsed;
    if (superseded && snapshot.accessToken && snapshot.accessToken !== superseded) {
      // The record is already the successor, so there is nothing to rotate: this is a read.
      const applied = await adoptCommittedSession(snapshot, { identity, epoch: generationSnapshot, source: 'refresh-already-applied' });
      return isCommitted(applied) ? readUsable(context) : null;
    }

    const attempt = async () => {
      // Inside the lock the persisted session is authoritative: another tab may have won while
      // this tab was waiting, and that session must be adopted instead of rotated again.
      const persisted = readUsable(context);
      if (persisted?.accessToken && persisted.refreshToken !== previousRefreshToken) {
        return { kind: REFRESH_OUTCOME_KIND.ADOPTED, session: persisted };
      }

      // The credential that is about to be spent, captured here — after the re-read under the
      // coordination lock, immediately before dispatch. This is the rotation's predecessor: it is
      // the only thing that makes the eventual write a rotation rather than a blind overwrite
      // (FR6-E). It stays inside this module and is never logged or broadcast.
      const spent = persisted?.accessToken ? persisted : snapshot;
      const predecessor = rotationPredecessor(spent);

      const outcome = await performRefresh({
        identity,
        generation: generationSnapshot,
        refreshToken: spent.refreshToken ?? previousRefreshToken,
      });

      return { ...outcome, predecessor };
    };

    // The refresh lock is held across the commit, not just across the request.
    //
    // Releasing it as soon as the response was in left a window between "the server has rotated" and
    // "the record holds the successor": a second tab took the lock, re-read, still saw the
    // *predecessor* refresh token and spent it again (FA8-01). The window is closed by keeping the
    // whole re-read -> dispatch -> commit sequence inside one exclusive section, so a tab that
    // arrives later re-reads a *committed* successor and adopts it.
    //
    // The writer lock is still never held across the network: `performRefresh` has already resolved
    // by the time `applySession` asks for it, so the ordering stays refresh -> writer and the HTTP
    // call never sits inside a storage transaction.
    const exclusive = async () => {
      const outcome = await attempt();
      // Only an answer that became local state belongs inside the section. The remaining outcomes are
      // reported to another tab (a conflict waits for a winner, a 5xx keeps the session) and doing
      // that here would hold the lock for seconds while a tab that *has* the answer waited for it.
      if (outcome.kind !== REFRESH_OUTCOME_KIND.OK) return outcome;

      // The writer is the store's guarded commit, so it returns a CommitResult rather than a boolean:
      // `stale` means another writer won, `unavailable` means reduced mode promises nothing durable.
      // Neither may be read back as a usable session.
      const applied = await applySession(
        outcome.session,
        { identity, epoch: generationSnapshot, source: 'refresh' },
        { predecessor: outcome.predecessor || rotationPredecessor(snapshot) }
      );

      if (!isCommitted(applied)) {
        // A refusal is not a temporary backend condition and must not end the session: the caller is
        // told there is no token here, and the reason travels with it.
        return { kind: REFRESH_OUTCOME_KIND.STALE, reason: applied?.reason || 'commit-unconfirmed' };
      }

      return { kind: REFRESH_OUTCOME_KIND.OK, session: readUsable(context) };
    };

    let outcome;

    if (locks && typeof locks.request === 'function') {
      // The refresh lock bounds queueing, and only queueing: `acquireWithDeadline` stops settling the
      // caller once the lock is granted, so a slow network or a held writer cannot expire a rotation
      // that is already under way. Ordering is always refresh -> writer.
      outcome = await acquireWithDeadline(
        locks,
        `${REFRESH_LOCK_PREFIX}${identity}:${getSessionId()}`,
        exclusive,
        { timeoutMs: lockTimeoutMs, now, fence: async () => ({ kind: REFRESH_OUTCOME_KIND.UNAVAILABLE, reason: 'refresh-lock-timeout' }) }
      );
    } else {
      outcome = await exclusive();
    }

    if (outcome.kind === REFRESH_OUTCOME_KIND.UNAVAILABLE) {
      // Reduced mode, or the coordination lock could not be acquired in time. Either way nothing was
      // dispatched: report a temporary condition of this tab and leave the session alone.
      onTemporaryFailure({ status: null, code: outcome.reason || 'refresh-unavailable' });
      return null;
    }

    if (outcome.kind === REFRESH_OUTCOME_KIND.ADOPTED) {
      // The winner already persisted this session, so this is a read of shared state: adopting it
      // must not write a second record on top of the one the winning tab just committed.
      const adopted = await adoptCommittedSession(outcome.session, { identity, epoch: generationSnapshot, source: 'cross-tab' });
      return isCommitted(adopted) ? readUsable(context) : null;
    }

    if (outcome.kind === REFRESH_OUTCOME_KIND.OK) {
      // The commit already happened inside the coordination section, so there is nothing left to
      // write here: a second write would be the duplicate commit FA8-01's fix removes. Publishing is
      // the only remaining step, and it happens only for a commit that actually landed — announcing
      // an uncommitted rotation is what lets a losing tab adopt a token that was never stored.
      const committed = readStateOrEmpty();
      publishSession(committed?.record ? { sessionId: committed.record.sessionId, version: committed.record.version } : null);
      return outcome.session ?? readUsable(context);
    }

    if (outcome.kind === REFRESH_OUTCOME_KIND.STALE) {
      // Either the server had already moved on, or the commit was refused. A refusal keeps the
      // session as it is and reports a temporary condition of this tab: it is not a verdict on the
      // session, so it must not end it the way a rejected refresh token does.
      if (outcome.reason && outcome.reason !== 'superseded-refresh') {
        onTemporaryFailure({ status: null, code: outcome.reason });
      }
      return null;
    }

    if (outcome.kind === REFRESH_OUTCOME_KIND.UNAVAILABLE) {
      // Reduced mode reached through a caller that did not check `canRotate` itself. It is a
      // temporary condition of this tab, not a verdict on the session: report it as such and leave
      // the session alone, so the caller can retry once a durable session exists.
      onTemporaryFailure({ status: null, code: outcome.reason || 'no-writer-serialization' });
      return null;
    }

    if (outcome.kind === REFRESH_OUTCOME_KIND.CONFLICT) {
      const winner = await waitForWinner(previousRefreshToken, outcome.timeoutMs ?? conflictTimeoutMs, context);
      if (winner) {
        // The winner's record is already the persisted record: adopt it, do not rotate it again.
        const applied = await adoptCommittedSession(winner, { identity, epoch: generationSnapshot, source: 'conflict-winner' });
        return isCommitted(applied) ? readUsable(context) : null;
      }
      await onInvalidSession({
        reason: 'refresh-conflict-without-winner',
        status: outcome.status,
        code: outcome.code,
        context: { identity, epoch: generationSnapshot }
      });
      return null;
    }

    if (outcome.kind === REFRESH_OUTCOME_KIND.TEMPORARY) {
      onTemporaryFailure({ status: outcome.status, code: outcome.code });
      return null;
    }

    await onInvalidSession({
      reason: 'refresh-rejected',
      status: outcome.status,
      code: outcome.code,
      context: { identity, epoch: generationSnapshot }
    });
    return null;
  };

  /**
   * Returns a valid session snapshot, sharing one in-flight refresh per context. A caller that
   * arrives for a *different* context starts its own flight: it must never be handed the result of
   * a refresh that belongs to a session it did not ask about.
   *
   * `options.accessTokenUsed` is the bearer the caller was rejected for. It is what lets a caller
   * that arrives just after a flight finished notice that the rotation already happened.
   */
  const ensureFreshSession = (context = null, options = {}) => {
    const key = contextKey(context);
    const existing = flights.get(key);
    if (existing) return existing;

    const flight = refreshWithCoordination(context, options)
      .catch((error) => {
        if (flights.get(key) === flight) flights.delete(key);
        throw error;
      })
      .finally(() => {
        if (flights.get(key) === flight) flights.delete(key);
      });

    flights.set(key, flight);
    return flight;
  };

  const close = () => {
    if (channel) {
      try { channel.close(); } catch (_error) { /* already closed */ }
      channel = null;
      channelName = '';
    }
    unbindStorage?.();
    flights.clear();
    sessionListeners.clear();
  };

  const unbindStorage = bindStorageFallback();

  return {
    ensureFreshSession,
    publishSession,
    onRemoteSession,
    close,
    waitForWinner,
    /** Re-reads the record and tells listeners; used on focus/visibility reconciliation. */
    reconcile: () => {
      ensureChannel();
      for (const listener of [...sessionListeners]) {
        try {
          listener({ type: SESSION_EVENT_TYPE.SESSION, identity: getIdentity(), source: 'reconcile' });
        } catch (error) {
          console.warn('[sessionCoordinator] reconcile listener failed:', error);
        }
      }
    },
  };
}
