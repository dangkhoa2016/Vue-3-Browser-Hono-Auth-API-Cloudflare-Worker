# Frontend Execution Log — frontend-remediation-r7

Source identity cho mọi lệnh dưới đây (trừ khi ghi khác):
`branch=remediation/round6-wip head=a1db43b7e432795c41c727324d87c66f63c22cbb tree=55033e41514957bbd7c13289661018aa6980a91c`
Cwd `/tmp/opencode/r7/repo`, node v20.19.0, npm 10.8.2, git 2.43.0, Linux x86_64, Ubuntu 24.04.

## Task1 — Intake, restore, evidence harness

| # | Lệnh | Exit | Ghi chú |
| --- | --- | --- | --- |
| 1 | `sha256sum r6-task7-full.zip` | 0 | `bfdc3b49…7504` khớp §1 |
| 2 | python3 zipfile inventory (478 entries) | 0 | 0 absolute / traversal / backslash / symlink / duplicate; entries ở root |
| 3 | `unzip -q … -d /tmp/opencode/r7/artifact` | 0 | explicit destination; `cd r6-task7-full` sẽ hỏng (FA8-07) |
| 4 | `sha256sum -c --quiet MANIFEST.sha256` | 0 | 321 entries |
| 5 | `git clone --no-checkout --branch remediation/round6-wip <bundle> repo` | 0 | HEAD `a1db43b`, tree `55033e4`, 98 HEAD / 117 all |
| 6 | `git bundle verify …` | 0 | complete history, 11 refs |
| 7 | `git fsck --full` | 0 | sạch |
| 8 | `git checkout remediation/round6-wip` | 0 | status sạch trước patch |
| 9 | `git apply --whitespace=error-all patches/working-tree-changes.patch` | 0 | 6 modified |
| 10 | `git apply patches/new-file-browser-fixture.patch` | 0 | 1 untracked |
| 11 | so sánh byte 293 file repo vs `source-tree/` | 0 | 293/293 khớp, 0 lệch, 0 chỉ-có-ở-một-bên |
| 12 | `git diff --check` | 0 | sạch |
| 13 | pre-work backup (2 bundle + 2 patch + untracked + 293 hash) | 0 | `/tmp/opencode/r7/prework/` |
| 14 | tạo `tools/run-frontend-gate.sh` (mới) | 0 | wrapper bằng chứng |
| 15 | wrapper self-test `exit 7` | 7 | exit của producer giữ nguyên |
| 16 | wrapper self-test timeout 2s | 124 | nonzero |
| 17 | wrapper self-test `--timeout 0` | 2 | reject trước khi chạy |
| 18 | wrapper self-test success | 0 | |
| 19 | `npm --prefix tests ci --ignore-scripts --no-audit --no-fund` | 0 | 30 packages |
| 20 | `npm --prefix tests run test:static` | 0 | 11/11 CDN pin exact |
| 21 | `npm --prefix tests run test:unit` | 0 | 188 pass / 0 fail / 0 cancelled / 0 skipped, 24 suites |
| 22 | `node --test regression/*.test.mjs` (discovery đối chiếu) | 0 | lần 1: 187 pass + **1 cancelled**; lần 2: 188 pass, 0 cancelled → R7-OBS-01 |
| 23 | `npm --prefix tests run test:loopback` | 0 | 8 pass / 0 fail |
| 24 | `npx --prefix tests playwright install chromium` | 0 | binary về `~/.cache/ms-playwright` |
| 25 | `chromium.launch()` probe | fail | thiếu libatk/atk-bridge/atspi/xcomposite |
| 26 | `apt-get install -y libatk1.0-0t64 libatk-bridge2.0-0t64 libatspi2.0-0t64 libxcomposite1 libasound2t64` | 0 | **có owner cho phép**; 9 gói mới, 0 upgrade, 0 remove |
| 27 | `chromium.launch()` probe lại | 0 | `LAUNCH OK 141.0.7390.37` |
| 28 | `npm --prefix tests run test:browser` | **0** | **32/32 pass (11.0m)** |

Ghi chú môi trường: bước 26 là thay đổi system **ngoài phạm vi dự án frontend**; đã hỏi owner và được
cho phép trong session này. Không có thay đổi nào khác ngoài `/tmp/opencode/r7/` và các gói apt nêu trên.

## Baseline numbers (đã tự chạy, không phải log của vòng trước)

| Gate | Exit | Kết quả |
| --- | --- | --- |
| static | 0 | 11/11 pins |
| unit | 0 | 188 / 0 / 0 / 0, 24 suites |
| loopback | 0 | 8 pass |
| browser | 0 | 32 pass |

## Task2..10

(chưa chạy — sẽ bổ sung theo từng task)

## Task2 (FA8-01) — CLOSED

| # | Lệnh | Exit | Kết quả |
| --- | --- | --- | --- |
| 1 | `npm --prefix tests run test:unit` (gates file) | 0 | **194/194** sau 3 case refresh-commit mới + refresh-lock-pin 3/3 |
| 2 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** — gồm FA8-01 two-tab case (roles đảo: arriving tab rotate, winner tab chờ) |
| 3 | mutation: release refresh lock trước commit | fail | node test 4/5 đỏ; browser đỏ tại assert winner 0 dispatch |

## Task3 (FA8-02) — CLOSED

| # | Lệnh | Exit | Kết quả |
| --- | --- | --- | --- |
| 1 | `npm --prefix tests run test:unit` (gates file) | 0 | **199/199** sau 4 subtest deadline mới |
| 2 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** |

## Task4 (FA8-03/04) — CLOSED

| # | Lệnh | Exit | Kết quả |
| --- | --- | --- | --- |
| 1 | `node --test regression/harness-boundaries.test.mjs` | 0 | 21/21 policy + typed-allowance case (RED khi allowlist chỉ origin: 4 đỏ; allowance không phân kind: 7 đỏ) |
| 2 | `npx playwright test -g "egress boundary"` | 0 | 2/2 — probe FA8-03 thành Image load thật, refused + count; mutation origin-only → đỏ |
| 3 | `npm --prefix tests run test:unit` (gates file) | 0 | **220/220** |
| 4 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** (12.1m) — đợt đầu 27 đỏ vì guard chặn font bootstrap-icons (đã thêm version-directory rule), 3 đỏ vì count kỳ vọng không khớp noise có điều kiện (đã hỗ trợ `[atLeast,atMost]`), sau đó sạch |
| 5 | `npm --prefix tests run test:unit` (gates file) | 0 | **220/220** — kèm FA8-02 follow-up (backstop 2×→min(8×,15s)) chạy 5/5 ổn định |
| 6 | `npm --prefix tests run test:browser` (gates file) | 0 | **33/33** (11.9m) sau khi đổi backstop |

## Task5..10

(chưa chạy — sẽ bổ sung theo từng task)
