# FRONTEND-HISTORY-MAP — R10 (P9)

> **Trạng thái: mapping xong, REWRITE CHƯA CHẠY.** Bản ghi lịch sử, không phải tuyên bố đã fold.
> Chi tiết từng commit: `reports/FRONTEND-COMMIT-REVIEW.tsv`.
>
> **Scope review — đọc gì và không đọc gì.** Đã đọc **đầy đủ** message của cả 19 commit, **đầy đủ**
> danh sách file của từng commit, và **full diff theo hunk** của `b45bf57` (commit trộn) cùng các hunk
> còn tranh chấp (`assets/js/init.js`, `tests/package.json`). **Chưa** đọc từng hunk của `081c18d`
> (162k dòng) và các diff lớn khác — ở mức tên file và message. **88 commit baseline chưa đọc diff**
> nào; chỉ dùng làm gốc fold và xác nhận là ancestor. Theo đúng yêu cầu của plan, phần này là
> **PARTIAL**, và số 93 là mục tiêu chứ không phải kết quả đã đo.

## Baseline và delta

| Mốc | SHA | Commit |
| --- | --- | --- |
| Baseline R5 (read-only) | `761712b57968810153ea9ade1cbb11a7becce437` | 88 |
| HEAD R9 review state | `a1db43b7e432795c41c727324d87c66c63c22cbb` | 98 |
| Delta trên baseline | 10 commit | 88 + 10 = 98 |
| Mục tiêu P9 | 88 + **5** | **93** |

## Phát hiện làm thay đổi cả cách fold: 5 nhóm **đã** được fold một lần

Cả 5 commit nhóm mang trailer `Folded in from this round (same subject, one commit per group now):`
liệt kê các subject đã nuốt vào:

| Nhóm | Anchor | Số subject đã nuốt |
| --- | --- | --- |
| 1 Auth/transport/session/caller/deadline/identity | `20ac335` | 9 |
| 2 Monitoring capability/component/emits | `5589f9b` | 1 |
| 3 Audit extraction/props/events/filter/pagination | `3ea37cf` | 1 |
| 4 Export/env/backend contract/protected reset | `c31aa50` | 3 |
| 5 CDN/common gates/browser tooling | `2991465` | 3 |

Hệ quả trực tiếp: **clone phục hồi cũ (`r10-clone-old`) đã bị loại vì lý do thứ hai, không chỉ vì nó
mất `a1db43b`.** `cd9d8cd` trong clone đó mang subject *"Cover the new invariants and fix the harness
that hid three of them"* — trùng đúng subject đã nằm trong trailer của `2991465`. Nó đang **chép lại
nội dung đã fold**, không phải phục hồi thứ gì mới.

## Mapping WIP round6 → nhóm

| WIP | Subject | Message | Nhóm | Căn cứ |
| --- | --- | --- | --- | --- |
| `b45bf57` | Task1 discovery + Task2 logout ownership | **rỗng** | **1 + 5, phải tách** | xem dưới |
| `3266676` | Task3 reduced-mode safety | **rỗng** | 1 | chỉ `sessionCoordinator.js`, `authStore.js`, `session-write-order.test.mjs` — toàn bộ lãnh thổ nhóm 1 |
| `81afbab` | Task4 writer policy, rotation predecessor, lock fences | có body (4 bullet) | 1 | cả 8 file đều session/auth |
| `a7fa278` | Task5 profile and login caller ownership | có body | 1 | "caller ownership" nằm đúng trong tên trách nhiệm nhóm 1 |
| `a1db43b` | Task6 offline integration fixture + READY manifest | có body | 5 | cả 7 file đều browser/test-harness; **không cần tách** |

### `b45bf57` — commit trộn, tách 4/3

| Vào nhóm 5 (harness) | Vào nhóm 1 (auth) |
| --- | --- |
| `README.md` | `assets/js/stores/authStore.js` |
| `README.vi.md` | `tests/regression/auth-transport.test.mjs` |
| `tests/package.json` | `tests/regression/session-write-order.test.mjs` |
| `tools/test-browser.sh` | |

Căn cứ không phải suy đoán: 4 file nhóm 5 là **harness và tài liệu của harness** (mục "Verification
(test-only harness)" mô tả `npm --prefix tests run test:*` và `bash tools/test-browser.sh`); 3 file
nhóm 1 là **auth store và hai test tiêu thụ nó**. Hunk `tests/package.json` đổi `test:unit` từ
`node --test regression/` sang glob tường minh và thêm `test:loopback` vào `test:all` — đó là hành vi
discovery, thuộc harness.

## Mapping lớp dirty R9 (`1c56023`, 34 mục) và 5 commit R10

| Đích | Nội dung |
| --- | --- |
| Nhóm 1 | `assets/js/init.js`; `sessionCoordinator.js`; `session-invariants.spec.mjs`; `refresh-commit-order.test.mjs`; `session-write-order.test.mjs` |
| Nhóm 4 | `backend-contract-mock.spec.mjs`; `fake-api.mjs`; `playwright.config.mjs` (bản dirty) |
| Nhóm 5 | 19 file tooling mới (`tools/*` ×8, `validate-reports`, `frontend-source-identity`, `frontend-run-claims`, 2 wrapper, selftest, `browser-gate-env`), 7 test mới, 4 `reports/*`, `session-flow.spec.mjs`, `session-seed-smoke.spec.mjs`, `tests/package.json` (bản dirty) |
| Nhóm 2, 3 | không có mục nào |

`assets/js/init.js` là file **production code** duy nhất trong lớp dirty không thuộc harness, và nó
đi vào **nhóm 1 chứ không phải nhóm 5**: hunk thêm `httpClient.js` + `mainStore.js` vào
`options.moduleCache` với lý do ghi nguyên văn trong comment — hai đánh giá module là **hai
singleton API identity**, nên credential của server này có thể bị gửi sang server khác (F03). Đây
chính là loại lỗi plan cảnh báo: fold nó vào CDN HEAD sẽ đúng về hình thức và sai về trách nhiệm.

5 commit R10 còn lại (`081c18d`, `2ece0a6`, `6f21c86`, `930d194`, `80dec1d`, `157437b`, `af223b1`,
`e139661`) đều về evidence harness và report → **nhóm 5**.

## Thứ tự bắt buộc khi fold

1. `20ac335` (1) → `5589f9b` (2) → `3ea37cf` (3) → `c31aa50` (4) → `2991465` (5)

Ba file bị sửa bởi nhóm sau nhóm trước, nên thứ tự là bắt buộc chứ không phải lựa chọn:
- `RealtimeAlertRulesSection.vue`, `RealtimeOpsControlsSection.vue`, `RealtimeToggleRuleConfirmModal.vue` — tạo ở (2), sửa ở (4)
- `Navbar.vue`, `backend-contract-ui.test.mjs` — (4) rồi (5)
- `fake-api.mjs`, `playwright.config.mjs`, `backend-capabilities.spec.mjs` — (4) rồi (5)

## Message: cái gì phải viết lại

`b45bf57` và `3266676` **không có body**. Plan cấm ghép WIP title vào message cuối, nên cả hai phải
viết message mới mô tả semantics. `81afbab`, `a7fa278`, `a1db43b` có body thật nên giữ phần kết luận
và viết lại phần đầu cho khớp nhóm đích.

**Lỗi cần biết: message của `1c56023` ghi "41 R8/R9 manifests"** — số đo được là **44 trong 45**
(một run R8 không có trường `repo.head`). Commit recovery này không được sống sót vào lịch sử cuối
nên lỗi tự biến mất, nhưng con số được ghi lại ở đây để không ai chép lại.

## Điều kiện an toàn đã biết

Sau khi rewrite: `git diff --exit-code <validated-checkpoint> <final-head>` phải rỗng và tree hash phải
bằng. Rewrite **chỉ đổi lịch sử, không đổi nội dung**, nên nó kiểm chứng được — lỗi hunk-mapping sẽ
lộ ra ở bước này, không phải ở P10.

**REWRITE CHƯA CHẠY.** Không có commit nào bị viết lại, không có nhánh nào mới được tạo. Còn nợ:
đọc hunk-level `081c18d`, và quyết định có cần `git mv`/rename gì không.
