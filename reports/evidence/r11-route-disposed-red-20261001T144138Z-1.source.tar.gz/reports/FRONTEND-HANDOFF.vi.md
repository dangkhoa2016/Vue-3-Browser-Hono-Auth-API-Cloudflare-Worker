# Frontend R11 — trạng thái hiện hành

Overall **PARTIAL**. Cập nhật 2026-10-01. Chưa có prepared-backend READY hoặc reduced-mode policy được owner duyệt; nguyên nhân cancellation R7 vẫn UNRESOLVED. Không suy acceptance backend từ local fake API.

| Trường | Giá trị |
| --- | --- |
| Input ZIP | `/workspaces/jjgsubl/frontend-remediation-r10-review-package.zip` |
| Input SHA256 | `155c9c06b94dafa327350ecc4a9e584a5a35bbdb336d62ad5db9729c62c24403` |
| Input HEAD | `d523d07d423d415ccb341049a1d007ad2b84d3eb`, 108 commits |
| Baseline bất biến | `761712b57968810153ea9ade1cbb11a7becce437`, 88 commits |
| Workspace | `/workspaces/frontend-r11-work`, branch `remediation/r11` |
| Current identity | Tính bằng `tools/frontend-source-identity.mjs`; exact comparisons ở `FRONTEND-SOURCE-COMPARISONS.json`. Git pin của bản bàn giao phải lấy từ external attestation, tránh SHA tự tham chiếu trong tree. |
| Review | Đã full-review 108/108 commit đầu vào; review R11 behavior và một fresh whole-branch review. |
| History | N9 candidate v4 có93commit/tree equality, G1–G4 own-revision boundaries đã kiểm tra. Final G5 sẽ pin ngoài tree sau khi freeze reports/evidence. |
| Artifact | N10 đang chuẩn bị. Chưa có exact-ZIP postpackage attestation. |

Repo gốc, ZIP R10 và baseline không bị sửa. Các bản ghi cũ trong `reports/history/` và evidence giữ nguyên identity/exits của từng run. Không dùng số liệu lịch sử làm claim source hiện tại.

| Task | Kết quả và giới hạn |
| --- | --- |
| N1 | Restore/audit input đúng pin; Chromium dùng thư viện trích xuất cục bộ, không cài hệ thống. |
| N2 | Strict manifest + bounded ustar audit, bytes/modes/file-set verification trước restore. 38 snapshot lịch sử thiếu vẫn log-only. |
| N3 | Cache key từ manifest/lock/runtime; atomic publish, graph/version/metadata/bin/entrypoint checks và concurrency probes. Không claim full installed-JavaScript byte integrity. |
| N4 | Restore exact 0644/0755 dưới nonroot/default ACL và umask 022/077/002. |
| N5 | Egress xét URL/method/type; HTTP redirect bị chặn trước khi tới receiver. Tailwind pin direct 3.4.17. Sáu teardown canary phải bị bắt; suite canary có exit 1 có chủ đích, không gọi là suite PASS. WebSocket nằm ngoài guard này. |
| N6 | Native/SFC dùng chung context; endpoint A/B và late success/error/finally có fence. Export recheck sau async decode và trước caller toast. Prepared backend integration PENDING, chưa READY. |
| N7 | Fail closed khi monotonic clock không hợp lệ/đi lùi; late grant chờ cùng asynchronous fence. Rollback runbook có allowlist và close-all-tabs. Owner reduced-mode policy BLOCKED; R7 cancellation UNRESOLVED. |
| N8 | 33 finding IDs và source-bound claims; các run failed/canary giữ đúng exit. Final validator và current report synchronization đang hoàn tất. |
| N9 | Full input review DONE; Full mapping và G1–G4 boundary receipts hoàn tất; final G5 freeze/tree equality và post-rewrite execution còn chờ. |
| N10 | Exact ZIP/restore/fresh gates/external attestation chưa hoàn tất. |

Các sửa từ review cuối được tái hiện RED trước khi sửa: redirect vượt guard, stale Blob decode tải file sau đổi session, invalid initial clock, backward clock reading và late grant trong lúc fence đang chờ. Fixture browser sau đó phải sửa held-response release sang `route.fallback()` để không bỏ qua guard. Khi đóng context, Playwright hủy request trước sự kiện close; guard chỉ chấp nhận đúng lỗi target-closed sau khi context bắt đầu đóng. Mọi lỗi network khác vẫn fail.

Bằng chứng hiện tại được liệt kê bằng run ID đầy đủ trong `FRONTEND-RUN-CLAIMS.json`; đối chiếu content bằng `FRONTEND-SOURCE-COMPARISONS.json`. Bản handoff này sẽ được cập nhật sau khi full browser và N9/N10 thực sự kết thúc, không dự báo kết quả.

Bước tiếp theo: hoàn tất gates trên source cuối, backup/fresh-clone validated checkpoint; dựng và kiểm tra G1–G5 bằng lockfile/helpers của từng revision; freeze bundle/source, đóng gói và kiểm exact ZIP trong thư mục mới. Không push/deploy hoặc sửa backend.

Local gates trên source review cuối: unit457/457, browser56/56, loopback10/10, static exit0; zero cancelled/unexpected skipped. Sáu teardown canary bị bắt đúng assertion, raw exit1.

- unit: `r11-review-closed-unit-20261001T075416Z-1`
- static: `r11-review-closed-static-20261001T075416Z-1`
- loopback: `r11-review-closed-loopback-20261001T075416Z-1`
- browser: `browser-r11-review-closed-browser-20261001T075431Z-1`
- canary: `browser-r11-review-closed-canaries-20261001T075517Z-1`

Gates có cùng digest `b50bd872d7996eab66ad5e0c5d4ecf0e94c8f1f3f03f78ac516aca64713fbb88`; sau gate chỉ handoff/matrix/execution thay đổi, đối chiếu bằng manifests trong SOURCE-COMPARISONS.

Named acceptance mapping: `FRONTEND-SESSION-ACCEPTANCE.tsv` (167 named tests đã quan sát trong raw logs +3 acceptance còn mở). Raw boundary receipts và full review maps được bàn giao trong package.
