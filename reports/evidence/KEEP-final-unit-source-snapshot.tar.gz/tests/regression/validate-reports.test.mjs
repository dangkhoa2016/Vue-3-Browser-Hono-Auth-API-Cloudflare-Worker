/**
 * FR9-06 — the reports must be checkable, and a checker that cannot fail is decoration.
 *
 * Every previous round of this work ended by writing a matrix and a handoff that described what had been
 * verified. Nothing read them. That is a specific and repeatable failure: a number in prose ("233/233",
 * "browser 33/33", "closed") is a claim about the world that no test ever makes, so it survives every
 * change that should have invalidated it. Delete the log, add a test, mark a finding closed that was only
 * read — and the report stays perfectly readable and quietly untrue.
 *
 * So the case that matters most here is not "the real reports validate". It is that each rule fires on a
 * doctored copy. A validator that only ever passes is worse than none, because it is cited as if it were
 * a check. Every case below therefore breaks one thing on purpose and asserts that the specific rule
 * notices, and each names the lie it would otherwise let through.
 *
 * The rules under test (see tools/validate-reports.mjs):
 *   1. a row with the wrong number of cells — the quiet one, because a short TSV row renders fine;
 *   2. a required finding with no row;
 *   3. a status outside the closed set;
 *   4. a VERIFIED row with no test, or naming evidence that does not exist;
 *   5. a path in a row that is not a file in the repo;
 *   6. a gate count asserted in the handoff that no log in the evidence directory records;
 *   7. a row VERIFIED in the matrix while the handoff still calls it OPEN.
 *   8. a matrix that does not declare the schema this validator reads.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, readdirSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

import { validateReports } from '../../tools/validate-reports.mjs';

const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');

/** The findings the validator insists on seeing. Narrower than the real default, so a case can be about one row. */
const REQUIRED = ['FR9-01', 'FR9-02'];

const SCHEMA_LINE = '# schema=frontend-finding-matrix/1';

const HEADER = [
  'finding_id', 'task', 'layer', 'severity', 'status', 'summary',
  'test_or_layer', 'source', 'evidence', 'limitation'
].join('\t');

/**
 * A whole repo-shaped tree: the reports and evidence the validator reads, plus a couple of real source
 * files so a `source` cell can point at something that exists.
 */
function makeRepo({ rows, handoff, logs = { 'unit-1-20260928T000000Z-1.log': '# tests 3\n# pass 3\n# fail 0\n' } } = {}) {
  const root = mkdtempSync(join(tmpdir(), 'validate-reports-'));
  mkdirSync(join(root, 'reports', 'evidence'), { recursive: true });
  mkdirSync(join(root, 'assets', 'js'), { recursive: true });
  mkdirSync(join(root, 'tests', 'regression'), { recursive: true });
  writeFileSync(join(root, 'assets', 'js', 'app.js'), 'export const x = 1;\n');
  writeFileSync(join(root, 'tests', 'regression', 'thing.test.mjs'), "// test\n");
  writeFileSync(join(root, 'reports', 'FRONTEND-FINDING-MATRIX.tsv'), `${SCHEMA_LINE}\n${HEADER}\n${rows.join('\n')}\n`);
  writeFileSync(
    join(root, 'reports', 'FRONTEND-HANDOFF.vi.md'),
    handoff ?? '# Handoff\n\n| unit | 3/3 | `unit-1-20260928T000000Z-1` |\n'
  );
  for (const [name, body] of Object.entries(logs)) {
    writeFileSync(join(root, 'reports', 'evidence', name), body);
  }
  return root;
}

/** One well-formed row, so a case can break exactly one thing about it. */
const goodRow = (id, overrides = {}) => {
  const cells = {
    finding_id: id,
    task: '1',
    layer: 'node',
    severity: 'P1',
    status: 'VERIFIED',
    summary: 'a thing that was wrong',
    test_or_layer: 'regression/thing.test.mjs covers it',
    source: 'assets/js/app.js:1',
    evidence: 'reports/evidence/unit-1-20260928T000000Z-1.log',
    limitation: 'None known',
    ...overrides
  };
  return HEADER.split('\t').map((column) => cells[column] ?? '').join('\t');
};

const problemsFor = (root) => validateReports({ repoRoot: root, required: REQUIRED }).problems;
const withRepo = (options, body) => (() => {
  const root = makeRepo(options);
  try { body(root, problemsFor(root)); } finally { rmSync(root, { recursive: true, force: true }); }
})();

test('FR9-06: a well-formed set of reports validates clean', () => {
  withRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] }, (_root, problems) => {
    assert.deepEqual(problems, [], 'the baseline the other cases break must itself be clean');
  });
});

test('FR9-06: a row with too few cells is caught, because a short TSV row renders fine', () => {
  // The row drops its `evidence` cell. Nothing about the file looks broken: TSV viewers pad it, and the
  // limitation text that was meant for the last column is read out of the evidence column instead — so
  // "closed" is backed by a sentence about limitations.
  const short = goodRow('FR9-01').split('\t').slice(0, -1).join('\t');
  withRepo({ rows: [short, goodRow('FR9-02')] }, (_root, problems) => {
    assert.ok(
      problems.some((p) => /FR9-01 has 9 cell\(s\) but the header has 10/.test(p)),
      `a short row must be reported, got: ${JSON.stringify(problems)}`
    );
  });
});

test('FR9-06: a required finding with no row is caught', () => {
  // The failure this prevents is the one that actually happens: the round found six things and the
  // matrix mentions five, and nothing in the repository knows a sixth exists.
  withRepo({ rows: [goodRow('FR9-01')] }, (_root, problems) => {
    assert.ok(
      problems.some((p) => /FR9-02 is required by this round and has no row/.test(p)),
      `a missing finding must be reported, got: ${JSON.stringify(problems)}`
    );
  });
});

test('FR9-06: a status outside the closed set is caught', () => {
  withRepo({ rows: [goodRow('FR9-01', { status: 'done' }), goodRow('FR9-02')] }, (_root, problems) => {
    assert.ok(
      problems.some((p) => /FR9-01 has status "done", which is not one of/.test(p)),
      `an unknown status must be reported, got: ${JSON.stringify(problems)}`
    );
  });
});

test('FR9-06: a VERIFIED row naming evidence that does not exist is caught', () => {
  withRepo({ rows: [goodRow('FR9-01', { evidence: 'reports/evidence/that-run.log' }), goodRow('FR9-02')] },
    (_root, problems) => {
      assert.ok(
        problems.some((p) => /FR9-01 claims evidence at reports\/evidence\/that-run\.log, which does not exist/.test(p)),
        `a VERIFIED row must not be able to name a log nobody produced, got: ${JSON.stringify(problems)}`
      );
    });
});

test('FR9-06: a VERIFIED row with no test is caught, because a verified finding with no test is an assertion', () => {
  withRepo({ rows: [goodRow('FR9-01', { test_or_layer: '-' }), goodRow('FR9-02')] }, (_root, problems) => {
    assert.ok(
      problems.some((p) => /FR9-01 is VERIFIED but names no test/.test(p)),
      `VERIFIED with no test must be reported, got: ${JSON.stringify(problems)}`
    );
  });
});

test('FR9-06: a path in a row that is not a file in the repo is caught', () => {
  withRepo({ rows: [goodRow('FR9-01', { source: 'assets/js/deleted.js:1' }), goodRow('FR9-02')] },
    (_root, problems) => {
      assert.ok(
        problems.some((p) => /FR9-01 names "assets\/js\/deleted\.js", which is not a file/.test(p)),
        `a dangling path must be reported, got: ${JSON.stringify(problems)}`
      );
    });
});

test('FR9-06: the harness spelling of a path is accepted, so the check is not merely a spelling lottery', () => {
  // `browser/x.spec.mjs` and `regression/x.test.mjs` are how rows refer to files under tests/. If those
  // did not resolve, the path rule would fire on the matrix's own idioms and be switched off.
  withRepo({
    rows: [goodRow('FR9-01', { test_or_layer: 'regression/thing.test.mjs covers it' }), goodRow('FR9-02')]
  }, (_root, problems) => {
    assert.deepEqual(problems, [], `a row in the documents' own spelling must validate, got: ${JSON.stringify(problems)}`);
  });
});

test('FR9-06: a gate count no log records is caught, so a stale "33/33" cannot outlive its run', () => {
  // This is the check that has teeth. The handoff says the browser suite passed 33 of 33; the evidence
  // directory has a log that says 3 passed. One of those is now false and the report is the last place
  // anyone would find out.
  withRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\n| browser | 33/33 | `r8-browser-20260928T052411Z-1` |\n'
  }, (_root, problems) => {
    assert.ok(
      problems.some((p) => /claims browser 33\/33 on line \d+, but no log/.test(p)),
      `an unsupported count must be reported, got: ${JSON.stringify(problems)}`
    );
  });
});

test('FR9-06: a gate count a log does record is accepted', () => {
  withRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\n| unit | 3/3 | `unit-1-20260928T000000Z-1` |\n',
    logs: { 'unit-1-20260928T000000Z-1.log': '# tests 3\n# pass 3\n# fail 0\n' }
  }, (_root, problems) => {
    assert.ok(!problems.some((p) => /claims/.test(p)), `a supported count must not be reported, got: ${JSON.stringify(problems)}`);
  });
});

test('FR9-06: a row VERIFIED in the matrix but OPEN in the handoff is caught', () => {
  withRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\n| unit | 3/3 |\n\n| FR9-01 | OPEN |\n'
  }, (_root, problems) => {
    assert.ok(
      problems.some((p) => /FR9-01 is VERIFIED in the matrix but the handoff still describes it as OPEN/.test(p)),
      `a matrix/handoff disagreement must be reported, got: ${JSON.stringify(problems)}`
    );
  });
});

test('FR9-06: an evidence reference in the handoff that does not exist is caught', () => {
  withRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\nunit 3/3\n\nEvidence: reports/evidence/never-ran.log\n'
  }, (_root, problems) => {
    assert.ok(
      problems.some((p) => /a report names reports\/evidence\/never-ran\.log, which is not in reports\/evidence\//.test(p)),
      `a named log that is absent must be reported, got: ${JSON.stringify(problems)}`
    );
  });
});

test('FR9-06: the real reports in this repo validate', (t) => {
  // The cases above are about the checker. This is about the thing being checked, and it is the case that
  // fails if a round ends without recording what it did.
  const result = validateReports();
  if (result.warnings.some((w) => /evidence does not exist/.test(w))) {
    // This suite also ships inside the review bundle, where the evidence is curated and lives beside the
    // source tree rather than inside it. A check that cannot be performed has to say so and stand down;
    // asserting a failure would blame the reports for the bundle's arrangement, and asserting a pass would
    // be a lie. Skipping is the only honest answer, and the reason travels with the skip line.
    const bundleEvidence = ['../evidence/r8', '../evidence/r7-prior']
      .filter((dir) => existsSync(resolve(dir)))
      .join(', ');
    t.skip(`no reports/evidence here; this looks like a review bundle (evidence in ${bundleEvidence || 'nowhere'}) — `
      + 'run tools/validate-reports.mjs --evidence <dir> to check the reports against the shipped evidence');
    return;
  }
  assert.deepEqual(
    result.problems, [],
    'the repository\'s own matrix and handoff must validate; problems: ' + result.problems.join(' | ')
  );
  assert.ok(result.rows.length > 0, 'the matrix must not be empty — an empty one would validate');
  assert.ok(result.evidenceFiles.length > 0, 'the evidence directory must not be empty — the same applies');
});

test('FR9-06: the reports and the evidence can be pointed at separately', () => {
  // Found by unzipping this round's own review bundle: the tool was hard-wired to <repo>/reports/evidence,
  // so a tree whose evidence ships elsewhere reported 37 problems that were purely a layout artefact. The
  // options are also what the round plan asked for (--repo, --reports, --mode).
  const root = makeRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] });
  try {
    // Move the evidence out of the tree, the way a bundle does.
    const elsewhere = mkdtempSync(join(tmpdir(), 'evidence-elsewhere-'));
    try {
      for (const name of readdirSync(join(root, 'reports', 'evidence'))) {
        writeFileSync(join(elsewhere, name), readFileSync(join(root, 'reports', 'evidence', name)));
      }
      rmSync(join(root, 'reports', 'evidence'), { recursive: true, force: true });

      // Pointed nowhere, the tool cannot tell "the evidence is elsewhere" from "the evidence was never
      // written". It must not guess, and it must not claim the tree is clean: it has to say the claims are
      // unchecked. Guessing either way is how a bundle like this one gets reviewed as if it were verified.
      const asDefault = validateReports({ repoRoot: root, required: REQUIRED });
      assert.deepEqual(
        asDefault.problems, [],
        'an unpointed run is not yet a false claim — the report of that is the warning below'
      );
      assert.ok(
        asDefault.warnings.some((w) => /every claim about a run cannot be checked/.test(w)),
        'and the tool has to admit it could not check the run claims, not quietly pass them'
      );

      const pointed = validateReports({ repoRoot: root, evidence: elsewhere, required: REQUIRED });
      assert.deepEqual(
        pointed.problems, [],
        `pointing --evidence at the real directory must clear the problems, got: ${JSON.stringify(pointed.problems)}`
      );
    } finally { rmSync(elsewhere, { recursive: true, force: true }); }
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: --mode final holds a delivered tree to shipping its evidence', () => {
  const root = makeRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] });
  try {
    rmSync(join(root, 'reports', 'evidence'), { recursive: true, force: true });
    const draft = validateReports({ repoRoot: root, required: REQUIRED, mode: 'draft' });
    const final = validateReports({ repoRoot: root, required: REQUIRED, mode: 'final' });
    assert.ok(
      !draft.problems.some((p) => /has to ship the runs its claims cite/.test(p)),
      'draft work in progress is not held to shipping its evidence'
    );
    assert.ok(
      final.problems.some((p) => /has to ship the runs its claims cite/.test(p)),
      'a final tree that cannot show its runs is incomplete whatever its claims say'
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a matrix with no schema line is refused rather than guessed at', () => {
  // The pin exists so a consumer never has to infer what the columns mean. A file that does not say
  // which schema it is must be refused, not read on the assumption that it looks like the last one.
  const root = makeRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] });
  try {
    const path = join(root, 'reports', 'FRONTEND-FINDING-MATRIX.tsv');
    writeFileSync(path, `${HEADER}\n${goodRow('FR9-01')}\n${goodRow('FR9-02')}\n`);
    assert.ok(
      problemsFor(root).some((p) => /does not declare "# schema=/.test(p)),
      'a matrix with no schema must be reported'
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a status outside the pinned enum is refused, including one that reads like success', () => {
  // `CLOSED` is the interesting one: it is the word the previous rounds used, it means what people want
  // it to mean, and it is not in the enum. A checker that accepted it would have ratified every wide
  // closure this round was opened to look at.
  for (const status of ['CLOSED', 'done', 'FIXED', 'PARTIAL']) {
    const root = makeRepo({ rows: [goodRow('FR9-01', { status }), goodRow('FR9-02')] });
    try {
      assert.ok(
        problemsFor(root).some((p) => new RegExp(`FR9-01 has status "${status}", which is not one of`).test(p)),
        `status ${status} must be outside the enum`
      );
    } finally { rmSync(root, { recursive: true, force: true }); }
  }
});

test('FR9-06: IMPLEMENTED_UNVERIFIED is not treated as done, so a row cannot skip its evidence', () => {
  // The state the work is actually in: the code is written and nobody has watched it fail before and pass
  // after. An enum without this state has to call it "done", which is where every wide closure came from.
  const unverified = () => makeRepo({
    rows: [goodRow('FR9-01', { status: 'IMPLEMENTED_UNVERIFIED', test_or_layer: '-', evidence: '-' }), goodRow('FR9-02')]
  });

  const asUnverified = unverified();
  try {
    assert.deepEqual(
      problemsFor(asUnverified), [],
      'an unverified row is not yet claiming anything, so it owes no test and no evidence'
    );
  } finally { rmSync(asUnverified, { recursive: true, force: true }); }

  // The same row, one status up, has to produce the complaint. Without this the case above would also
  // pass if the evidence rule had stopped firing at all.
  const asVerified = makeRepo({
    rows: [goodRow('FR9-01', { status: 'VERIFIED', test_or_layer: '-', evidence: '-' }), goodRow('FR9-02')]
  });
  try {
    const problems = problemsFor(asVerified);
    assert.ok(problems.some((p) => /FR9-01 is VERIFIED but names no test/.test(p)), 'the same row as VERIFIED owes a test');
    assert.ok(problems.some((p) => /FR9-01 is VERIFIED but names no evidence/.test(p)), 'and owes evidence');
  } finally { rmSync(asVerified, { recursive: true, force: true }); }
});

test('FR9-06: a "12/12 CDN references" line is not read as 12 passing unit tests', () => {
  // The false alarm this guards against. A ratio next to the word "static" is a count of checks the gate
  // made, not of tests that passed, and a validator that reports it is one nobody keeps running.
  const root = makeRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\n| static | pass | `r8-static-20260928T055415Z-1` — 12/12 CDN references pinned |\n'
  });
  try {
    assert.ok(
      !problemsFor(root).some((p) => /claims/.test(p)),
      `a ratio that is not a gate count must be left alone, got: ${JSON.stringify(problemsFor(root))}`
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a gate count on a line with no run named is not a claim either', () => {
  // Same rule from the other side: a number with neither a gate result nor a run to check it against is
  // prose. Requiring the run is what makes the check enforceable rather than decorative.
  const root = makeRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\nunit 99/99 passed.\n'
  });
  try {
    assert.ok(
      !problemsFor(root).some((p) => /claims/.test(p)),
      `an unanchored count must be left alone, got: ${JSON.stringify(problemsFor(root))}`
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a complete N/N gate count is still checked, so a stale full pass cannot survive', () => {
  // The rule that fixes the false alarm must not also excuse the real thing: "unit 999/999" with a run
  // named is exactly as false as a partial one, and is the more likely shape for a stale claim.
  const root = makeRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\n| unit | 999/999 | `unit-1-20260928T000000Z-1` |\n'
  });
  try {
    assert.ok(
      problemsFor(root).some((p) => /claims unit 999\/999 on line \d+, but no log/.test(p)),
      `a stale complete count must be reported, got: ${JSON.stringify(problemsFor(root))}`
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a run name cited in the handoff that never ran is caught', () => {
  // A correct count attributed to a run that did not happen. The count rule cannot see this — the number
  // matches a real log — so without this rule a report can be right about the total and wrong about where
  // it came from, which is the version a reader cannot check at all.
  const root = makeRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\n| unit | 3/3 | `unit-9-20260928T235959Z-1` |\n'
  });
  try {
    assert.ok(
      problemsFor(root).some((p) => /cites run 20260928T235959Z-1, and no file in reports\/evidence\//.test(p)),
      `a run that never ran must be reported, got: ${JSON.stringify(problemsFor(root))}`
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a cited run whose timestamp was mistyped is caught', () => {
  // The same rule, from the mistake that is easy to make by hand: the run is real, the count is real, and
  // the timestamp written next to it is from memory. This exact error happened while writing R8's handoff.
  const root = makeRepo({
    rows: [goodRow('FR9-01'), goodRow('FR9-02')],
    handoff: '# Handoff\n\n| unit | 3/3 | `unit-1-20260928T999999Z-1` |\n'
  });
  try {
    assert.ok(
      problemsFor(root).some((p) => /cites run 20260928T999999Z-1/.test(p)),
      `a mistyped run reference must be reported, got: ${JSON.stringify(problemsFor(root))}`
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a tree with no evidence directory says so once, instead of per row', () => {
  // Found by unzipping this round's own review package: the tool took an unguarded readdir and died on the
  // one input a reviewer is most likely to try. The crash was the first bug. The second was subtler: once
  // it stopped crashing, it reported 37 problems, all of them the same fact — no evidence directory —
  // restated once per row. A reader cannot act on 37 copies of one sentence, and the one sentence that
  // would let them act is not among them.
  const root = makeRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] });
  try {
    rmSync(join(root, 'reports', 'evidence'), { recursive: true, force: true });

    const draft = validateReports({ repoRoot: root, required: REQUIRED, mode: 'draft' });
    assert.deepEqual(
      draft.problems, [],
      'a tree mid-round is not a lying tree; the missing directory is a warning, and there is only one'
    );
    assert.deepEqual(
      draft.warnings.filter((w) => /every claim about a run cannot be checked/.test(w)).length, 1,
      'and it is said exactly once'
    );

    // Same tree, but being delivered rather than worked in. Here the missing directory IS the finding,
    // and it is the finding, not 37 derivatives of it.
    const final = validateReports({ repoRoot: root, required: REQUIRED, mode: 'final' });
    assert.deepEqual(
      final.problems, ['reports/evidence does not exist at ' + join(root, 'reports', 'evidence')
        + '; a final tree has to ship the runs its claims cite'],
      'a delivered tree that cannot show its runs is incomplete, stated once'
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: an early return has the same shape as a full one, so a caller can destructure it', () => {
  // `--mode final` on a tree with no evidence died with `TypeError: warnings is not iterable`. The early
  // return for "the reports themselves are unusable" left `warnings` out of its result while every other
  // path included it. A caller that destructures should not have to know which path it got.
  const root = makeRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] });
  try {
    // The early path is "the reports themselves are unusable", so make them unusable.
    rmSync(join(root, 'reports', 'FRONTEND-FINDING-MATRIX.tsv'), { force: true });
    const result = validateReports({ repoRoot: root, required: REQUIRED, mode: 'final' });
    for (const key of ['problems', 'warnings', 'rows', 'evidenceFiles']) {
      assert.ok(Array.isArray(result[key]), `${key} must be an array on every path, including the early one`);
    }
    assert.ok(
      result.problems.some((p) => /FRONTEND-FINDING-MATRIX.tsv is missing/.test(p)),
      'and it must actually be reporting the problem it exited for'
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a run stamp that is genuinely absent is caught even though the directory is', () => {
  // The counterpart to the rule above, so the suppression cannot swallow a real finding: if the directory
  // is there, a run nobody wrote is still a lie and must be reported.
  const root = makeRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] });
  try {
    writeFileSync(join(root, 'reports', 'FRONTEND-HANDOFF.vi.md'),
      '# Handoff\n\n| unit | 3/3 | `unit-9-20260928T235959Z-1` |\n');
    assert.ok(
      problemsFor(root).some((p) => /cites run 20260928T235959Z-1, and no file in reports\/evidence\//.test(p)),
      'with the directory present, a run that never ran must be reported'
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('FR9-06: a run label is reported when there is no evidence directory to resolve it against', () => {
  // The other unguarded path: a row that names a run in backticks rather than a literal file. With the
  // directory gone, `readdirSync` threw before the label could be checked.
  const root = makeRepo({ rows: [goodRow('FR9-01'), goodRow('FR9-02')] });
  try {
    rmSync(join(root, 'reports', 'evidence'), { recursive: true, force: true });
    // Nothing can be resolved, so the only true statement is the one about the directory — but the tool
    // must be the one saying it. If this case ever reports a run label, something is resolving names
    // against a directory that does not exist.
    const result = validateReports({ repoRoot: root, required: REQUIRED });
    assert.deepEqual(
      result.warnings.filter((w) => /every claim about a run cannot be checked/.test(w)).length, 1,
      'a run label with nothing to resolve against must reduce to the one true statement'
    );
    assert.ok(
      !result.problems.some((p) => /names the run|cites run/.test(p)),
      `no run can be called missing while the directory to search is missing, got: ${JSON.stringify(result.problems)}`
    );
  } finally { rmSync(root, { recursive: true, force: true }); }
});
