#!/usr/bin/env node
/**
 * validate-reports.mjs — checks that the reports say what the evidence supports (FR9-06).
 *
 * The defect this exists for is not that a report was missing. It is that a report could be *wrong* in
 * the specific way a self-report always can: a claim that nothing checks.
 *
 * Every round of this work has produced a matrix, a handoff and a directory of evidence, and every one of
 * them has been written by the same hands that wrote the code. That is the weakest possible arrangement
 * for a document whose entire job is to tell a later reader what has actually been verified. A number in
 * prose ("233/233", "browser 33/33", "closed") is a claim about the world that no test ever made, so it
 * stays plausible-looking forever: bump a test, delete a log, add a finding and forget the row, and the
 * report is still perfectly readable and now quietly untrue.
 *
 * So the rules here are all of one kind: **a claim must point at something that exists and says what the
 * claim says.** Not "the document is well-formed" — a well-formed report that asserts a gate passed when
 * the log next to it says otherwise is worse than no report, because it is trusted.
 *
 * What is checked:
 *
 *   1. Every finding in the review has a row in the matrix, and every row names real files.
 *   2. Every status is from the closed set, and a row marked CLOSED has both a test and an evidence file
 *      that exist on disk.
 *   3. Every `evidence` file named anywhere in the matrix or the handoff exists — or is explicitly
 *      recorded as not-yet-produced, never quietly claimed.
 *   4. Every gate count the handoff states as a pass matches a number in the evidence log it names. This
 *      is the one that bites: it is the check that a stale "33/33" cannot outlive the run that produced it.
 *   5. No finding is simultaneously claimed open and closed, and the handoff's task table does not claim a
 *      task VERIFIED whose matrix rows are still OPEN.
 *
 * Exit 0 when clean, 1 when there is something to say, 2 on bad usage. Output is a list of sentences a
 * human can act on — deliberately not a diff of what the author "meant".
 */

import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const REPORTS = join(REPO_ROOT, 'reports');
const EVIDENCE = join(REPORTS, 'evidence');
const MATRIX = join(REPORTS, 'FRONTEND-FINDING-MATRIX.tsv');
const HANDOFF = join(REPORTS, 'FRONTEND-HANDOFF.vi.md');
const EXECUTION_LOG = join(REPORTS, 'FRONTEND-EXECUTION-LOG.vi.md');

/**
 * The matrix schema, pinned.
 *
 * A matrix with no declared schema is a matrix whose columns can drift without anyone noticing, which is
 * the defect the pinned version is here to prevent: a row that grows or loses a cell still parses, it just
 * starts meaning something else. A consumer that knows the version can refuse a file that is not it.
 */
export const MATRIX_SCHEMA = 'frontend-finding-matrix/1';

/** The only statuses a row may carry. Anything else is a word, not a state. */
const STATUSES = new Set([
  'OPEN', 'IN_PROGRESS', 'IMPLEMENTED_UNVERIFIED', 'VERIFIED', 'BLOCKED'
]);

/**
 * A status that means "this is finished and checked".
 *
 * `IMPLEMENTED_UNVERIFIED` is deliberately *not* in this set, and that gap is the point of having it. The
 * real work in these rounds happens in that state: the code is written, it looks right, and nobody has
 * watched it fail in the old shape and pass in the new one. An enum that offered only yes/no would have
 * to call that "done", and every wide closure in the previous rounds came from exactly that.
 */
const CLAIMS_DONE = new Set(['VERIFIED']);

/** The findings this round is accountable for. Kept here so an unrecorded finding fails the gate. */
const REQUIRED_FINDINGS = [
  'FR9-01', 'FR9-02', 'FR9-03', 'FR9-04', 'FR9-05', 'FR9-06',
  'FA8-01', 'FA8-02', 'FA8-03', 'FA8-04', 'FA8-05', 'FA8-06', 'FA8-07'
];

/** Files a row may legitimately name, so a typo in a path is caught rather than believed. */
const REPO_PREFIXES = [
  'assets/', 'vue/', 'tests/', 'tools/', 'reports/', 'documents/', 'browser/', 'regression/', 'index.html', 'README'
];

/** Splits a TSV row. `-1` so an empty trailing cell is an empty string and not the whole rest. */
const cells = (line) => line.split('\t').map((cell) => cell.trim());

/**
 * A path-shaped token out of a cell of prose.
 *
 * Rows say `assets/js/api/sessionCoordinator.js:412 acquireWithDeadline`, which is two things at once: a
 * place and a symbol. Only the place is checkable, and the check is worth making, because a row that
 * points at a file that is not in the repo is a claim about code that is not there.
 */
const PATH_TOKEN = /[A-Za-z0-9_./@-]+[A-Za-z0-9_.-]*\.(?:m?js|c?js|json|vue|html|md|sh|txt|css|yml|yaml|ts)\b/g;

const pathTokens = (cell) => (cell || '').match(PATH_TOKEN) || [];

/**
 * Whether one token names something that exists.
 *
 * A row refers to a place in the three ways the existing documents already use, and all three have to
 * work or the check only ever fires on the one spelling: the path itself, the path with a `:line` or
 * `:symbol` tail, and the harness shorthand `browser/x.spec.mjs` for `tests/browser/x.spec.mjs`.
 */
function tokenExists(repoRoot, token) {
  const bare = token.replace(/[:(].*$/, '');
  const candidates = [bare, join('tests', bare), join('reports', bare)];
  return candidates.some((candidate) => existsSync(join(repoRoot, candidate)));
}

/** Every `reports/evidence/...` path a document mentions, whether it exists or not. */
function evidenceReferences(text) {
  return [...text.matchAll(/reports\/evidence\/[A-Za-z0-9._/-]+/g)]
    .map((match) => match[0].replace(/[.,;)]+$/, ''));
}

/**
 * Backticked tokens a cell names as evidence, which are either a file or a run label.
 *
 * A run label is `r8cd-browser`; its evidence files are `browser-r8cd-browser-<timestamp>-1.log`. Writing
 * the timestamp into a matrix cell would mean every rerun edits six rows, and the incentive that produces
 * is "do not rerun the browser suite". So a row names the run and the check asks the directory whether
 * a run by that name exists — which still catches the failure that matters, a row claiming a run that
 * never happened.
 */
function backtickedTokens(text) {
  return [...text.matchAll(/`([^`]+)`/g)].map((match) => match[1].trim()).filter(Boolean);
}

/**
 * Resolves a `reports/evidence/...` reference against the evidence directory it names.
 *
 * The reference is written relative to the repo root, so the obvious check is `join(repoRoot, ref)`. That
 * is only right when the evidence happens to sit under the repo root, which is not true of a review
 * bundle that ships it curated and separately. A checker hard-wired to the layout reports a tree full of
 * problems that are really a different arrangement of the same files, and a reader who cannot tell that
 * difference stops trusting the tool on the findings that matter.
 */
function evidencePathExists(repoRoot, evidenceDir, reference) {
  const name = reference.replace(/^reports\/evidence\//, '');
  return existsSync(join(evidenceDir, name)) || existsSync(join(repoRoot, reference));
}

/**
 * Whether an evidence name the cell gave can be resolved to a file in the evidence directory.
 *
 * A missing directory is a finding, not a crash. Every other rule here degrades to a sentence a human can
 * act on; an unguarded `readdirSync` would take the whole tool down on the one input a reviewer is most
 * likely to try — a tree where the evidence was not shipped — and a validator that dies instead of
 * explaining itself is indistinguishable from a validator that is broken.
 */
function evidenceResolves(repoRoot, evidenceDir, names) {
  const files = existsSync(evidenceDir) ? readdirSync(evidenceDir) : [];
  for (const name of names) {
    const bare = name.replace(/[:(].*$/, '');
    if (existsSync(join(repoRoot, bare))) return true;
    if (existsSync(join(evidenceDir, bare.replace(/^reports\/evidence\//, '')))) return true;
    // A run label resolves when at least one file in the directory is named for it.
    if (files.some((file) => file.includes(bare))) return true;
  }
  return false;
}

/**
 * The gate counts a document asserts, as `{ gate, passed, total, line }`.
 *
 * Only the "N/M" shape is read, and only when it sits on a line that also names a run. Both halves of
 * that matter. A bare "N/M" in prose is often not a gate at all: "12/12 CDN references" is a count of
 * checks the static gate performed, and reading it as "12 of 12 unit tests passed" is a false alarm that
 * would train a reader to ignore this tool. Requiring a run reference on the same line keeps the check on
 * the sentences that really are claims — a gate, a count, and the run it came from, which is also the only
 * sentence a reader can go and check.
 */
function claimedCounts(text) {
  const RUN = /(?:[A-Za-z0-9_.-]*-)?20\d{6}T\d{6}Z/;
  const claims = [];
  const gates = [
    { name: 'unit', pattern: /unit[^.\n]{0,24}?(\d+)\s*\/\s*(\d+)/g },
    { name: 'browser', pattern: /browser[^.\n]{0,24}?(\d+)\s*\/\s*(\d+)/g },
    { name: 'loopback', pattern: /loopback[^.\n]{0,24}?(\d+)\s*\/\s*(\d+)/g }
  ];
  const lines = text.split('\n');
  for (const [index, line] of lines.entries()) {
    for (const gate of gates) {
      for (const match of line.matchAll(gate.pattern)) {
        if (!RUN.test(line)) continue;
        claims.push({ gate: gate.name, passed: Number(match[1]), total: Number(match[2]), line: index + 1, text: line });
      }
    }
  }
  return claims;
}

/** The pass/fail totals a Playwright or node log actually records, keyed by what the log proves. */
function countsInLog(text) {
  const read = [];
  for (const match of text.matchAll(/(\d+) passed/g)) read.push({ kind: 'passed', n: Number(match[1]) });
  for (const match of text.matchAll(/(\d+) failed/g)) read.push({ kind: 'failed', n: Number(match[1]) });
  for (const match of text.matchAll(/# pass (\d+)/g)) read.push({ kind: 'pass', n: Number(match[1]) });
  for (const match of text.matchAll(/# fail (\d+)/g)) read.push({ kind: 'fail', n: Number(match[1]) });
  for (const match of text.matchAll(/# tests (\d+)/g)) read.push({ kind: 'tests', n: Number(match[1]) });
  return read;
}

/**
 * Validates the reports in a repository.
 *
 * The paths are parameters rather than constants because the reports do not always sit next to the
 * evidence they cite. A review bundle, for instance, ships the evidence curated and separately from the
 * tree, and a checker hard-wired to `<repo>/reports/evidence` would report a tree full of problems that
 * are really just a different layout.
 *
 * `mode` is `draft` for work in progress and `final` for a tree that is meant to be delivered.
 *
 *   draft  Missing evidence is a problem for a row that claims to be VERIFIED — that row is making a
 *          claim, and the claim is the whole point. Nothing else is held to the evidence.
 *   final  Additionally, a missing evidence directory is itself a problem: a delivered package that
 *          cannot show the runs behind its claims is incomplete whatever those claims say.
 */
export function validateReports({
  repoRoot = REPO_ROOT,
  reports = null,
  evidence = null,
  required = REQUIRED_FINDINGS,
  mode = 'draft'
} = {}) {
  const problems = [];
  const warnings = [];
  const reportsDir = reports || join(repoRoot, 'reports');
  const evidenceDir = evidence || join(reportsDir, 'evidence');
  const evidenceExists = existsSync(evidenceDir);
  if (!evidenceExists && mode === 'final') {
    problems.push(`reports/evidence does not exist at ${evidenceDir}; a final tree has to ship the runs its claims cite`);
  } else if (!evidenceExists) {
    warnings.push(`reports/evidence does not exist at ${evidenceDir}; every claim about a run cannot be checked`);
  }

  for (const file of ['FRONTEND-FINDING-MATRIX.tsv', 'FRONTEND-HANDOFF.vi.md']) {
    if (!existsSync(join(reportsDir, file))) problems.push(`reports/${file} is missing; there is nothing to validate`);
  }
  // Every early return has to carry the same shape as the normal one. This one did not: a caller that
  // destructures `warnings` got undefined, and `--mode final` on a tree without evidence died with a
  // TypeError instead of reporting the problem it was asked to report. Found by running it, not by reading
  // it, which is the only way this class of bug turns up.
  if (problems.length > 0) return { problems, warnings, rows: [], evidenceFiles: [] };

  /* --- the matrix ------------------------------------------------------------- */
  const matrixText = readFileSync(join(reportsDir, 'FRONTEND-FINDING-MATRIX.tsv'), 'utf8');
  const lines = matrixText.split('\n').filter((line) => line.trim().length > 0);

  // The schema line is the first thing checked, because a consumer that has already guessed the columns
  // has already lost. A missing or wrong version is a refusal to interpret the file at all.
  const declared = lines[0].startsWith('#') ? /^#\s*schema=(\S+)\s*$/.exec(lines[0]) : null;
  if (!declared) {
    problems.push(`the matrix does not declare "# schema=<version>" on its first line, so its columns cannot be trusted`);
  } else if (declared[1] !== MATRIX_SCHEMA) {
    problems.push(`the matrix declares schema ${declared[1]}, but this validator reads ${MATRIX_SCHEMA}; the file is not the one it was written for`);
  }
  const headerLine = lines[0].startsWith('#') ? lines[1] : lines[0];
  const header = cells(headerLine);
  const expected = ['finding_id', 'task', 'layer', 'severity', 'status', 'summary', 'test_or_layer', 'source', 'evidence', 'limitation'];
  for (const column of expected) {
    if (!header.includes(column)) problems.push(`the matrix header has no ${column} column`);
  }
  const body = lines.slice(lines[0].startsWith('#') ? 2 : 1);
  const rows = body.map((line) => {
    const parts = cells(line);
    const row = { _raw: line, _cellCount: parts.length };
    header.forEach((name, index) => { row[name] = parts[index] ?? ''; });
    return row;
  });

  const byId = new Map();
  for (const row of rows) {
    const id = row.finding_id;
    if (!id) { problems.push('a matrix row has no finding_id'); continue; }
    if (byId.has(id)) problems.push(`${id} appears more than once in the matrix; two rows cannot both be the record`);
    byId.set(id, row);

    // A row with the wrong number of cells is the quietest defect in a TSV, because a short row does not
    // look broken: the last column just silently holds whatever was written in the second-to-last. One
    // FA8 row was nine cells wide against a ten-column header, so its evidence cell was reading out a
    // sentence about limitations. Nothing rendered wrong and the claim was still being counted.
    if (row._cellCount !== header.length) {
      problems.push(`${id} has ${row._cellCount} cell(s) but the header has ${header.length}; every value after the missing one is read from the wrong column`);
    }

    for (const column of header) {
      if (row[column] === '') problems.push(`${id} has an empty ${column}; a blank cell reads as "nothing to say" and is indistinguishable from an oversight`);
    }

    if (!STATUSES.has(row.status)) {
      problems.push(`${id} has status "${row.status}", which is not one of ${[...STATUSES].join('/')}`);
    }

    // A path in a row has to exist. Rows name a place and a symbol in the same breath, so every
    // path-shaped token in the row is checked — not the cell as a whole, which would only ever fire on
    // the one spelling a checker guessed.
    for (const cell of [row.source, row.test_or_layer]) {
      for (const token of pathTokens(cell)) {
        if (!REPO_PREFIXES.some((prefix) => token.startsWith(prefix))) continue;
        if (!tokenExists(repoRoot, token)) {
          problems.push(`${id} names "${token}", which is not a file in this repo`);
        }
      }
    }
  }

  for (const id of required) {
    if (!byId.has(id)) problems.push(`${id} is required by this round and has no row in the matrix`);
  }

  /* --- a VERIFIED row owes a test and evidence that exist ----------------------- */
  const evidenceFiles = evidenceExists
    ? readdirSync(evidenceDir).filter((name) => statSync(join(evidenceDir, name)).isFile())
    : [];

  for (const [id, row] of byId) {
    if (!CLAIMS_DONE.has(row.status)) continue;
    if (!row.test_or_layer || row.test_or_layer === '-') {
      problems.push(`${id} is VERIFIED but names no test; a verified finding with no test is an assertion`);
    }
    if (!row.evidence || row.evidence === '-') {
      problems.push(`${id} is VERIFIED but names no evidence; "verified" has to point at something observed`);
    }
    // `not yet` / `to be produced` is a legitimate honest answer, and it is checked for honesty: the
    // evidence cell must not *also* name a file as though it did.
    const claimsProduced = !/\b(not yet|pending|to be|will be|not reproduced|unreproduced)\b/i.test(row.evidence);
    if (claimsProduced) {
      for (const reference of evidenceReferences(row.evidence)) {
        if (!evidencePathExists(repoRoot, evidenceDir, reference)) {
          // With no directory to look in, this is not a fact about the row: it is the missing directory,
          // already reported once above. Saying it 37 times buries the one sentence that says anything.
          if (evidenceExists) problems.push(`${id} claims evidence at ${reference}, which does not exist`);
        }
      }
      const labels = backtickedTokens(row.evidence);
      if (labels.length > 0 && !evidenceResolves(repoRoot, evidenceDir, labels)) {
        if (evidenceExists) problems.push(`${id} names the run ${labels.join(', ')}, and no file in reports/evidence/ belongs to it`);
      }
    }
  }

  /* --- evidence the documents mention must exist ------------------------------ */
  const handoffText = readFileSync(join(reportsDir, 'FRONTEND-HANDOFF.vi.md'), 'utf8');
  const logText = existsSync(EXECUTION_LOG) ? readFileSync(EXECUTION_LOG, 'utf8') : '';
  const documentText = `${handoffText}\n${logText}\n${matrixText}`;

  for (const reference of new Set(evidenceReferences(documentText))) {
    if (!evidencePathExists(repoRoot, evidenceDir, reference)) {
      if (evidenceExists) problems.push(`a report names ${reference}, which is not in reports/evidence/`);
    }
  }

  // A run cited in a document has to be a run that happened. The count rule above catches a number no log
  // supports; this catches the other half — a *correct* number attributed to a run that never ran, or to a
  // run whose timestamp was typed from memory. Both were hit while writing this round's own handoff, which
  // is the argument for the rule: it is not a failure mode anyone has to be careful about, it is one the
  // tool refuses.
  //
  // The timestamp alone is the identity. Run labels are not unique over a round (`unit` is used again for
  // every task that reran the suite) and a run's label is chosen by whoever launched it, so matching on
  // the label would either be too strict or need a prefix rule that guesses. `20260928T060057Z-1` occurs
  // in exactly the files that run produced.
  const RUN_STAMP = /20\d{6}T\d{6}Z-\d+/g;
  for (const [name, text] of [['the handoff', handoffText], ['the matrix', matrixText], ['the execution log', logText]]) {
    for (const stamp of new Set(text.match(RUN_STAMP) || [])) {
      if (evidenceFiles.some((file) => file.includes(stamp))) continue;
      if (evidenceExists) problems.push(`${name} cites run ${stamp}, and no file in reports/evidence/ belongs to it`);
    }
  }

  /* --- the counts a document asserts must match the logs ---------------------- */
  // Every log is read, and every claim is checked against every log. A claim that matches *some* log is
  // accepted and a claim that matches none is refused: the question a report has to answer is not "which
  // run was this" but "is there a run in this evidence directory that says so".
  const logs = evidenceFiles
    .filter((name) => name.endsWith('.log'))
    .map((name) => ({ name, read: countsInLog(readFileSync(join(evidenceDir, name), 'utf8')) }))
    .filter((entry) => entry.read.length > 0);

  const claims = claimedCounts(handoffText);
  if (logs.length === 0 && claims.length > 0) {
    if (evidenceExists) problems.push('the documents assert gate counts but reports/evidence/ has no log that records any');
  }

  for (const claim of claimedCounts(handoffText)) {
    if (claim.passed > claim.total) {
      problems.push(`the handoff claims ${claim.gate} ${claim.passed}/${claim.total}, which is not a number of passes`);
      continue;
    }
    const supported = logs.some((entry) => entry.read.some((c) => c.kind === 'passed' && c.n === claim.passed)
      || entry.read.some((c) => c.kind === 'pass' && c.n === claim.passed && entry.read.some((r) => r.kind === 'tests' && r.n === claim.total)));
    if (!supported && evidenceExists) {
      problems.push(
        `the handoff claims ${claim.gate} ${claim.passed}/${claim.total} on line ${claim.line}, but no log in `
        + `reports/evidence/ records ${claim.passed} passing ${claim.gate} tests; the logs there report `
        + `${logs.map((l) => `${l.name}: ${l.read.filter((r) => r.kind === 'passed' || r.kind === 'pass').map((r) => r.n).join('/')}`).join(', ') || 'nothing'}`
      );
    }
  }

  /* --- a finding cannot be both open and closed -------------------------------- */
  // Not a duplicate-id check: a row can be *edited* into a contradiction with the handoff's task table,
  // and that is the version that survives review. The handoff uses "OPEN" as prose for unfinished work,
  // so the check only fires when the row is finished and the handoff still calls it unfinished.
  for (const [id, row] of byId) {
    if (!CLAIMS_DONE.has(row.status)) continue;
    const handoffLine = handoffText.split('\n').find((line) => line.includes(id));
    if (handoffLine && /\bOPEN\b/.test(handoffLine)) {
      problems.push(`${id} is ${row.status} in the matrix but the handoff still describes it as OPEN`);
    }
  }

  return {
    problems,
    warnings,
    mode,
    rows: rows.map(({ _raw, _cellCount, ...row }) => row),
    evidenceFiles
  };
}

/* ------------------------------------------------------------------ cli ---- */
const isMain = process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url));
if (isMain) {
  const USAGE = `usage: node tools/validate-reports.mjs [options]

  --repo <path>       repository root; the reports are read from <path>/reports unless told otherwise
  --reports <path>    reports directory (default: <repo>/reports)
  --evidence <path>   evidence directory (default: <reports>/evidence)
  --mode draft|final  draft: only rows that claim VERIFIED must be backed by evidence (default)
                      final: a missing evidence directory is itself a problem
  --json              machine-readable output
  -h, --help          this text

Exit 0 when every claim holds, 1 when there is something to say, 2 on bad usage.
`;

  const options = { repoRoot: REPO_ROOT, mode: 'draft' };
  const argv = process.argv.slice(2);
  const known = new Set(['--repo', '--reports', '--evidence', '--mode', '--json', '-h', '--help']);
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!known.has(arg)) {
      process.stderr.write(`validate-reports: unknown option ${arg}\n\n${USAGE}`);
      process.exit(2);
    }
    if (arg === '--json') { options.json = true; continue; }
    if (arg === '-h' || arg === '--help') { process.stdout.write(USAGE); process.exit(0); }
    const value = argv[i + 1];
    if (value === undefined || value.startsWith('--')) {
      process.stderr.write(`validate-reports: ${arg} needs a value\n\n${USAGE}`);
      process.exit(2);
    }
    if (arg === '--repo') options.repoRoot = resolve(value);
    if (arg === '--reports') options.reports = resolve(value);
    if (arg === '--evidence') options.evidence = resolve(value);
    if (arg === '--mode') {
      if (value !== 'draft' && value !== 'final') {
        process.stderr.write(`validate-reports: --mode must be draft or final, not "${value}"\n\n${USAGE}`);
        process.exit(2);
      }
      options.mode = value;
    }
    i += 1;
  }

  const { problems, warnings, rows, evidenceFiles } = validateReports(options);
  if (options.json) {
    process.stdout.write(`${JSON.stringify({
      ok: problems.length === 0, mode: options.mode, problems, warnings, rows, evidenceFiles
    }, null, 2)}\n`);
  } else {
    for (const warning of warnings) process.stdout.write(`  ! ${warning}\n`);
    if (problems.length === 0) {
      process.stdout.write(`reports validate: ${rows.length} finding rows, ${evidenceFiles.length} evidence files, every claim backed\n`);
    } else {
      process.stdout.write(`reports validate: ${problems.length} problem(s)\n`);
      for (const problem of problems) process.stdout.write(`  - ${problem}\n`);
    }
  }
  process.exit(problems.length === 0 ? 0 : 1);
}
