# Frontend R11 — trạng thái hiện hành

Overall: **IN_PROGRESS / PARTIAL**, chưa đủ điều kiện COMPLETE. Cập nhật 2026-09-30.

| Trường | Giá trị hiện hành |
| --- | --- |
| Plan | FRONTEND-REMEDIATION-FRESH-SESSION-R11.vi.md, N1–N10 |
| Input ZIP | /workspaces/jjgsubl/frontend-remediation-r10-review-package.zip |
| Input SHA256 | 155c9c06b94dafa327350ecc4a9e584a5a35bbdb336d62ad5db9729c62c24403 |
| Repo / reports / evidence | /workspaces/frontend-r11-work; reports/; reports/evidence/ |
| Branch | remediation/r11 |
| HEAD / base tree | 6e185df127d9ce3c59ee97f61064f34abcca985d / ba028372a15db377626ee1e984f80ec6f66d4bd4 |
| Working tree | DIRTY sau checkpoint tạm: sửa monitoring phát hiện qua N9, tests và reports mới |
| Current content identity | Tính từ source bằng tools/frontend-source-identity.mjs; toDigest trong FRONTEND-SOURCE-COMPARISONS.json. Không ghi digest tự tham chiếu vào tài liệu nằm trong digest. |
| History | 109 commits gồm checkpoint tạm; baseline 88 bất biến; full-review/fold chưa xong |
| Artifact / attestation | Chưa tạo ZIP R11; chưa exact-ZIP restore/gates |

Bản ghi R9/R10 được bảo toàn tại reports/history/; các số liệu ở đó là lịch sử, không phải acceptance R11.
Repo gốc và ZIP đầu vào không bị sửa. Backup đầu vào: /workspaces/frontend-r11-session/r10-intake-backup.bundle.

| Task | Trạng thái và giới hạn |
| --- | --- |
| N1 | DONE: 653 hashes, 654 modes, 816 ZIP members; baseline unit có 4 lỗi ACL được giữ nguyên bằng chứng. Chromium cần 8 thư viện trích xuất cục bộ, không cài hệ thống. |
| N2 | Implemented: strict manifest, bounded ustar audit, byte/mode replay, no-clobber producer/extractor; active archive corruption bị từ chối. 38 historical missing snapshots là log-only, không replay. |
| N3 | Implemented: key từ manifest/lock/runtime; lock và atomic publish; graph/version/bin/entrypoint, metadata pin, symlink containment. Review tái hiện shadow dependency và metadata bypass rồi sửa; cần gate cuối trên source mới. Không claim full installed-byte integrity. |
| N4 | Implemented: exact 0644/0755 sau restore, default ACL nonroot và umask 022/077/002. |
| N5 | Implemented: method/type bắt buộc cho CDN; auto test-scoped teardown. Sáu canary cố ý thất bại vì assertion boundary, không phải PASS suite. |
| N6 | Implemented: native/SFC singleton bridge, late catch/finally fence, hold A/switch endpoint/release A; JSON/CSV bytes và HTML200 refusal. Prepared backend integration PENDING: thiếu READY; không dựng/sửa backend. |
| N7 | Rollback runbook + allowlist test; inherited session coverage có bằng chứng nhưng mapping acceptance đang rà soát. Reduced-mode policy BLOCKED chờ owner trả lời; R7 cancellation UNRESOLVED. |
| N8 | IN_PROGRESS: current reports, 33 finding IDs, comparison validator; checkpoint đầu đã validate/backup/fresh clone; cần refresh sau sửa monitoring. |
| N9 | IN_PROGRESS: full diff/message review 108 commits, responsibility map, fold, boundary gates, tree equality. |
| N10 | NOT_DONE: exact artifact, clean restore, fresh gates, external attestation. |

Bằng chứng gần nhất (mỗi run giữ nguyên identity của nó):

- unit 440/440: `r11-ready-unit-20260930T002919Z-1`, exit 0, zero fail/cancel/skip.
- browser 48/48: `browser-r11-ready-browser-20260930T002943Z-1`, exit 0, 5.9 phút.
- static `r11-ready-static-20260930T002919Z-1`: exit 0.
- loopback `r11-ready-loopback-20260930T002919Z-1`: exit 0.
- Cả bốn run trên cùng source digest `ac372d8fe04fc7b41df4d99b7a852bfbf0909f8a500f29e670ceb5bd3f8a015f`, source_drift none; sau đó sửa monitoring và thêm tests là SOURCE_CHANGE; không dùng bốn gate này chứng minh source mới.

- unit `r11-stable-unit-20260929T134719Z-1`: 437/437, exit 0, không cancelled/skipped; trước bản sửa READY.
- browser `browser-r11-stable-browser-20260929T134733Z-1`: 48/48, exit 0, không source drift; trước assertion toast HTML200 và bản sửa READY.
- HTML200 UI `browser-r11-export-ui-20260929T135014Z-1`: 1/1, export qua nút thật, có thông báo lỗi, không success/download.
- READY thiếu `r11-ready-missing-fixed (chi tiết reports/evidence/r11-ready-diagnostics.json)`: exit 0, **6 skipped / PENDING**, không phải integration PASS. READY sai `r11-ready-invalid-canary-20260930T002603Z-1`: exit 1, 6 assertion failures đúng SHA; CAUGHT, không phải gate xanh.
- READY lần đầu `r11-ready-missing (chi tiết cùng diagnostic sidecar)`: SOURCE_DRIFT do outputDir integration nằm trong source; đã chuyển output về tests/test-results, giữ nguyên bằng chứng lỗi.
- R7 diagnostic direct Node `r11-r7-direct-diagnostic-20260929T150647Z-1`: 437/437, chưa tái hiện cancellation; UNRESOLVED, đã dùng 1/3 full-suite diagnostic runs.

- unit 419/419: `r11-current-unit-20260929T095220Z-1`, exit 0, không cancelled/skipped; trước sửa cache-review/export/deadline/comparison.
- browser 45/45: `browser-r11-current-browser-20260929T095227Z-1`, exit 0, frozen copy, 5.8 phút; trước các thay đổi vừa nêu.
- browser 3/3: `browser-r11-export-cors-20260929T100206Z-1`, exit 0, JSON/CSV byte equality và HTML200 rejection.
- Canary `browser-r11-canaries-fixed-20260929T090417Z-1`: exit 1, sáu lỗi boundary mong đợi; dùng làm CAUGHT, không dùng làm gate xanh.
- Wrapper selftest: session/logs/deadline-final-selftest.log, 33 passed / 0 failed; self124 là RAN, TERM0 sau deadline là TIMEOUT, tên bằng chứng không ghi đè.

Các gate trên không được gán thành bằng chứng cho source mới chỉ vì cùng HEAD. Comparison SOURCE_CHANGE buộc chạy lại gate có liên quan. `validate-reports --mode final` kiểm tính nhất quán, không tự đóng findings.

Next action: kiểm chứng sửa monitoring trên source mới, hoàn tất full history review N9 rồi fold. Checkpoint đầu đã có backup bundle/fresh clone/fsck; SHA/tree ghi tại session/checkpoint-20260930.json. Chưa rewrite và chưa ZIP cuối.
Owner input còn thiếu: quyết định hỗ trợ reduced mode theo N7; READY pin backend HEAD/tree/URL/scope/fixture nếu cần integration thật. Không push/deploy/backend mutation.

N9 phát hiện lỗi monitoring còn tồn tại từ extraction: bốn submit gọi hàm mở/reset thay vì submit và ba checkbox thiếu input/helper. Đã tái hiện bằng browser RED, sửa event bindings và immutable channel update; browser targeted mới đạt 5/5 (run r11-monitoring-green, raw evidence giữ riêng identity). Test Incident ban đầu sai locator do icon trong accessible name, đã sửa và tái hiện lại RED vì không gửi request. Đây là sửa regression trong nhóm monitoring, không thêm tính năng.

Rà soát N9 tiếp tục: phát hiện counter profile của page và store bị so sánh chéo sau reset/remount. Đã tách hai guard, unit profile 19/19 gồm 8 probe mới; browser remount đạt 1 case sau sửa fixture đủ status. Gate toàn bộ gần nhất 440 unit / 53 browser thuộc source trước sửa profile, chưa phải acceptance source mới. Chi tiết review từng SHA và provenance audit nằm trong session/history-review-progress.tsv, baseline-review-*.tsv và history-diffs/*-generated-audit.json; chưa đủ toàn bộ 108 commit.
